# V22.0 Release Notes

V22 implements the recommended typed application boundary layer on top of V21.

### Highlights
- Typed command contract
- Typed domain-event envelope
- EventBus fault isolation preserved
- Contract-neutral application boundary module
- Backward-compatible legacy command and event handler support
- Self-repair `asdict` import correction
- V22 release metadata correction
- Architecture regression tests

### Verification
301/301 tests PASS.
Compileall PASS.
No circular production import cycles detected.
LIVE_TRADING remains disabled.
