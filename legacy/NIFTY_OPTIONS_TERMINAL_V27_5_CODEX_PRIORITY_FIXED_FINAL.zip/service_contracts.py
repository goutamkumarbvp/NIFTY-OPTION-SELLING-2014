from __future__ import annotations
"""Dependency contracts for V21.

Application services depend on these narrow bundles instead of importing concrete
trading/infrastructure implementations.  Concrete wiring lives in composition.py.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Protocol
from application_contracts import DomainEvent, EventTopic

class EventBusPort(Protocol):
    def publish(self, event: DomainEvent | str, payload: dict[str, Any] | None = None) -> dict[str, Any]: ...
    def subscribe(self, topic: EventTopic | str, handler: Callable[[DomainEvent], None]) -> None: ...

@dataclass(frozen=True)
class MarketDependencies:
    config_cls: Any
    manager_cls: Any
    adapter_cls: Any
    adapter_config_cls: Any
    redacted_env: Callable[[dict], dict]
    sfeed_cls: Any
    feed_supervisor_cls: Any
    build_chain: Callable
    chain_metrics: Callable
    chain_feed_tokens: Callable
    response_extractor: Any
    token_resolver: Any
    subscription_planner: Any
    tick_soak_monitor: Any
    pass15_error: type[Exception]
    reconcile: Callable

@dataclass(frozen=True)
class IntelligenceDependencies:
    risk_brain: Any
    advanced_risk: Any
    strategy_brain: Any
    options_intel: Any
    regime_engine: Any
    quant: Any
    vol_surface: Any
    event_intel: Any
    fii_dii: Any

@dataclass(frozen=True)
class ResearchDependencies:
    backtester: Any
    data_store_factory: Callable[[Path], Any]
    option_backtester: Any
    walk_forward: Any
    option_chain_store_factory: Callable[[Path], Any]
    option_replay: Any
    research_margin_engine: Any
    stress: Any
    strategy_backtester: Any
    strategy_optimizer_factory: Callable[[Any], Any]
    v10_store_factory: Callable[[Path], Any]
    csv_importer: Any
    parquet_exporter: Any
    v10_calendar: Any
    contract_mapper: Any
    v11_registry_factory: Callable[[Path], Any]
    v11_series: Any
    v11_query_factory: Callable[[Path], Any]
    v11_quality: Any
    v11_replay_engine: Any
    v12_provenance_factory: Callable[[Path], Any]
    v12_partitions_factory: Callable[[Path], Any]
    v12_coverage: Any
    v12_source: Any
    v12_completeness: Any
    v13_schema: Any
    v13_integrity: Any
    v13_calendar: Any
    v13_chain: Any
    v13_stream: Any
    v13_certifier: Any
    v13_replay_engine: Any
    robustness: Callable
    monte_carlo_validate: Callable

@dataclass(frozen=True)
class AIDependencies:
    super_agent: Any
    pass17_factory: Callable[[Path], Any]
    alert_manager_factory: Callable[[Path, dict], Any]
    self_repair_factory: Callable[[Path, Callable], Any]
    llm_gateway: Any
    long_term_memory_factory: Callable[[Path], Any]
    autonomous_research: Any
    verified_repair_factory: Callable[[Any], Any]

@dataclass(frozen=True)
class ApplicationDependencies:
    market: MarketDependencies
    intelligence: IntelligenceDependencies
    research: ResearchDependencies
    ai: AIDependencies
    paper_execution_factory: Callable[[Path], Any]
    event_bus: EventBusPort
