from __future__ import annotations
import ast, hashlib, re
from pathlib import Path
from safety_authority import PAPER_ONLY_INVARIANTS

FORBIDDEN_PATH_PARTS={'.env','.env.local','.env.production'}
FORBIDDEN_FILES={'safety_authority.py','security_verifier.py'}
DANGEROUS_MODULES={'os','subprocess','socket','ctypes','multiprocessing','signal','resource','pty','shutil','pathlib','importlib','runpy','code','pickle','marshal','ftplib','telnetlib','requests','httpx','aiohttp','urllib.request','http.client'}
DANGEROUS_CALLS={'eval','exec','compile','__import__','open','system','popen','Popen','run','call','check_call','check_output','create_connection','remove','unlink','rmtree','rename','replace','chmod','chown','makedirs','mkdir','write_text','write_bytes','putenv','unsetenv','getattr','setattr','delattr','globals','locals','vars','breakpoint'}
DANGEROUS_ATTRS={'__builtins__','__import__','__globals__','__subclasses__','__class__','__base__','__bases__','__mro__','__getattribute__','__getattr__','__setattr__','__delattr__','__code__','__loader__','__spec__','__reduce__','__reduce_ex__'}

def verify_tree(root: Path, candidate_files=None):
    root=Path(root).resolve(); violations=[]
    protected_hash=policy_hash(root)
    paths=[root/x for x in candidate_files] if candidate_files else list(root.rglob('*.py'))
    for p in paths:
        if any(x in {'__pycache__','.pytest_cache','.venv','venv'} for x in p.parts): continue
        if p.name.startswith('test_') or p.name in {'security_verifier.py','self_repair.py'}: continue
        try: tree=ast.parse(p.read_text(encoding='utf-8',errors='replace'), filename=str(p))
        except SyntaxError as e: violations.append(f'{p}:SYNTAX:{e}'); continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant) and str(node.value.value).lower()=='true':
                for t in node.targets:
                    if isinstance(t,ast.Name) and t.id in {'LIVE_TRADING','LIVE_ORDERS_ENABLED'}: violations.append(f'{p}:LIVE_ENABLE_ASSIGNMENT')
            if isinstance(node, ast.FunctionDef) and node.name in {'place_order','submit_order','execute_order'}:
                violations.append(f'{p}:ORDER_FUNCTION')
            if candidate_files and isinstance(node,(ast.Import,ast.ImportFrom)):
                for a in node.names:
                    if a.name in DANGEROUS_MODULES or any(a.name.startswith(x+'.') for x in DANGEROUS_MODULES): violations.append(f'{p}:DANGEROUS_IMPORT:{a.name}')
            if candidate_files and isinstance(node,ast.Call):
                fn=node.func; name=fn.id if isinstance(fn,ast.Name) else fn.attr if isinstance(fn,ast.Attribute) else ''
                if name in DANGEROUS_CALLS: violations.append(f'{p}:DANGEROUS_CALL:{name}')
                if isinstance(fn,ast.Attribute) and isinstance(fn.value,ast.Name) and fn.value.id in {'os','subprocess','socket','shutil','pathlib','ctypes'}:
                    violations.append(f'{p}:DANGEROUS_CAPABILITY:{fn.value.id}.{name}')
            if candidate_files and isinstance(node,ast.Attribute) and node.attr in DANGEROUS_ATTRS:
                violations.append(f'{p}:DANGEROUS_REFLECTION:{node.attr}')
            if candidate_files and isinstance(node,ast.Name) and node.id in DANGEROUS_ATTRS:
                violations.append(f'{p}:DANGEROUS_NAME:{node.id}')
    # The verifier's own policy implementation is integrity-protected by its hash.
    if not protected_hash: violations.append('POLICY_HASH_UNAVAILABLE')
    return {'ok':not violations,'violations':violations,'policy_sha256':protected_hash}

def policy_hash(root: Path):
    files=[]
    for name in ['safety_authority.py']:
        p=Path(root)/name
        if p.exists(): files.append(p.read_bytes())
    h=hashlib.sha256(); [h.update(x) for x in files]; return h.hexdigest()
