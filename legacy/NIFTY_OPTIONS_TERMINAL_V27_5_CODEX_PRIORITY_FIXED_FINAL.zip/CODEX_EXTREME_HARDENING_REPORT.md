# V27.3 Codex Extreme Hardening

This release was hardened in an isolated workspace under the mandatory paper-only boundary.

## Changes

1. **Quant numerical fail-closed:** Black-Scholes Greeks now convert overflow/value/division failures into `INVALID_BS_INPUT`; implied-volatility solving rejects invalid/non-finite solver states instead of propagating numerical exceptions.
2. **Self-repair candidate identity:** verification no longer relies on shared `_candidate_rel_for_verify` state; candidate identity is passed explicitly per verification operation.
3. **Self-repair independent verifier:** candidate-scoped verification now rejects Python reflection/builtin recovery primitives such as `__builtins__`, `__import__`, `getattr`, `globals`, `locals`, `object.__subclasses__`, and related dunder capabilities.
4. **Self-repair patch-size gate:** replacement source larger than 120,000 UTF-8 bytes is rejected before sandbox execution.
5. **Sandbox hardening:** host system bind mounts used for the Linux verification sandbox are remounted read-only; only disposable workspace and tmpfs `/tmp` remain writable.
6. **Market-data boundary:** negative OI and negative volume are rejected during option-chain normalization, preventing impossible counts from reaching PCR/liquidity calculations.
7. **Regression compatibility:** the self-repair rollback test was updated to the explicit candidate-verification interface.
8. **Release hygiene:** runtime-generated databases, audit logs, research artifacts, caches and bytecode are excluded from the distributable release archive.

## Verification

- `python3 -m compileall -q .` — PASS
- complete pytest suite — **341 passed**
- independent security verifier — PASS, 0 violations
- extreme Black-Scholes input — fail-closed
- independent reflection attacks — blocked
- safe self-repair candidate — verified
- malicious self-repair candidate — rejected
- HTTP `/api/health` — 200
- HTTP `/api/state` — 200
- live-mode safety flags — blocked
- P0-1 FIFO paper P&L — verified
- P0-2 negative OI/volume — blocked

## Boundary

This is a **paper/read-only release**. No real broker credentials, order endpoint, position, funds, or real OpenAI credential were used. Real Kotak execution and full browser E2E remain outside this certification.


## Additional adversarial fault-injection round — 2026-09-15

[EXECUTED — VERIFIED]
- Injected non-finite/negative feed age faults: recovery succeeded only when health became valid.
- Injected false-positive recovery (`ok=true` while feed remained unhealthy): remained non-healthy.
- Injected recovery exception: remained non-healthy.
- Injected repeated recovery failures: circuit breaker opened.
- Discovered a post-recovery verification gap: a stale feed with a live thread/socket could previously be promoted to `HEALTHY`.
- Repaired the supervisor to re-run eligibility and the complete failure detector after recovery; stale/invalid/disconnected/unauthenticated/disabled states can no longer be promoted.
- Added regression test `test_recovery_cannot_promote_stale_feed_to_healthy`.

Targeted fault-injection result: **5/5 PASS** after repair.
Full suite collection: **346 tests**. A complete uninterrupted suite run exceeded the local execution timeout; therefore the full 346-test suite is not claimed as independently passed in this round.
