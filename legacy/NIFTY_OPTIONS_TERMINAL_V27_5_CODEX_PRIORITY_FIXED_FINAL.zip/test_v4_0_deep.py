from strategy_brain import StrategyBrain
from server import TerminalBackend, Handler
from http.server import ThreadingHTTPServer
from urllib.request import urlopen, Request
import threading, json, re

def good_chain():
    return [{'strike':24900,'pe':{'ltp':20,'oi':1000,'doi':200},'ce':{'ltp':150,'oi':300,'doi':-50}},
            {'strike':25000,'pe':{'ltp':30,'oi':1500,'doi':300},'ce':{'ltp':100,'oi':1000,'doi':50}},
            {'strike':25100,'pe':{'ltp':50,'oi':800,'doi':100},'ce':{'ltp':60,'oi':1800,'doi':200}},
            {'strike':25200,'pe':{'ltp':80,'oi':500,'doi':50},'ce':{'ltp':30,'oi':2200,'doi':300}}]

def test_neutral_iron_condor_candidate():
    c=good_chain()
    for r in c:
        r['pe']['oi']=r['ce']['oi']
        r['pe']['doi']=r['ce']['doi']
    p=StrategyBrain().analyze(c,25000,'RANGE')
    assert any(x['type']=='IRON_CONDOR_CANDIDATE' for x in p['candidates'])

def test_strategy_never_enables_execution():
    p=StrategyBrain().analyze(good_chain(),25000,'RANGE')
    assert all(x['execution']=='DISABLED' and x['risk_gate_required'] for x in p['candidates'])

def test_invalid_chain_fail_closed():
    assert StrategyBrain().analyze([],25000)['status']=='BLOCKED'

def test_server_version_and_routes():
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); threading.Thread(target=srv.serve_forever,daemon=True).start()
    try:
        h=json.loads(urlopen(f'http://127.0.0.1:{srv.server_address[1]}/api/health').read())
        assert h['api_schema_version']=='v12.0' and h['live_orders_enabled'] is False
        req=Request(f'http://127.0.0.1:{srv.server_address[1]}/api/trade-plan',data=b'{}',headers={'Content-Type':'application/json'})
        out=json.loads(urlopen(req).read()); assert out['ok'] and out['execution']=='DISABLED'
    finally: srv.shutdown(); srv.server_close()

def test_dashboard_strategy_wiring():
    html=open('dashboard/index.html',encoding='utf8').read()
    assert "id=\"strategy\"" in html and "'/api/strategy/analyze'" in html
    assert 'live_orders_enabled' not in html.split('<script>')[0] or 'LIVE ORDERS DISABLED' in html
