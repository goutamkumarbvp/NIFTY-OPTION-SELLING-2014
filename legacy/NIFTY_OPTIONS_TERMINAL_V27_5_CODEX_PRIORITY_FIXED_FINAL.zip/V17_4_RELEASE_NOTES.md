# V17.4 — Bounded Runtime Self-Healing

## Added
- Deterministic `SelfHealingSupervisor` for the live Kotak SFeed runtime.
- Detects dead feed thread, disconnect, or stale feed.
- Automatically performs bounded feed restart only when authenticated, explicitly feed-armed, market state is safe/open, and terminal is not PAUSED/EMERGENCY.
- Recovery verification after restart.
- Cooldown + rolling-window circuit breaker to prevent infinite reconnect loops.
- Hash-chained audit events for healing attempts, success, failure, and circuit-open state.
- Dashboard visibility for healing status/recovery count.

## Explicit limits
This is runtime self-healing, not autonomous source-code self-repair. It does not edit Python, install packages, alter risk policy, place orders, or bypass safety. If the whole Python process dies, an external process supervisor/launcher is still required.

## Verification
- Pytest: 265/265 PASS
- compileall/py_compile: PASS
- No `place_order()` definition found.
- No `live_orders_enabled=True` found.
