import json, math
from server import json_safe

def test_json_safe_replaces_non_finite_numbers():
    payload={"a": float("nan"), "b": float("inf"), "c": [float("-inf"), 1.25], "d": {"x": float("nan")}}
    safe=json_safe(payload)
    assert safe == {"a": None, "b": None, "c": [None, 1.25], "d": {"x": None}}
    json.dumps(safe, allow_nan=False)

def test_paper_safety_metadata():
    assert json_safe({"live_orders_enabled": False, "paper_only": True})["live_orders_enabled"] is False
