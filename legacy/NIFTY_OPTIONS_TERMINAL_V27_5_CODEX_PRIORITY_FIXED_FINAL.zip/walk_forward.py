from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class WalkForwardConfig:
    train_bars:int=100
    test_bars:int=25
    step:int=25

class WalkForwardValidator:
    def __init__(self,config=None): self.config=config or WalkForwardConfig()
    def split(self,rows):
        n=len(rows); c=self.config; out=[]; start=0
        if c.train_bars<=0 or c.test_bars<=0 or c.step<=0: return {'status':'BLOCKED','reason':'INVALID_CONFIG'}
        while start+c.train_bars+c.test_bars<=n:
            out.append({'train_start':start,'train_end':start+c.train_bars,'test_start':start+c.train_bars,'test_end':start+c.train_bars+c.test_bars})
            start+=c.step
        return {'status':'READY' if out else 'BLOCKED','reason':None if out else 'INSUFFICIENT_DATA','windows':out}
    def evaluate(self, rows, scorer):
        s=self.split(rows)
        if s['status']!='READY': return s
        results=[]
        for w in s['windows']:
            train=rows[w['train_start']:w['train_end']]; test=rows[w['test_start']:w['test_end']]
            model=scorer(train)
            results.append({'window':w,'train_score':model.get('score',0),'test_score':model.get('test_score',0),'degradation':model.get('score',0)-model.get('test_score',0)})
        return {'status':'READY','windows':results,'avg_test_score':sum(x['test_score'] for x in results)/len(results)}
