# V22 Security / Deployment Boundary

## Default
- `LIVE_TRADING=false` is mandatory for this release.
- The built-in server binds to `127.0.0.1` by default.
- No live order endpoint is exposed.
- Broker credentials and TOTP secrets belong only in a local `.env` or process environment.

## Remote deployment
For a remote/cloud deployment, do not expose the built-in HTTP server directly to the Internet.
Use a hardened reverse proxy with HTTPS, authentication, rate limiting, request-size limits,
network controls, process supervision, centralized logs, backups, and secret management.
If `BIND_HOST` is changed from loopback, `API_AUTH_TOKEN` is required as a second safety gate.
TLS is intentionally delegated to the reverse proxy.
