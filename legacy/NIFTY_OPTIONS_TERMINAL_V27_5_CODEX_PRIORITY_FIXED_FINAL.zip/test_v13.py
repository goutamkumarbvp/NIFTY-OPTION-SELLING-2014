import tempfile, json, time
from pathlib import Path
from pass13_engine import CanonicalNiftySchema, IntegrityScanner, SessionCalendar, ContractChain, DatasetCertifier, FastReplay

def row(ts='2026-09-15T09:15:00+05:30', exp='2026-09-24', opt='CE', token='1'):
    return {'timestamp':ts,'dataset':'demo','symbol':'NIFTY24SEP25000'+opt,'instrument_token':token,'exchange_segment':'nse_fo','underlying':'NIFTY','expiry':exp,'strike':25000,'option_type':opt,'lot_size':65,'tick_size':.05,'spot':25000,'bid':100,'ask':101,'last':100.5,'volume':100,'oi':1000}

def test_schema_canonicalizes_aliases():
    x=row(); x['ts']=x.pop('timestamp'); x['token']=x.pop('instrument_token'); r=CanonicalNiftySchema.normalize(x); assert r['instrument_token']=='1' and r['timestamp'].endswith('+05:30')
def test_schema_blocks_naive():
    x=row('2026-09-15T09:15:00');
    try: CanonicalNiftySchema.normalize(x); assert False
    except ValueError as e: assert str(e)=='TIMESTAMP_TIMEZONE_REQUIRED'
def test_schema_blocks_non_nifty():
    x=row(); x['underlying']='BANKNIFTY'
    try: CanonicalNiftySchema.normalize(x); assert False
    except ValueError as e: assert str(e)=='NON_NIFTY_UNDERLYING'
def test_schema_blocks_crossed():
    x=row(); x['bid']=102; x['ask']=101
    try: CanonicalNiftySchema.normalize(x); assert False
    except ValueError as e: assert str(e)=='CROSSED_MARKET'
def test_integrity_duplicates():
    r=IntegrityScanner().scan([row(),row()]); assert r['duplicates']==1
def test_integrity_order():
    r=IntegrityScanner().scan([row('2026-09-15T09:16:00+05:30'),row('2026-09-15T09:15:00+05:30')],True); assert r['reason']=='OUT_OF_ORDER'
def test_calendar_weekend():
    r=SessionCalendar().check('2026-09-12T10:00:00+05:30'); assert r['weekend'] and not r['in_regular_session']
def test_calendar_holiday():
    r=SessionCalendar().check('2026-09-14T10:00:00+05:30'); assert r['holiday'] and not r['in_regular_session']
def test_calendar_regular():
    r=SessionCalendar().check('2026-09-15T10:00:00+05:30'); assert r['in_regular_session']
def test_contract_chain_pairs():
    rows=[row(opt='CE',token='1'),row(opt='PE',token='2'),row(exp='2026-10-01',opt='CE',token='3')]
    r=ContractChain().group(rows); assert r['expiry_count']==2 and r['expiries'][0]['complete_pairs']==1
def test_nearest_expiry():
    rows=[row(exp='2026-09-24'),row(exp='2026-10-01')]; assert ContractChain().nearest(rows,'2026-09-15')['expiry']=='2026-09-24'
def test_nearest_no_future():
    rows=[row(exp='2026-09-01')]; assert ContractChain().nearest(rows,'2026-09-15')['reason']=='NO_FUTURE_EXPIRY'
def test_certification_clean():
    r=DatasetCertifier().certify([row()],'x',1,1); assert r['status']=='CERTIFIED' and len(r['sha256'])==64
def test_certification_duplicate_not_certified():
    r=DatasetCertifier().certify([row(),row()],'x'); assert r['status']=='NOT_CERTIFIED' and r['integrity']['duplicates']==1
def test_replay():
    r=FastReplay().replay([row(),row('2026-09-15T09:16:00+05:30')]); assert r['status']=='READY' and r['events']==2
def test_replay_out_of_order():
    r=FastReplay().replay([row('2026-09-15T09:16:00+05:30'),row('2026-09-15T09:15:00+05:30')]); assert r['reason']=='OUT_OF_ORDER'
def test_replay_limit():
    assert FastReplay().replay([row()]*3,2)['reason']=='EVENT_LIMIT_EXCEEDED'
