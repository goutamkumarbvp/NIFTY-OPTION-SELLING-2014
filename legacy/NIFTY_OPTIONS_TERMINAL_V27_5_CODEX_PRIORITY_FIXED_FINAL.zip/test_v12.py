import os, tempfile, json
from pathlib import Path
from pass12_engine import HistoricalNormalizer, ContractIdentity, ProvenanceRegistry, PartitionedStore, CoverageAnalyzer, DatasetCompleteness, ReplaySource

def row(ts='2026-09-15T09:15:00+05:30',expiry='2026-09-24',opt='CE',bid=100,ask=101):
    return {'timestamp':ts,'spot':25000,'expiry':expiry,'symbol':'NIFTY24SEP25000'+opt,'instrument_token':'1','exchange_segment':'nse_fo','underlying':'NIFTY','strike':25000,'option_type':opt,'lot_size':75,'tick_size':.05,'bid':bid,'ask':ask,'oi':1000,'volume':100}

def test_normalize_aliases_and_timezone():
    r=HistoricalNormalizer.row({'ts':'2026-09-15T09:15:00+05:30',**{k:v for k,v in row().items() if k!='timestamp'}})
    assert r['option_type']=='CE' and r['strike']==25000

def test_naive_timestamp_blocked():
    x=row('2026-09-15T09:15:00');
    try: HistoricalNormalizer.row(x); assert False
    except ValueError as e: assert str(e)=='TIMESTAMP_TIMEZONE_REQUIRED'

def test_contract_identity_required():
    x=row(); del x['lot_size']
    try: ContractIdentity.validate(x); assert False
    except ValueError: pass

def test_contract_non_nifty_blocked():
    x=row(); x['underlying']='BANKNIFTY'
    try: ContractIdentity.validate(x); assert False
    except ValueError as e: assert str(e)=='NON_NIFTY_UNDERLYING'

def test_crossed_market_blocked():
    x=row(bid=102,ask=101)
    try: HistoricalNormalizer.row(x); assert False
    except ValueError as e: assert str(e)=='CROSSED_MARKET'

def test_negative_oi_blocked():
    x=row(); x['oi']=-1
    try: HistoricalNormalizer.row(x); assert False
    except ValueError as e: assert str(e)=='INVALID_OI_OR_VOLUME'

def test_provenance_immutable():
    with tempfile.TemporaryDirectory() as d:
        p=ProvenanceRegistry(Path(d)/'p.sqlite3'); rows=[row()]
        assert p.register('x','source.csv','csv',rows)['status']=='READY'
        assert p.register('x','source.csv','csv',rows)['existing'] is True
        changed=[row(bid=99)]
        assert p.register('x','source.csv','csv',changed)['reason']=='DATASET_IMMUTABLE'

def test_provenance_readback():
    with tempfile.TemporaryDirectory() as d:
        p=ProvenanceRegistry(Path(d)/'p.sqlite3'); rows=[row()]; p.register('x','s','csv',rows)
        assert p.get('x')['lineage']['schema_version']=='v12.0'

def test_partitioned_store_groups_date_expiry():
    with tempfile.TemporaryDirectory() as d:
        st=PartitionedStore(d); rows=[row('2026-09-15T09:15:00+05:30'),row('2026-09-16T09:15:00+05:30',expiry='2026-10-01')]
        r=st.write('ds',rows); assert r['partitions']==2; assert st.manifest('ds')['partitions']==2

def test_partitioned_store_no_rows():
    with tempfile.TemporaryDirectory() as d: assert PartitionedStore(d).write('x',[])['reason']=='NO_ROWS'

def test_coverage_basic():
    rows=[row('2026-09-15T09:15:00+05:30'),row('2026-09-15T09:16:00+05:30')]
    c=CoverageAnalyzer().analyze(rows); assert c['status']=='READY' and c['days']==1 and c['gap_count']==0

def test_coverage_gap_detection():
    rows=[row('2026-09-15T09:15:00+05:30'),row('2026-09-15T09:16:00+05:30'),row('2026-09-15T09:17:00+05:30'),row('2026-09-15T14:17:00+05:30')]
    c=CoverageAnalyzer().analyze(rows); assert c['gap_count']==1

def test_coverage_nonmonotonic_blocked():
    rows=[row('2026-09-15T09:16:00+05:30'),row('2026-09-15T09:15:00+05:30')]
    assert CoverageAnalyzer().analyze(rows)['reason']=='NON_MONOTONIC_TIMESTAMP'

def test_completeness_expected_days():
    rows=[row('2026-09-15T09:15:00+05:30'),row('2026-09-16T09:15:00+05:30')]
    c=CoverageAnalyzer().analyze(rows); r=DatasetCompleteness().score(c,expected_days=4); assert r['score']==.5

def test_completeness_invalid_expectation():
    c=CoverageAnalyzer().analyze([row()]); assert DatasetCompleteness().score(c,expected_days=0)['reason']=='INVALID_EXPECTED_DAYS'

def test_replay_source_jsonl():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'x.jsonl'; p.write_text(json.dumps(row())+'\n'+json.dumps(row('2026-09-15T09:16:00+05:30'))+'\n')
        assert len(ReplaySource().from_jsonl(p))==2

def test_replay_source_limit():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'x.jsonl'; p.write_text('\n'.join(json.dumps(row()) for _ in range(4))+'\n')
        assert len(ReplaySource().from_jsonl(p,2))==2

def test_invalid_quote_price():
    x=row(); x['bid']=0
    try: HistoricalNormalizer.row(x); assert False
    except ValueError as e: assert str(e)=='INVALID_QUOTE'

def test_invalid_tick():
    x=row(); x['tick_size']=0
    try: ContractIdentity.validate(x); assert False
    except ValueError as e: assert str(e)=='INVALID_CONTRACT_NUMERIC'

def test_invalid_expiry():
    x=row(); x['expiry']='not-date'
    try: ContractIdentity.validate(x); assert False
    except ValueError as e: assert str(e)=='INVALID_CONTRACT_NUMERIC_OR_EXPIRY'

def test_partition_manifest_missing():
    with tempfile.TemporaryDirectory() as d: assert PartitionedStore(d).manifest('missing')['reason']=='DATASET_NOT_FOUND'

def test_coverage_empty(): assert CoverageAnalyzer().analyze([])['reason']=='NO_ROWS'

def test_completeness_no_gap_single():
    c=CoverageAnalyzer().analyze([row()]); assert DatasetCompleteness().score(c)['score']==1.0

def test_symbol_can_be_arbitrary_but_identity_explicit():
    x=row(); x['symbol']='BROKER_EXPLICIT_SYMBOL'; assert ContractIdentity.validate(x)

def test_exchange_case_insensitive():
    x=row(); x['exchange_segment']='NSE_FO'; assert ContractIdentity.validate(x)

def test_option_type_normalized():
    x=row(opt='PE'); x['option_type']='pe'; r=HistoricalNormalizer.row(x); assert r['option_type']=='PE'

def test_nonfinite_spot_blocked():
    x=row(); x['spot']='nan'
    try: HistoricalNormalizer.row(x); assert False
    except ValueError as e: assert str(e)=='INVALID_SPOT'

def test_nonfinite_oi_blocked():
    x=row(); x['oi']='nan'
    try: HistoricalNormalizer.row(x); assert False
    except ValueError as e: assert str(e)=='INVALID_OI_OR_VOLUME'

def test_partition_atomic_file_exists():
    with tempfile.TemporaryDirectory() as d:
        r=PartitionedStore(d).write('x',[row()]); assert Path(r['files'][0]).exists(); assert not Path(str(r['files'][0])+'.tmp').exists()

def test_lineage_source_type_persisted():
    with tempfile.TemporaryDirectory() as d:
        p=ProvenanceRegistry(Path(d)/'p.sqlite3'); p.register('x','kotak','broker', [row()]); assert p.get('x')['lineage']['source_type']=='broker'

def test_coverage_expiry_counts():
    rows=[row(expiry='2026-09-24'),row('2026-09-15T09:16:00+05:30',expiry='2026-10-01')]
    c=CoverageAnalyzer().analyze(rows); assert len(c['expiries'])==2
