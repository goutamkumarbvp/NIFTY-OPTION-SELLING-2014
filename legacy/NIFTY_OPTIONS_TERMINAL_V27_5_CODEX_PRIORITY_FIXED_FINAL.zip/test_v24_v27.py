import os, tempfile, unittest
from pathlib import Path
from v24_llm_gateway import LLMReasoningGateway
from v25_agent_memory import AgentLongTermMemory
from v26_autonomous_research import AdvancedAutonomousResearch
from v27_verified_autonomous_repair import VerifiedAutonomousRepair

class StubRepair:
    def status(self): return {'enabled':True,'auto_promote':False}
    def diagnose(self,error,target):
        from self_repair import Diagnosis
        return Diagnosis('i','SYNTAX','LOW','test',1.0,[error],[str(target)],True,'verify')
    def propose_and_verify(self,d,target,new_source,promote=False):
        from self_repair import RepairResult
        return RepairResult(True,'VERIFIED',d,None,None,False,False,'sandbox verified')

class TestV24V27(unittest.TestCase):
    def test_v24_deterministic_and_redaction(self):
        g=LLMReasoningGateway({'LLM_GATEWAY_ENABLED':'false'})
        r=g.reason({'api_key':'SECRET','feed':'fresh'},'safe')
        self.assertTrue(r['ok']); self.assertEqual(r['mode'],'deterministic'); self.assertNotIn('SECRET',r['summary'])
    def test_v24_fail_closed_remote(self):
        g=LLMReasoningGateway({'LLM_GATEWAY_ENABLED':'true','LLM_GATEWAY_URL':'http://127.0.0.1:1','LLM_TIMEOUT_SECONDS':'1'})
        r=g.reason({'x':'stale'}); self.assertTrue(r['blocked']); self.assertEqual(r['mode'],'fallback')
    def test_v25_persist_and_learn(self):
        with tempfile.TemporaryDirectory() as d:
            m=AgentLongTermMemory(Path(d)/'m.sqlite'); m.remember('t1','PAPER CANDIDATE',.8,{'token':'SECRET'}); m.record_outcome('t1','WIN',1); k=m.learn('h1','test',True)
            self.assertEqual(m.recent(1)[0]['outcome'],'WIN'); self.assertEqual(k['success_rate'],1.0)
            self.assertEqual(AgentLongTermMemory(Path(d)/'m.sqlite').recent(1)[0]['trace_id'],'t1')
    def test_v26_research(self):
        bars=[{'close':100+i*0.2} for i in range(100)]
        r=AdvancedAutonomousResearch().run(bars,[{'name':'trend','threshold':0}])
        self.assertEqual(r['status'],'READY'); self.assertEqual(r['guardrails']['live_orders_enabled'],False); self.assertTrue(r['results'][0]['robustness']['pass'])
    def test_v27_policy(self):
        v=VerifiedAutonomousRepair(StubRepair()); s=v.status(); self.assertFalse(s['promotion_default']); self.assertFalse(s['live_orders_enabled'])
        r=v.run('x',Path('foo.py'),approve=True); self.assertTrue(r['ok']); self.assertFalse(r['result']['promoted'])

if __name__=='__main__': unittest.main()

class TestProviderWiring(unittest.TestCase):
    def test_openai_provider_is_fail_closed_without_key(self):
        from self_repair import OpenAIRepairProvider
        p=OpenAIRepairProvider({'REPAIR_LLM_ENABLED':'true','OPENAI_API_KEY':'','TRADING_MODE':'paper'})
        self.assertIsNone(p.propose(None,'x','x.py'))
    def test_openai_gateway_config(self):
        g=LLMReasoningGateway({'LLM_GATEWAY_ENABLED':'true','LLM_PROVIDER':'openai','OPENAI_API_KEY':'x','LLM_MODEL':'gpt-5.6-sol'})
        self.assertTrue(g.allow_remote); self.assertTrue(g.url.endswith('/v1/responses')); self.assertEqual(g.model,'gpt-5.6-sol')
