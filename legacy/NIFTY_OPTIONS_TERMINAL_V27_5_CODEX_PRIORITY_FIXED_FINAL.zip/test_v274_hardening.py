import os, tempfile, subprocess, sys
from pathlib import Path
from paper_execution import PaperExecutionLedger
from self_repair import RepairPolicy
from security_verifier import verify_tree

def test_paper_ledger_order_mark_flatten_persists():
    with tempfile.TemporaryDirectory() as d:
        l=PaperExecutionLedger(Path(d)/'ledger.sqlite3')
        o=l.submit('NIFTYCE','SELL',75,fill_price=100)
        assert o['status']=='FILLED' and l.positions()[0]['net_quantity']==-75
        assert l.mark_to_market({'NIFTYCE':80})['unrealized_pnl']==1500
        assert len(l.flatten({'NIFTYCE':80}))==1
        assert l.positions()[0]['net_quantity']==0

def test_repair_cannot_modify_existing_safety_policy():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'app.py'; p.write_text('LIVE_TRADING=false\n')
        pol=RepairPolicy(Path(d))
        assert pol.patch_allowed(p.read_text(),'LIVE_TRADING=false\n# changed gate\n',p)[0] is False

def test_independent_verifier_passes_release_tree():
    r=verify_tree(Path(__file__).parent)
    assert r['ok'], r

def test_live_flags_fail_closed_at_startup():
    env=dict(os.environ); env.update({'TRADING_MODE':'paper','LIVE_TRADING':'true','LIVE_ORDERS_ENABLED':'false','PORT':'8521','BIND_HOST':'127.0.0.1'})
    p=subprocess.run([sys.executable,'server.py'],cwd=Path(__file__).parent,env=env,text=True,capture_output=True,timeout=10)
    assert p.returncode != 0
    assert 'LIVE_TRADING_MUST_BE_FALSE' in (p.stdout+p.stderr)
