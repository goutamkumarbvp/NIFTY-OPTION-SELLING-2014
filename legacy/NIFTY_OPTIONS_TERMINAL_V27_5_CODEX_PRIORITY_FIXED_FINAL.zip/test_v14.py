import os, time
from pass14_engine import KotakReadOnlyConfig, ReadOnlyGate, redacted_env, generate_totp, ConnectionState, TickQuality, Pass14SafetyError

def env():
    return {'NEO_CONSUMER_KEY':'abc123456','NEO_MOBILE_NUMBER':'9876543210','NEO_UCC':'X24PD','NEO_MPIN':'123456','NEO_TOTP_SECRET':'secret','LIVE_TRADING':'false'}

def test_env_config_paper_only():
    c=KotakReadOnlyConfig.from_env(env()); assert c.live_trading is False; assert c.validate()

def test_live_true_blocked():
    e=env(); e['LIVE_TRADING']='true'
    try: KotakReadOnlyConfig.from_env(e); assert False
    except Pass14SafetyError as x: assert 'LIVE_TRADING' in str(x)

def test_missing_key_blocked():
    e=env(); e['NEO_CONSUMER_KEY']=''
    try: KotakReadOnlyConfig.from_env(e).validate(); assert False
    except Pass14SafetyError as x: assert str(x)=='MISSING_NEO_CONSUMER_KEY'

def test_redaction():
    r=redacted_env(env()); assert r['NEO_MPIN']=='***REDACTED***' and r['NEO_TOTP_SECRET']=='***REDACTED***' and r['NEO_CONSUMER_KEY']=='***REDACTED***'

def test_gate_paper(): assert ReadOnlyGate().assert_paper(False)

def test_state_feed_fresh():
    s=ConnectionState(authenticated=True,feed_connected=True,last_tick_at=time.time(),subscribed_tokens=10); x=s.snapshot(); assert x['feed_fresh'] and x['live_orders_enabled'] is False

def test_state_stale():
    s=ConnectionState(feed_connected=True,last_tick_at=time.time()-20); assert s.snapshot(10)['feed_fresh'] is False

def test_quality():
    q=TickQuality(); q.observe(type('T',(),{'local_sequence':1,'ltp':100})()); q.observe(type('T',(),{'local_sequence':2,'ltp':101})()); assert q.snapshot()['status']=='GOOD'

def test_quality_invalid():
    q=TickQuality(); q.observe(type('T',(),{'local_sequence':1,'ltp':0})()); assert q.snapshot()['invalid']==1

def test_quality_out_of_order():
    q=TickQuality(); q.observe(type('T',(),{'local_sequence':2,'ltp':100})()); q.observe(type('T',(),{'local_sequence':1,'ltp':100})()); assert q.snapshot()['out_of_order']==1

def test_totp_dependency_is_explicit():
    try:
        import pyotp
    except ImportError:
        try: generate_totp('x')
        except Pass14SafetyError as e: assert str(e)=='PYOTP_REQUIRED_FOR_TOTP_GENERATION'
        return
    code=pyotp.TOTP(pyotp.random_base32()).now(); assert len(code)==6 and code.isdigit()
