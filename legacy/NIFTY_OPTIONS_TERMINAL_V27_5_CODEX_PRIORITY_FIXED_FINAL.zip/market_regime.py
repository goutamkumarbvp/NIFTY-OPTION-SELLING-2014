from __future__ import annotations
from dataclasses import dataclass, asdict
from math import isfinite
from typing import Any

@dataclass(frozen=True)
class RegimeConfig:
    range_pcr_low: float=0.90
    range_pcr_high: float=1.10
    trend_threshold_pct: float=0.80
    high_vol_threshold: float=22.0

class MarketRegimeEngine:
    """Evidence-based regime classifier. Missing inputs remain UNKNOWN, never synthetic."""
    def __init__(self, config:RegimeConfig|None=None): self.config=config or RegimeConfig(); self.last={'regime':'UNKNOWN','confidence':0}
    def num(self,v):
        try:
            x=float(v); return x if isfinite(x) else None
        except (TypeError,ValueError): return None
    def classify(self, *, spot=None, prev_close=None, pcr=None, iv=None, breadth=None, trend=None):
        s=self.num(spot); pc=self.num(prev_close); p=self.num(pcr); v=self.num(iv); b=self.num(breadth)
        evidence=[]; score=0
        if s and pc and pc>0:
            move=(s-pc)/pc*100; evidence.append({'name':'spot_change_pct','value':move})
            if move>=self.config.trend_threshold_pct: score+=2
            elif move<=-self.config.trend_threshold_pct: score-=2
        if p is not None:
            evidence.append({'name':'pcr','value':p})
            if p>self.config.range_pcr_high: score+=1
            elif p<self.config.range_pcr_low: score-=1
        if v is not None:
            evidence.append({'name':'iv','value':v})
        if b is not None:
            evidence.append({'name':'breadth','value':b})
            if b>0.6: score+=1
            elif b<0.4: score-=1
        if trend is not None:
            t=str(trend).upper(); evidence.append({'name':'trend_input','value':t})
            if 'BULL' in t: score+=2
            elif 'BEAR' in t: score-=2
        if abs(score)>=2: regime='BULL_TREND' if score>0 else 'BEAR_TREND'
        elif p is not None or (s and pc): regime='RANGE'
        else: regime='UNKNOWN'
        conf=min(1.0, abs(score)/6 + min(len(evidence),3)*0.1) if evidence else 0.0
        if v is not None and v>=self.config.high_vol_threshold: regime += '_HIGH_VOL' if regime!='UNKNOWN' else 'HIGH_VOL'
        self.last={'regime':regime,'confidence':round(conf,3),'score':score,'evidence':evidence,'source':'derived_inputs'}; return self.last
    def health(self): return {'healthy':True,'config':asdict(self.config),'last':self.last}
