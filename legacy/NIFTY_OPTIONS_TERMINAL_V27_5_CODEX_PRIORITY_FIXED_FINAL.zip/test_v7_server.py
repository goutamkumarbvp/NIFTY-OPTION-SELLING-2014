from server import TerminalBackend,Handler
from http.server import ThreadingHTTPServer
from urllib.request import urlopen,Request
import json,threading

def call(base,path,payload):
 r=Request(base+path,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'}); return json.loads(urlopen(r).read())
def test_v7_state(): assert TerminalBackend().state()['api_schema_version']=='v12.0'
def test_v7_research_routes():
 a=TerminalBackend(); assert all(hasattr(a,x) for x in ('research_ingest','option_backtest_run','walk_forward_run','stress_run'))
def test_v7_http():
 srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); threading.Thread(target=srv.serve_forever,daemon=True).start(); base=f'http://127.0.0.1:{srv.server_address[1]}'
 try:
  h=json.loads(urlopen(base+'/api/health').read()); assert h['api_schema_version']=='v12.0' and h['live_orders_enabled'] is False and 'pass_7' in h
  assert call(base,'/api/research/data-ingest',{'dataset':'http_test_unique_v11_'+str(__import__('time').time_ns()),'rows':[{'timestamp':'2026-01-01T09:15:00+05:30','open':1,'high':2,'low':1,'close':1.5},{'timestamp':'2026-01-01T09:16:00+05:30','open':1.5,'high':2,'low':1.4,'close':1.8}]})['ok']
  assert call(base,'/api/research/options-backtest',{'bars':[{'bid':1,'ask':1.1},{'bid':1.2,'ask':1.3},{'bid':1,'ask':1.1}],'signals':[1,-1,0]})['ok']
  assert call(base,'/api/research/walk-forward',{'rows':list(range(150))})['ok']
  assert call(base,'/api/research/stress',{'trade_pnls':[1,-1,2]})['ok']
 finally:srv.shutdown();srv.server_close()
def test_v7_dashboard_routes():
 s=open('dashboard/index.html').read()
 for p in ['/api/research/data-ingest','/api/research/options-backtest','/api/research/walk-forward','/api/research/stress']: assert p in s
