# V27.1 — Paper Auto Self-Repair Isolation

## Change
V27.1 adds a dedicated Paper Auto Self-Repair policy and launch mode.

### Paper Mode
- automatic verified-repair promotion can be enabled only in an explicitly named `paper` runtime
- `LIVE_TRADING=false` is forced by the paper launchers
- `LIVE_ORDERS_ENABLED=false` is forced
- `PAPER_AUTO_SELF_REPAIR=true`
- `SELF_REPAIR_AUTO_PROMOTE=true` is accepted only inside Paper Mode
- compile + full tests + security verification remain mandatory before promotion

### Live Mode isolation
Even if `SELF_REPAIR_AUTO_PROMOTE=true` is present, auto-promotion is hard-disabled when:
- `TRADING_MODE != paper`, or
- `LIVE_TRADING=true`, or
- `LIVE_ORDERS_ENABLED=true`.

Repair policy also forbids modifying secret files and forbids introducing live-order enabling code.

## Scope
This release does not claim unrestricted autonomous programming. A repair is only automatic when the configured repair provider can generate a candidate patch; the default provider remains conservative/offline.
