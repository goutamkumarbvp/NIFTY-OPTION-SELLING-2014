$ErrorActionPreference = 'Stop'
if (-not (Test-Path .venv)) { python -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:TRADING_MODE='paper'
$env:LIVE_TRADING='false'
$env:LIVE_ORDERS_ENABLED='false'
$env:PORT='8500'
& .\.venv\Scripts\python.exe server.py
