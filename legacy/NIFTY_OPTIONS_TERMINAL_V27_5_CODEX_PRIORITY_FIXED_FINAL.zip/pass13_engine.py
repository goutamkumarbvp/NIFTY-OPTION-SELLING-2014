from __future__ import annotations
import csv, hashlib, json, math, os, re, sqlite3
from dataclasses import dataclass, asdict
from datetime import datetime, date, time, timedelta
from pathlib import Path
from collections import defaultdict

IST='Asia/Kolkata'
SESSION_OPEN=time(9,15); SESSION_CLOSE=time(15,30)
SCHEMA_VERSION='v13.0'

class Pass13ValidationError(ValueError): pass

@dataclass(frozen=True)
class CanonicalRecord:
    timestamp: str; dataset: str; symbol: str; instrument_token: str; exchange_segment: str
    underlying: str; expiry: str; strike: float; option_type: str; lot_size: int; tick_size: float
    spot: float; bid: float; ask: float; last: float|None; volume: float; oi: float; sequence: int|None

class CanonicalNiftySchema:
    REQUIRED=('timestamp','dataset','symbol','instrument_token','exchange_segment','underlying','expiry','strike','option_type','lot_size','tick_size','spot','bid','ask','volume','oi')
    @staticmethod
    def _ts(x):
        try: dt=datetime.fromisoformat(str(x).strip().replace('Z','+00:00'))
        except Exception as e: raise Pass13ValidationError('INVALID_TIMESTAMP') from e
        if dt.tzinfo is None: raise Pass13ValidationError('TIMESTAMP_TIMEZONE_REQUIRED')
        return dt.isoformat()
    @classmethod
    def normalize(cls, row):
        if not isinstance(row,dict): raise Pass13ValidationError('INVALID_ROW')
        aliases={'ts':'timestamp','time':'timestamp','trading_symbol':'symbol','token':'instrument_token','segment':'exchange_segment','underlying_price':'spot','best_bid':'bid','best_ask':'ask','last_price':'last','open_interest':'oi'}
        r={aliases.get(str(k).strip().lower(),str(k).strip().lower()):v for k,v in row.items()}
        missing=[k for k in cls.REQUIRED if k not in r or str(r[k]).strip()=='']
        if missing: raise Pass13ValidationError('MISSING_FIELDS:'+','.join(missing))
        r['timestamp']=cls._ts(r['timestamp']); r['dataset']=str(r['dataset']).strip()
        r['symbol']=str(r['symbol']).strip(); r['instrument_token']=str(r['instrument_token']).strip(); r['exchange_segment']=str(r['exchange_segment']).lower()
        r['underlying']=str(r['underlying']).upper(); r['option_type']=str(r['option_type']).upper(); r['expiry']=str(r['expiry'])[:10]
        if r['underlying']!='NIFTY': raise Pass13ValidationError('NON_NIFTY_UNDERLYING')
        if r['exchange_segment']!='nse_fo': raise Pass13ValidationError('INVALID_EXCHANGE_SEGMENT')
        if r['option_type'] not in ('CE','PE'): raise Pass13ValidationError('INVALID_OPTION_TYPE')
        try: date.fromisoformat(r['expiry'])
        except Exception as e: raise Pass13ValidationError('INVALID_EXPIRY') from e
        for k in ('strike','tick_size','spot','bid','ask','volume','oi'):
            try: r[k]=float(r[k])
            except Exception as e: raise Pass13ValidationError('INVALID_NUMERIC:'+k) from e
            if not math.isfinite(r[k]): raise Pass13ValidationError('NONFINITE:'+k)
        try: r['lot_size']=int(r['lot_size'])
        except Exception as e: raise Pass13ValidationError('INVALID_LOT_SIZE') from e
        if r['strike']<=0 or r['tick_size']<=0 or r['lot_size']<=0 or r['spot']<=0 or r['bid']<=0 or r['ask']<=0 or r['volume']<0 or r['oi']<0: raise Pass13ValidationError('INVALID_VALUE')
        if r['ask']<r['bid']: raise Pass13ValidationError('CROSSED_MARKET')
        if 'last' in r and r['last'] not in (None,''):
            r['last']=float(r['last']);
            if not math.isfinite(r['last']) or r['last']<=0: raise Pass13ValidationError('INVALID_LAST')
        else: r['last']=None
        if 'sequence' in r and r['sequence'] not in (None,''):
            r['sequence']=int(r['sequence'])
            if r['sequence']<0: raise Pass13ValidationError('INVALID_SEQUENCE')
        else: r['sequence']=None
        return r

class IntegrityScanner:
    def scan(self, rows, require_monotonic=False):
        if not isinstance(rows,list) or not rows: return {'status':'BLOCKED','reason':'NO_ROWS'}
        normalized=[]; seen=set(); duplicates=0; out_of_order=0; bad=[]; prev=None
        for i,row in enumerate(rows):
            try: r=CanonicalNiftySchema.normalize(row)
            except Exception as e: bad.append({'index':i,'reason':str(e)}); continue
            key=(r['timestamp'],r['instrument_token'],r['symbol'])
            if key in seen: duplicates+=1
            seen.add(key)
            ts=datetime.fromisoformat(r['timestamp'])
            if prev is not None and ts<prev: out_of_order+=1
            prev=ts
            normalized.append(r)
        if require_monotonic and out_of_order: return {'status':'BLOCKED','reason':'OUT_OF_ORDER','out_of_order':out_of_order,'duplicates':duplicates,'invalid':len(bad)}
        return {'status':'READY' if not bad else 'PARTIAL','rows':len(rows),'valid_rows':len(normalized),'invalid':len(bad),'duplicates':duplicates,'out_of_order':out_of_order,'errors':bad[:25]}

class SessionCalendar:
    # NSE F&O 2026 holidays from NSE circular NSE/FAOP/71777 (12-Dec-2025). Caller can replace/extend this set.
    HOLIDAYS_2026={
      '2026-01-26','2026-03-03','2026-03-26','2026-03-31','2026-04-03','2026-04-14','2026-05-01','2026-05-28','2026-06-26','2026-09-14','2026-10-02','2026-10-20','2026-11-10','2026-11-24','2026-12-25'
    }
    def check(self, timestamp, holidays=None):
        dt=datetime.fromisoformat(str(timestamp).replace('Z','+00:00'))
        local=dt
        if local.utcoffset() is None: raise Pass13ValidationError('TIMESTAMP_TIMEZONE_REQUIRED')
        ds=local.date().isoformat(); hs=set(holidays or self.HOLIDAYS_2026)
        weekend=local.weekday()>=5; holiday=ds in hs
        in_session=(not weekend and not holiday and SESSION_OPEN<=local.timetz().replace(tzinfo=None)<=SESSION_CLOSE)
        return {'status':'READY','date':ds,'weekday':local.strftime('%A'),'weekend':weekend,'holiday':holiday,'in_regular_session':in_session,'session_open':'09:15','session_close':'15:30','timezone':IST,'holiday_source':'NSE F&O circular NSE/FAOP/71777 (2025-12-12)' if holidays is None else 'caller_supplied'}

class ContractChain:
    def group(self, rows):
        chains=defaultdict(lambda: defaultdict(list))
        for raw in rows:
            r=CanonicalNiftySchema.normalize(raw)
            chains[r['expiry']][r['strike']].append(r)
        out=[]
        for expiry,strikes in sorted(chains.items()):
            out.append({'expiry':expiry,'strikes':sorted(strikes),'contracts':sum(len(v) for v in strikes.values()),'complete_pairs':sum(1 for v in strikes.values() if {x['option_type'] for x in v}=={'CE','PE'})})
        return {'status':'READY','expiries':out,'expiry_count':len(out)}
    def nearest(self, rows, asof):
        a=date.fromisoformat(str(asof)[:10]); exps=sorted({CanonicalNiftySchema.normalize(r)['expiry'] for r in rows}); future=[e for e in exps if date.fromisoformat(e)>=a]
        if not future:return {'status':'BLOCKED','reason':'NO_FUTURE_EXPIRY'}
        return {'status':'READY','expiry':future[0]}

class StreamingNormalizer:
    def csv_rows(self,path, dataset):
        with open(path,newline='',encoding='utf-8-sig') as f:
            for row in csv.DictReader(f):
                row['dataset']=dataset; yield CanonicalNiftySchema.normalize(row)
    def jsonl_rows(self,path,dataset):
        with open(path,encoding='utf-8') as f:
            for line_no,line in enumerate(f,1):
                if not line.strip(): continue
                try: row=json.loads(line)
                except Exception as e: raise Pass13ValidationError(f'INVALID_JSON_LINE:{line_no}') from e
                row['dataset']=dataset; yield CanonicalNiftySchema.normalize(row)

class DatasetCertifier:
    def certify(self, rows, dataset, expected_days=None, expected_expiries=None):
        scan=IntegrityScanner().scan(rows)
        if scan['status']=='BLOCKED': return {'status':'BLOCKED','reason':scan['reason']}
        norm=[CanonicalNiftySchema.normalize(r) for r in rows]
        days=len({r['timestamp'][:10] for r in norm}); exps=len({r['expiry'] for r in norm})
        coverage=1.0
        if expected_days: coverage*=min(1,days/expected_days)
        if expected_expiries: coverage*=min(1,exps/expected_expiries)
        coverage*=1 if scan['duplicates']==0 else max(0,1-scan['duplicates']/max(1,len(norm)))
        digest=hashlib.sha256(''.join(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n' for r in norm).encode()).hexdigest()
        certified=coverage>=0.999 and scan['invalid']==0 and scan['duplicates']==0
        return {'status':'CERTIFIED' if certified else 'NOT_CERTIFIED','dataset':dataset,'sha256':digest,'rows':len(norm),'days':days,'expiries':exps,'coverage_score':round(coverage,6),'integrity':scan}

class FastReplay:
    def replay(self, rows, limit=5_000_000):
        if not isinstance(rows,list): return {'status':'BLOCKED','reason':'ROWS_REQUIRED'}
        if len(rows)>limit:return {'status':'BLOCKED','reason':'EVENT_LIMIT_EXCEEDED','limit':limit}
        t0=datetime.now().timestamp(); count=0; prev=None
        for raw in rows:
            r=CanonicalNiftySchema.normalize(raw); ts=r['timestamp']
            if prev and ts<prev: return {'status':'BLOCKED','reason':'OUT_OF_ORDER'}
            prev=ts; count+=1
        elapsed=max(datetime.now().timestamp()-t0,1e-9)
        return {'status':'READY','events':count,'elapsed_seconds':elapsed,'events_per_second':round(count/elapsed,2)}
