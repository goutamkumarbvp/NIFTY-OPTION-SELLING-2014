from __future__ import annotations
from dataclasses import dataclass
from math import isfinite

@dataclass(frozen=True)
class ResearchMarginConfig:
    base_rate: float=0.20
    short_rate: float=0.10
    stress_pct: float=0.10
    max_utilization: float=0.80

class ResearchMarginEngine:
    """Conservative research estimate only; never represents NSE/Kotak margin."""
    def __init__(self,config=None): self.config=config or ResearchMarginConfig()
    @staticmethod
    def _intrinsic(typ,strike,spot):
        return max(spot-strike,0.0) if typ=='CE' else max(strike-spot,0.0)
    def estimate(self,legs,entry_prices,spot,capital):
        c=self.config
        try: spot=float(spot); capital=float(capital)
        except (TypeError,ValueError): return {'status':'BLOCKED','reason':'INVALID_MARGIN_INPUT'}
        if not isfinite(spot) or spot<=0 or not isfinite(capital) or capital<=0:return {'status':'BLOCKED','reason':'INVALID_MARGIN_INPUT'}
        if not isinstance(legs,list) or len(legs)!=len(entry_prices) or not legs:return {'status':'BLOCKED','reason':'INVALID_LEGS'}
        for l,p in zip(legs,entry_prices):
            if l.get('option_type') not in ('CE','PE') or l.get('side') not in (-1,1):return {'status':'BLOCKED','reason':'INVALID_LEG'}
            if float(l.get('strike',0))<=0 or int(l.get('qty',0))<=0 or int(l.get('lot_size',0))<=0:return {'status':'BLOCKED','reason':'INVALID_LEG'}
            if not isfinite(float(p)) or float(p)<=0:return {'status':'BLOCKED','reason':'INVALID_ENTRY_PRICE'}
        strikes=[float(l['strike']) for l in legs]
        spots=[spot*(1-c.stress_pct),spot,spot*(1+c.stress_pct)]
        worst=0.0
        for s in spots:
            pnl=0.0
            for l,p in zip(legs,entry_prices):
                qty=int(l['qty'])*int(l['lot_size']); intrinsic=self._intrinsic(l['option_type'],float(l['strike']),s)
                pnl += l['side']*(intrinsic-float(p))*qty
            worst=min(worst,pnl)
        gross=sum(abs(float(p)*int(l['qty'])*int(l['lot_size'])) for l,p in zip(legs,entry_prices))
        short_notional=sum(float(l['qty'])*int(l['lot_size'])*float(p) for l,p in zip(legs,entry_prices) if l['side']<0)
        stress_loss=max(0.0,-worst)
        estimate=max(stress_loss,gross*c.base_rate+short_notional*c.short_rate)
        utilization=estimate/capital
        return {'status':'READY','estimated_margin':estimate,'stress_loss':stress_loss,'gross_premium_notional':gross,'utilization':utilization,'allowed_utilization':c.max_utilization,'stress_spots':spots,'research_only':True}
