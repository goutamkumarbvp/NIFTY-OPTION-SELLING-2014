# V19.0 Extremely Deep Architecture / Coupling Audit

## Scope
V18.0 was refactored to separate HTTP transport from the application backend and to enforce import boundaries. This pass targets the previously identified `server.py` God-Object / transport coupling problem while preserving all existing behavior and the paper-only safety interlock.

## Changes
- Moved `TerminalBackend` and its domain/infrastructure composition out of `server.py` into `terminal_backend.py`.
- `server.py` is now an HTTP transport/composition shell: dashboard serving, HTTP parsing, route mapping, response serialization, and application startup only.
- Backend contains no HTTP server/handler code.
- Added architecture boundary tests preventing domain modules from importing `server`.
- Added tests preventing the backend from regressing into an HTTP transport module.
- Preserved legacy `from server import TerminalBackend, Handler, Audit` compatibility.
- Preserved all historical health capability fields and added `pass_19` architecture metadata.

## Measured dependency graph
Static AST scan of production Python modules:
- Production modules scanned: 36
- Production import edges: 37
- `server.py` direct production fan-out: **1** (`terminal_backend`)
- `terminal_backend.py` direct production fan-out: 34 (this remains the principal application composition point)
- Circular import edges involving `server`: none
- Domain → `server` imports: none

## Interpretation
This is a meaningful reduction in *transport coupling*: HTTP concerns no longer sit in the same module as trading/application behavior. The remaining `terminal_backend.py` fan-out is an intentional transitional composition root, not evidence that every domain module imports every other domain module. A future domain-service extraction can further reduce this concentration without changing the HTTP contract.

## Safety invariants
- `live_orders_enabled` remains hard false.
- No live order route was introduced.
- Self-repair auto-promotion remains disabled by default.
- Existing self-healing and verified code-repair mechanisms remain available.

## Verification
- Python compilation: PASS
- Full regression suite: **275/275 PASS**
- Architecture boundary tests: PASS
- Existing V18 self-repair tests: PASS
- Existing V17.x alert/self-healing tests: PASS

## Verdict
**V19.0 PASS for transport decoupling and dependency-boundary hardening.**
The largest remaining coupling hotspot is the application composition inside `terminal_backend.py`; it should be addressed in a later domain-service extraction pass rather than hidden by an import facade.
