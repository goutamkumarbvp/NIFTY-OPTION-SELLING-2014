# NIFTY Options Terminal V7.0 — Pass 7

## Scope
Historical research data validation/storage, evidence-based option bid/ask backtesting, walk-forward validation, deterministic stress scenarios and seeded Monte Carlo.

## Safety
- Live order execution remains disabled.
- Historical data is never fabricated by the research modules.
- Dataset ingestion rejects invalid OHLC, non-monotonic timestamps and duplicate dataset writes.
- Option backtest requires valid next-bar bid/ask evidence; missing quotes block the run.
- Walk-forward uses explicit train/test windows and never trains on the test window.
- Monte Carlo is seeded for reproducibility.

## Verification
- Full regression + Pass 7 tests: see audit report.
- Python compilation: PASS.
- Dashboard Pass 7 routes: PASS.
- Live execution remains disabled.
