import ast
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def imports(path):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    out=[]
    for n in ast.walk(tree):
        if isinstance(n, ast.Import): out += [a.name.split('.')[0] for a in n.names]
        elif isinstance(n, ast.ImportFrom) and n.module: out.append(n.module.split('.')[0])
    return set(out)


def test_server_is_transport_shell():
    im=imports(ROOT/'server.py')
    forbidden={'kotak_neo_adapter','market_intelligence','market_feed','risk_brain','strategy_brain','options_intelligence','quant_engine','self_repair','self_healing','alert_engine','super_ai_agent','pass17_agent_engine'}
    assert not (im & forbidden)
    assert 'terminal_backend' in im


def test_domain_modules_do_not_import_server():
    excluded={'server.py','terminal_backend.py'}
    domain_files=[p for p in ROOT.glob('*.py') if p.name not in excluded and not p.name.startswith('test_')]
    offenders=[]
    for p in domain_files:
        if 'server' in imports(p): offenders.append(p.name)
    assert offenders == []


def test_no_circular_import_edges_to_server():
    assert 'server' not in imports(ROOT/'terminal_backend.py')


def test_http_routes_are_not_duplicated_in_backend():
    text=(ROOT/'terminal_backend.py').read_text(encoding='utf-8')
    assert 'class Handler' not in text
    assert 'ThreadingHTTPServer' not in text
