from __future__ import annotations

from service_contracts import ResearchDependencies

class Research:
    """Application service boundary. Trading components are reached only through the injected context."""
    def __init__(self, ctx, deps: ResearchDependencies):
        self.ctx = ctx; self.deps = deps; c=ctx; root=c.ROOT
        c.backtester=deps.backtester; c.data_store=deps.data_store_factory(root/'runtime'/'research_data'); c.option_backtester=deps.option_backtester; c.walk_forward=deps.walk_forward
        c.option_chain_store=deps.option_chain_store_factory(root/'runtime'/'option_chain_data'); c.option_replay=deps.option_replay; c.research_margin_engine=deps.research_margin_engine; c.stress=deps.stress
        c.last_data_ingest=None; c.last_option_backtest=None; c.last_walk_forward=None; c.last_stress=None; c.last_greeks=None; c.last_surface=None; c.last_events=None; c.last_flows=None; c.last_backtest=None
        c.strategy_backtester=deps.strategy_backtester; c.strategy_optimizer=deps.strategy_optimizer_factory(c.strategy_backtester)
        c.last_strategy_backtest=None; c.last_optimization=None; c.last_robustness=None; c.last_mc_validation=None; c.last_option_ingest=None; c.last_replay=None; c.last_research_margin=None
        c.v10_store=deps.v10_store_factory(root/'runtime'/'historical_options'/'v10.sqlite3'); c.v10_calendar_engine=deps.v10_calendar; c.last_v10=None
        c.v11_registry=deps.v11_registry_factory(root/'runtime'/'historical_options'/'v11_registry.sqlite3'); c.v11_series=deps.v11_series; c.v11_query=deps.v11_query_factory(root/'runtime'/'historical_options'/'v10.sqlite3'); c.v11_quality=deps.v11_quality; c.v11_replay_engine=deps.v11_replay_engine; c.last_v11=None
        c.v12_provenance=deps.v12_provenance_factory(root/'runtime'/'historical_options'/'v12_provenance.sqlite3'); c.v12_partitions=deps.v12_partitions_factory(root/'runtime'/'historical_options'/'v12_partitions'); c.v12_coverage=deps.v12_coverage; c.v12_source=deps.v12_source; c.v12_completeness=deps.v12_completeness; c.last_v12=None
        c.v13_integrity=deps.v13_integrity; c.v13_calendar=deps.v13_calendar; c.v13_chain=deps.v13_chain; c.v13_stream=deps.v13_stream; c.v13_certifier=deps.v13_certifier; c.v13_replay_engine=deps.v13_replay_engine; c.last_v13=None

    def backtest_run(self,b=None):
        try:
            self.ctx.last_backtest=self.ctx.backtester.run(b.get('bars'),b.get('signals')); return {'ok':self.ctx.last_backtest['status']=='READY','backtest':self.ctx.last_backtest,'research_data':self.ctx.last_data_ingest,'option_backtest':self.ctx.last_option_backtest,'walk_forward':self.ctx.last_walk_forward,'stress':self.ctx.last_stress,'strategy_backtest':self.ctx.last_strategy_backtest,'optimization':self.ctx.last_optimization,'robustness':self.ctx.last_robustness,'mc_validation':self.ctx.last_mc_validation,'state':self.ctx.state(),'action':self.ctx._log('RESEARCH_BACKTEST',detail={'status':self.ctx.last_backtest['status']})}
        except Exception as e:return self.ctx._fail('RESEARCH_BACKTEST',e)

    def research_ingest(self,b=None):
        try:
            self.ctx.last_data_ingest=self.ctx.data_store.ingest(b.get('dataset'),b.get('rows'),b.get('metadata')); return {'ok':self.ctx.last_data_ingest['status']=='READY','data':self.ctx.last_data_ingest,'state':self.ctx.state(),'action':self.ctx._log('RESEARCH_DATA_INGEST', 'OK' if self.ctx.last_data_ingest['status']=='READY' else 'FAILED')}
        except Exception as e:return self.ctx._fail('RESEARCH_DATA_INGEST',e)

    def option_backtest_run(self,b=None):
        try:
            self.ctx.last_option_backtest=self.ctx.option_backtester.run(b.get('bars'),b.get('signals')); return {'ok':self.ctx.last_option_backtest['status']=='READY','backtest':self.ctx.last_option_backtest,'state':self.ctx.state(),'action':self.ctx._log('OPTIONS_BACKTEST', 'OK' if self.ctx.last_option_backtest['status']=='READY' else 'FAILED')}
        except Exception as e:return self.ctx._fail('OPTIONS_BACKTEST',e)

    def walk_forward_run(self,b=None):
        try:
            rows=b.get('rows') or []; mode=b.get('mode','split')
            if mode=='evaluate':
                score=float(b.get('score',0)); scorer=lambda train:{'score':score,'test_score':float(b.get('test_score',score))}
                out=self.ctx.walk_forward.evaluate(rows,scorer)
            else: out=self.ctx.walk_forward.split(rows)
            self.ctx.last_walk_forward=out; return {'ok':out['status']=='READY','walk_forward':out,'state':self.ctx.state(),'action':self.ctx._log('WALK_FORWARD', 'OK' if out['status']=='READY' else 'FAILED')}
        except Exception as e:return self.ctx._fail('WALK_FORWARD',e)

    def stress_run(self,b=None):
        try:
            if 'trade_pnls' in b: out=self.ctx.stress.monte_carlo(b.get('trade_pnls'))
            else: out=self.ctx.stress.deterministic(float(b.get('pnl',0)),float(b.get('delta',0)),float(b.get('gamma',0)),float(b.get('vega',0)),float(b.get('theta',0)),float(b.get('price',0)),float(b.get('vol',0)))
            self.ctx.last_stress=out; return {'ok':out['status']=='READY','stress':out,'state':self.ctx.state(),'action':self.ctx._log('STRESS_TEST', 'OK' if out['status']=='READY' else 'FAILED')}
        except Exception as e:return self.ctx._fail('STRESS_TEST',e)

    def strategy_backtest_run(self,b=None):
        try:
            out=self.ctx.strategy_backtester.run(b.get('bars'),b.get('legs'),int(b.get('entry_index',0)),b.get('expiry_index'),b.get('capital'))
            self.ctx.last_strategy_backtest=out
            return {'ok':out['status']=='READY','strategy_backtest':out,'state':self.ctx.state(),'action':self.ctx._log('MULTILEG_STRATEGY_BACKTEST','OK' if out['status']=='READY' else 'FAILED')}
        except Exception as e:return self.ctx._fail('MULTILEG_STRATEGY_BACKTEST',e)

    def optimize_run(self,b=None):
        try:
            out=self.ctx.strategy_optimizer.grid(b.get('bars'),b.get('candidate_legs'),b.get('parameter_grid'))
            self.ctx.last_optimization=out
            return {'ok':out['status']=='READY','optimization':out,'state':self.ctx.state(),'action':self.ctx._log('STRATEGY_OPTIMIZATION','OK' if out['status']=='READY' else 'FAILED')}
        except Exception as e:return self.ctx._fail('STRATEGY_OPTIMIZATION',e)

    def robustness_run(self,b=None):
        try:
            out=self.deps.robustness(b.get('pnls')); self.ctx.last_robustness=out
            return {'ok':out['status']=='READY','robustness':out,'state':self.ctx.state(),'action':self.ctx._log('STRATEGY_ROBUSTNESS','OK' if out['status']=='READY' else 'FAILED')}
        except Exception as e:return self.ctx._fail('STRATEGY_ROBUSTNESS',e)

    def mc_validation_run(self,b=None):
        try:
            out=self.deps.monte_carlo_validate(b.get('pnls'),int(b.get('paths',2000)),int(b.get('seed',17))); self.ctx.last_mc_validation=out
            return {'ok':out['status']=='READY','mc_validation':out,'state':self.ctx.state(),'action':self.ctx._log('STRATEGY_MC_VALIDATION','OK' if out['status']=='READY' else 'FAILED')}
        except Exception as e:return self.ctx._fail('STRATEGY_MC_VALIDATION',e)

    def option_chain_ingest(self,b=None):
        try:
            dataset=b.get('dataset')
            snapshots=b.get('snapshots')
            if not dataset or not isinstance(snapshots,list): raise ValueError('DATASET_AND_SNAPSHOTS_REQUIRED')
            r=self.ctx.option_chain_store.ingest(dataset,snapshots,b.get('metadata')); self.ctx.last_option_ingest=r; return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('INGEST_HISTORICAL_OPTION_CHAIN', 'OK' if r.get('status')=='READY' else 'BLOCKED', r)}
        except Exception as e:return self.ctx._fail('INGEST_HISTORICAL_OPTION_CHAIN',e)

    def option_chain_replay(self,b=None):
        try:
            r=self.ctx.option_replay.replay(b.get('snapshots'),b.get('legs'),int(b.get('entry_index',0)),b.get('exit_index'),float(b.get('capital',1000000))); self.ctx.last_replay=r; return {'ok':r.get('status')=='READY','replay':r,'state':self.ctx.state(),'action':self.ctx._log('REPLAY_OPTION_CHAIN', 'OK' if r.get('status')=='READY' else 'BLOCKED', r)}
        except Exception as e:return self.ctx._fail('REPLAY_OPTION_CHAIN',e)

    def research_margin(self,b=None):
        try:
            r=self.ctx.research_margin_engine.estimate(b.get('legs'),b.get('entry_prices'),b.get('spot'),b.get('capital',1000000)); self.ctx.last_research_margin=r; return {'ok':r.get('status')=='READY','margin':r,'state':self.ctx.state(),'action':self.ctx._log('RESEARCH_MARGIN_ESTIMATE', 'OK' if r.get('status')=='READY' else 'BLOCKED', r)}
        except Exception as e:return self.ctx._fail('RESEARCH_MARGIN_ESTIMATE',e)

    def v10_import_csv(self,b=None):
        try:
            path=b.get('path'); dataset=b.get('dataset')
            if not path or not dataset: return {'ok':False,'error':'PATH_AND_DATASET_REQUIRED','state':self.ctx.state()}
            snaps=self.deps.csv_importer.snapshots(path); r=self.ctx.v10_store.ingest(dataset,snaps,b.get('metadata')); self.ctx.last_v10=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V10_IMPORT_CSV','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V10_IMPORT_CSV',e)

    def v10_ingest(self,b=None):
        try:
            r=self.ctx.v10_store.ingest(b.get('dataset'),b.get('snapshots'),b.get('metadata')); self.ctx.last_v10=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V10_SQLITE_INGEST','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V10_SQLITE_INGEST',e)

    def v10_read(self,b=None):
        try:
            r=self.ctx.v10_store.read(b.get('dataset')); self.ctx.last_v10=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V10_SQLITE_READ','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V10_SQLITE_READ',e)

    def v10_parquet(self,b=None):
        try:
            r=self.deps.parquet_exporter.export(b.get('snapshots') or [],b.get('path','runtime/historical_options/export.parquet')); self.ctx.last_v10=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V10_PARQUET_EXPORT','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V10_PARQUET_EXPORT',e)

    def v10_calendar_check(self,b=None):
        try:
            ts=b.get('timestamp'); expiry=b.get('expiry'); r={'status':'READY','timestamp_valid':self.ctx.v10_calendar_engine.is_market_timestamp(ts) if ts else None,'expiry_valid':self.ctx.v10_calendar_engine.is_expiry_date(expiry) if expiry else None}; r['status']='BLOCKED' if (ts and not r['timestamp_valid']) or (expiry and not r['expiry_valid']) else 'READY'; return {'ok':r['status']=='READY','calendar':r,'state':self.ctx.state(),'action':self.ctx._log('V10_CALENDAR_CHECK','OK' if r['status']=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V10_CALENDAR_CHECK',e)

    def v11_register(self,b=None):
        try:
            r=self.ctx.v11_registry.register(b.get('name'),b.get('payload'),b.get('metadata')); self.ctx.last_v11=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V11_DATASET_REGISTER','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V11_DATASET_REGISTER',e)

    def v11_versions(self,b=None):
        try:
            r=self.ctx.v11_registry.list_versions(b.get('name')); self.ctx.last_v11=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V11_DATASET_VERSIONS',detail={'name':b.get('name')})}
        except Exception as e:return self.ctx._fail('V11_DATASET_VERSIONS',e)

    def v11_series_map(self,b=None):
        try:
            r=self.ctx.v11_series.series(b.get('contracts')); self.ctx.last_v11=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V11_EXPIRY_SERIES','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V11_EXPIRY_SERIES',e)

    def v11_query_snapshots(self,b=None):
        try:
            r=self.ctx.v11_query.snapshots(str(b.get('dataset')),b.get('start_ts'),b.get('end_ts'),b.get('limit',1000)); self.ctx.last_v11=r
            return {'ok':True,'data':r,'state':self.ctx.state(),'action':self.ctx._log('V11_QUERY_SNAPSHOTS',detail={'count':len(r.get('snapshots',[]))})}
        except Exception as e:return self.ctx._fail('V11_QUERY_SNAPSHOTS',e)

    def v11_query_contracts(self,b=None):
        try:
            r=self.ctx.v11_query.contracts(str(b.get('dataset')),b.get('snapshot_id'),b.get('expiry'),b.get('option_type'),b.get('limit',5000)); self.ctx.last_v11=r
            return {'ok':True,'data':r,'state':self.ctx.state(),'action':self.ctx._log('V11_QUERY_CONTRACTS',detail={'count':len(r.get('contracts',[]))})}
        except Exception as e:return self.ctx._fail('V11_QUERY_CONTRACTS',e)

    def v11_quality_score(self,b=None):
        try:
            r=self.ctx.v11_quality.score(b.get('snapshots')); self.ctx.last_v11=r
            return {'ok':r.get('status') in ('READY','DEGRADED'),'data':r,'state':self.ctx.state(),'action':self.ctx._log('V11_DATA_QUALITY','OK' if r.get('status') in ('READY','DEGRADED') else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V11_DATA_QUALITY',e)

    def v11_replay(self,b=None):
        try:
            r=self.ctx.v11_replay_engine.replay(b.get('snapshots'),b.get('signal_indices'),max_events=min(int(b.get('max_events',1000000)),1000000)); self.ctx.last_v11=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V11_HIGH_SPEED_REPLAY','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V11_HIGH_SPEED_REPLAY',e)

    def v11_soak(self,b=None):
        try:
            r=self.ctx.v11_replay_engine.soak(b.get('snapshots'),b.get('passes',3)); self.ctx.last_v11=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V11_REPLAY_SOAK','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V11_REPLAY_SOAK',e)

    def v13_normalize(self,b=None):
        try:
            rows=b.get('rows'); out=[self.deps.v13_schema.normalize(r) for r in rows] if isinstance(rows,list) else (_ for _ in ()).throw(ValueError('ROWS_REQUIRED'))
            r={'status':'READY','rows':len(out),'sample':out[:3],'schema_version':'v13.0'}; self.ctx.last_v13=r
            return {'ok':True,'data':r,'state':self.ctx.state(),'action':self.ctx._log('V13_NORMALIZE','OK',{'rows':len(out)})}
        except Exception as e:return self.ctx._fail('V13_NORMALIZE',e)

    def v13_integrity_run(self,b=None):
        try:
            r=self.ctx.v13_integrity.scan(b.get('rows'),bool(b.get('require_monotonic',False))); self.ctx.last_v13=r
            return {'ok':r.get('status') in ('READY','PARTIAL'),'data':r,'state':self.ctx.state(),'action':self.ctx._log('V13_INTEGRITY','OK' if r.get('status')!='BLOCKED' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V13_INTEGRITY',e)

    def v13_calendar_check(self,b=None):
        try:
            if not isinstance(b,dict) or not b.get('timestamp'): raise ValueError('TIMESTAMP_REQUIRED')
            r=self.ctx.v13_calendar.check(b.get('timestamp'),b.get('holidays')); self.ctx.last_v13=r
            return {'ok':True,'data':r,'state':self.ctx.state(),'action':self.ctx._log('V13_CALENDAR_CHECK','OK',r)}
        except Exception as e:return self.ctx._fail('V13_CALENDAR_CHECK',e)

    def v13_chain_group(self,b=None):
        try:
            if not isinstance(b,dict) or not isinstance(b.get('rows'),list) or not b.get('rows'): raise ValueError('ROWS_REQUIRED')
            r=self.ctx.v13_chain.group(b.get('rows')); self.ctx.last_v13=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V13_CONTRACT_CHAIN','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V13_CONTRACT_CHAIN',e)

    def v13_chain_nearest(self,b=None):
        try:
            if not isinstance(b,dict) or not isinstance(b.get('rows'),list) or not b.get('rows') or not b.get('asof'): raise ValueError('ROWS_AND_ASOF_REQUIRED')
            r=self.ctx.v13_chain.nearest(b.get('rows'),b.get('asof')); self.ctx.last_v13=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V13_NEAREST_EXPIRY','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V13_NEAREST_EXPIRY',e)

    def v13_certify(self,b=None):
        try:
            r=self.ctx.v13_certifier.certify(b.get('rows'),str(b.get('dataset','')),b.get('expected_days'),b.get('expected_expiries')); self.ctx.last_v13=r
            return {'ok':r.get('status')=='CERTIFIED','data':r,'state':self.ctx.state(),'action':self.ctx._log('V13_CERTIFY','OK' if r.get('status')=='CERTIFIED' else 'NOT_CERTIFIED',r)}
        except Exception as e:return self.ctx._fail('V13_CERTIFY',e)

    def v13_replay(self,b=None):
        try:
            r=self.ctx.v13_replay_engine.replay(b.get('rows'),int(b.get('limit',5000000))); self.ctx.last_v13=r
            return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V13_REPLAY','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V13_REPLAY',e)

    def v12_normalize(self,b=None):
        try:
            rows=b.get('rows');
            if not isinstance(rows,list) or not rows: raise ValueError('ROWS_REQUIRED')
            out=[HistoricalNormalizer.row(r) for r in rows]
            self.ctx.last_v12={'status':'READY','rows':len(out),'sample':out[:3]}
            return {'ok':True,'data':self.ctx.last_v12,'state':self.ctx.state(),'action':self.ctx._log('V12_NORMALIZE','OK',{'rows':len(out)})}
        except Exception as e:return self.ctx._fail('V12_NORMALIZE',e)

    def v12_import(self,b=None):
        try:
            rows=b.get('rows'); dataset=b.get('dataset'); source=b.get('source'); source_type=b.get('source_type','external')
            if not isinstance(rows,list) or not dataset or not source: raise ValueError('DATASET_SOURCE_ROWS_REQUIRED')
            norm=[HistoricalNormalizer.row(r) for r in rows]
            prev=None
            for r in norm:
                from datetime import datetime
                dt=datetime.fromisoformat(r['timestamp'])
                if prev and dt<=prev: raise ValueError('NON_MONOTONIC_TIMESTAMP')
                prev=dt
            lineage=self.ctx.v12_provenance.register(dataset,source,source_type,norm)
            if lineage.get('status')!='READY': return {'ok':False,'data':lineage,'state':self.ctx.state(),'action':self.ctx._log('V12_IMPORT','BLOCKED',lineage)}
            part=self.ctx.v12_partitions.write(dataset,norm)
            cov=self.ctx.v12_coverage.analyze(norm)
            self.ctx.last_v12={'status':'READY','lineage':lineage,'partitions':part,'coverage':cov}
            return {'ok':True,'data':self.ctx.last_v12,'state':self.ctx.state(),'action':self.ctx._log('V12_IMPORT','OK',{'dataset':dataset,'rows':len(norm)})}
        except Exception as e:return self.ctx._fail('V12_IMPORT',e)

    def v12_lineage(self,b=None):
        try:
            r=self.ctx.v12_provenance.get(str(b.get('dataset'))); self.ctx.last_v12=r; return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V12_LINEAGE','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V12_LINEAGE',e)

    def v12_coverage_run(self,b=None):
        try:
            r=self.ctx.v12_coverage.analyze(b.get('rows')); self.ctx.last_v12=r; return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V12_COVERAGE','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V12_COVERAGE',e)

    def v12_completeness_run(self,b=None):
        try:
            cov=self.ctx.v12_coverage.analyze(b.get('rows')); r=self.ctx.v12_completeness.score(cov,b.get('expected_days'),b.get('expected_expiries')); self.ctx.last_v12=r; return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V12_COMPLETENESS','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V12_COMPLETENESS',e)

    def v12_partition_manifest(self,b=None):
        try:
            r=self.ctx.v12_partitions.manifest(str(b.get('dataset'))); self.ctx.last_v12=r; return {'ok':r.get('status')=='READY','data':r,'state':self.ctx.state(),'action':self.ctx._log('V12_PARTITION_MANIFEST','OK' if r.get('status')=='READY' else 'BLOCKED',r)}
        except Exception as e:return self.ctx._fail('V12_PARTITION_MANIFEST',e)

    def v10_contract(self,b=None):
        c=self.deps.contract_mapper.map(b); ok=self.deps.contract_mapper.validate_nifty(c); r={'status':'READY' if ok else 'BLOCKED','contract':c.__dict__ if c else None}; return {'ok':ok,'mapping':r,'state':self.ctx.state(),'action':self.ctx._log('V10_CONTRACT_MAP','OK' if ok else 'BLOCKED',r)}
