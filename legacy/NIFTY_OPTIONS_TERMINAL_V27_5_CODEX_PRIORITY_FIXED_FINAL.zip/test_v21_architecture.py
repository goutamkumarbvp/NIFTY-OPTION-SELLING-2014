import ast
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SERVICES=('market_service.py','intelligence_service.py','research_service.py','ai_service.py')
CONCRETE={'kotak_neo_adapter','market_feed','pass14_engine','pass15_engine','market_intelligence','risk_brain','advanced_risk','strategy_brain','options_intelligence','market_regime','quant_engine','vol_surface','event_intelligence','fii_dii_intelligence','research_backtest','research_data','options_backtest','walk_forward','stress_monte_carlo','strategy_backtest','historical_option_store','options_replay','research_margin','market_data_v10','pass11_engine','pass12_engine','pass13_engine','super_ai_agent','pass17_agent_engine','alert_engine','self_repair'}

def imports(path):
 t=ast.parse(path.read_text(encoding='utf-8')); out=set()
 for n in ast.walk(t):
  if isinstance(n,ast.Import): out|={a.name.split('.')[0] for a in n.names}
  elif isinstance(n,ast.ImportFrom) and n.module: out.add(n.module.split('.')[0])
 return out

def calls(path):
 t=ast.parse(path.read_text(encoding='utf-8')); return [n.func.id for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)]

def test_services_depend_only_on_contracts_and_stdlib():
 for name in SERVICES:
  assert not (imports(ROOT/name)&CONCRETE), (name, imports(ROOT/name)&CONCRETE)

def test_composition_is_only_concrete_wiring_point():
 im=imports(ROOT/'composition.py')
 assert CONCRETE <= im

def test_no_service_cross_imports_or_backend():
 for name in SERVICES:
  im=imports(ROOT/name)
  assert not (im & {x[:-3] for x in SERVICES})
  assert 'server' not in im and 'terminal_backend' not in im

def test_backend_is_composition_only():
 im=imports(ROOT/'terminal_backend.py')
 assert {'market_service','intelligence_service','research_service','ai_service','self_healing'} <= im
 assert 'composition' not in im  # loaded through isolated composition-root loader
 assert not (im & CONCRETE)

def test_server_transport_boundary():
 im=imports(ROOT/'server.py')
 assert im <= {'terminal_backend','json','os','http','pathlib','urllib','__future__','threading','signal','runtime_config'}

def test_event_bus_is_independent():
 im=imports(ROOT/'event_bus.py')
 assert not (im & CONCRETE)
 assert 'terminal_backend' not in im and 'server' not in im

def test_service_contracts_is_independent():
 im=imports(ROOT/'service_contracts.py')
 assert not (im & CONCRETE)
 assert 'terminal_backend' not in im and 'server' not in im

def test_composition_is_the_only_concrete_wiring_module():
 for name in SERVICES:
  assert not (imports(ROOT/name)&CONCRETE)


def test_event_bus_fault_isolation():
 from event_bus import EventBus
 bus=EventBus(); seen=[]
 bus.subscribe('x', lambda p: (_ for _ in ()).throw(RuntimeError('boom')))
 bus.subscribe('x', lambda p: seen.append(p['v']))
 result=bus.publish('x', {'v': 21})
 assert result['handlers']==2 and result['failures'] and seen==[21]
