from server import Handler

class H:
    def __init__(self, origin=None, host='127.0.0.1:8500', sec=''):
        self.headers={}
        if origin is not None: self.headers['Origin']=origin
        if host is not None: self.headers['Host']=host
        if sec: self.headers['Sec-Fetch-Site']=sec
    _csrf_ok=Handler._csrf_ok

def test_cross_origin_is_rejected():
    assert H('http://evil.example')._csrf_ok() is False

def test_same_origin_is_allowed():
    assert H('http://127.0.0.1:8500')._csrf_ok() is True

def test_api_client_without_origin_remains_allowed():
    assert H()._csrf_ok() is True

def test_cross_site_fetch_without_origin_signal_is_rejected():
    assert H(sec='cross-site')._csrf_ok() is False
