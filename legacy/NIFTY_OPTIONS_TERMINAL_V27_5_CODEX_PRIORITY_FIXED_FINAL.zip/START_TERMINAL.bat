@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  python -m venv .venv
  if errorlevel 1 exit /b 1
)
call .venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
set "TRADING_MODE=paper"
set "LIVE_TRADING=false"
set "LIVE_ORDERS_ENABLED=false"
set "PORT=8500"
.venv\Scripts\python.exe -m compileall -q .
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe server.py
exit /b %errorlevel%
