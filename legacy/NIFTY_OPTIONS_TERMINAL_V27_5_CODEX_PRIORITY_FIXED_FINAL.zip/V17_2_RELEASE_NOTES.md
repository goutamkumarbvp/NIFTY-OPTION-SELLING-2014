# V17.2 — Live Alerting

## Purpose
Adds live alert delivery for stop-loss, new paper-trade candidate, black-swan/extreme move, large NIFTY movement, feed staleness/disconnect, risk blocks, broker/local reconciliation mismatch, emergency stop, and other explicitly emitted undesirable events.

## Channels
- Dashboard alert center: always enabled; polls backend every second.
- Browser notifications: user enables permission with one click.
- Telegram: optional via local `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`; secrets never appear in the dashboard.

## Safety
- Alerting has no order-placement capability.
- `LIVE_TRADING=false` remains hard enforced.
- Alerts are deduplicated with configurable cooldown.
- Market movement thresholds are configurable; defaults: 1% big move, 2% black-swan, 5-minute window.
- Feed stale default: 5 seconds.

## APIs
- `/api/alerts/recent`
- `/api/alerts/config`
- `/api/alerts/test`
- `/api/alerts/emit`

## Stop-loss
Supports both daily P&L stop-loss and per-trade stop-loss inputs in the risk evaluation path.

## Important
Telegram delivery is only active when the user configures a Telegram bot token and chat ID locally. The build test does not claim successful delivery to an external Telegram account.
