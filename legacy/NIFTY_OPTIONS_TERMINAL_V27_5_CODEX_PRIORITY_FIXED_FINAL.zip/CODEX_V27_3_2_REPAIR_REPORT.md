# V27.3.2 Codex Repair Report

## Repairs

1. Fixed `/api/health` version normalization so `VERSION.json` values such as `V27.3.2` are exposed as `v27.3.2`, not `vv27.3.2`.
2. Added `_sandbox_backend_available()` capability probing to the self-repair engine. This is fail-closed and does not introduce an unsandboxed fallback. Meta-tests now distinguish an unavailable OS sandbox from a candidate verification failure.
3. Hardened self-repair isolation tests so they only run the destructive isolation assertion when the configured OS sandbox is actually available; unavailable environments fail closed rather than producing a misleading candidate-verification failure.

## Verification performed

- Full pytest suite: 379 passed.
- Self-repair + hardening targeted suite: 19 passed.
- Actual Linux namespace sandbox capability probe: passed.
- Actual hostile candidate attempt to write `/tmp` from inside the sandbox: return code 0; host marker was not created.
- Original release archive was not modified.

## Important limitation

A passing local sandbox test does not certify every production host. Supported deployment environments must provide the required Linux namespace capability or Docker/Podman isolation. If no supported isolation backend is available, self-repair verification remains fail-closed and cannot promote a candidate.
