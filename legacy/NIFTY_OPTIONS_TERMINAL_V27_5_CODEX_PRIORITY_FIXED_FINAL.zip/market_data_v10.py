from __future__ import annotations
import csv, hashlib, json, re, sqlite3, threading
from dataclasses import dataclass, asdict
from datetime import datetime, date, time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

IST = ZoneInfo('Asia/Kolkata')

@dataclass(frozen=True)
class NiftyContract:
    symbol: str
    instrument_token: str
    exchange_segment: str
    underlying: str
    expiry: str
    strike: float
    option_type: str
    lot_size: int
    tick_size: float

class NSECalendar:
    """Conservative calendar: weekends are blocked; supplied holidays are authoritative."""
    def __init__(self, holidays=None):
        self.holidays = {self._date(x) for x in (holidays or [])}
    @staticmethod
    def _date(x):
        if isinstance(x, date): return x
        return date.fromisoformat(str(x)[:10])
    def is_trading_day(self, d):
        d=self._date(d); return d.weekday()<5 and d not in self.holidays
    def session_bounds(self, d):
        d=self._date(d)
        return datetime.combine(d,time(9,15),IST), datetime.combine(d,time(15,30),IST)
    def is_market_timestamp(self, ts):
        dt=normalize_timestamp(ts)
        if not self.is_trading_day(dt.date()): return False
        lo,hi=self.session_bounds(dt.date()); return lo <= dt <= hi
    def is_expiry_date(self, expiry):
        d=self._date(expiry); return self.is_trading_day(d)

def normalize_timestamp(ts):
    s=str(ts).strip().replace('Z','+00:00')
    dt=datetime.fromisoformat(s)
    if dt.tzinfo is None: dt=dt.replace(tzinfo=IST)
    return dt.astimezone(IST)

class ContractMapper:
    """Maps explicit normalized broker/scrip-master fields. Never guesses missing identity."""
    REQUIRED=('symbol','instrument_token','exchange_segment','underlying','expiry','strike','option_type','lot_size','tick_size')
    @classmethod
    def map(cls, row):
        try:
            opt=str(row['option_type']).upper(); expiry=str(row['expiry'])[:10]
            strike=float(row['strike']); lot=int(row['lot_size']); tick=float(row['tick_size'])
            if opt not in ('CE','PE') or strike<=0 or lot<=0 or tick<=0: raise ValueError
            date.fromisoformat(expiry)
            vals={k:str(row[k]).strip() for k in ('symbol','instrument_token','exchange_segment','underlying')}
            if any(not v for v in vals.values()): raise ValueError
            return NiftyContract(**vals,expiry=expiry,strike=strike,option_type=opt,lot_size=lot,tick_size=tick)
        except (KeyError,TypeError,ValueError,OverflowError):
            return None
    @classmethod
    def validate_nifty(cls, c):
        return bool(c and c.underlying.upper()=='NIFTY' and c.exchange_segment.lower() in {'nse_fo','nse_fo'} and c.option_type in ('CE','PE'))

class OptionChainSQLiteStore:
    """Immutable normalized historical option-chain store with SQLite transactions and dataset digest."""
    def __init__(self, path='runtime/historical_options/v10.sqlite3'):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self.lock=threading.RLock(); self._init()
    def _connect(self):
        c=sqlite3.connect(self.path, timeout=10, isolation_level=None); c.row_factory=sqlite3.Row; return c
    def _init(self):
        with self.lock:
            c=self._connect(); c.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS datasets(name TEXT PRIMARY KEY, created_at TEXT NOT NULL, row_count INTEGER NOT NULL, contract_count INTEGER NOT NULL, sha256 TEXT NOT NULL, metadata_json TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS snapshots(dataset TEXT NOT NULL, snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, spot REAL NOT NULL, expiry TEXT NOT NULL, UNIQUE(dataset,ts), FOREIGN KEY(dataset) REFERENCES datasets(name));
            CREATE TABLE IF NOT EXISTS contracts(dataset TEXT NOT NULL, snapshot_id INTEGER NOT NULL, symbol TEXT NOT NULL, instrument_token TEXT NOT NULL, exchange_segment TEXT NOT NULL, underlying TEXT NOT NULL, expiry TEXT NOT NULL, strike REAL NOT NULL, option_type TEXT NOT NULL, bid REAL NOT NULL, ask REAL NOT NULL, oi REAL NOT NULL, volume REAL NOT NULL, UNIQUE(dataset,snapshot_id,symbol,option_type,strike,expiry), FOREIGN KEY(snapshot_id) REFERENCES snapshots(snapshot_id));
            CREATE INDEX IF NOT EXISTS idx_snap_ds_ts ON snapshots(dataset,ts); CREATE INDEX IF NOT EXISTS idx_contract_ds_snap ON contracts(dataset,snapshot_id);
            '''); c.close()
    @staticmethod
    def _digest(snaps):
        raw=''.join(json.dumps(s,sort_keys=True,separators=(',',':'))+'\n' for s in snaps).encode(); return hashlib.sha256(raw).hexdigest()
    def ingest(self,dataset,snapshots,metadata=None):
        name=re.sub(r'[^A-Za-z0-9_-]','',str(dataset)) or 'dataset'
        if not isinstance(snapshots,list) or not snapshots: return {'status':'BLOCKED','reason':'NO_SNAPSHOTS'}
        prev=None; normalized=[]; count=0; cal=NSECalendar()
        try:
            for s in snapshots:
                dt=normalize_timestamp(s['timestamp']); spot=float(s['spot']); expiry=str(s['expiry'])[:10]
                if prev and dt<=prev: return {'status':'BLOCKED','reason':'NON_MONOTONIC_TIMESTAMP'}
                if spot<=0 or not cal.is_expiry_date(expiry): return {'status':'BLOCKED','reason':'INVALID_EXPIRY_OR_SPOT'}
                prev=dt; out=[]; seen=set()
                for raw in s['contracts']:
                    c=ContractMapper.map(raw)
                    if not ContractMapper.validate_nifty(c): return {'status':'BLOCKED','reason':'INVALID_NIFTY_CONTRACT'}
                    if c.expiry!=expiry: return {'status':'BLOCKED','reason':'EXPIRY_MISMATCH'}
                    bid=float(raw['bid']); ask=float(raw['ask']); oi=float(raw.get('oi',0)); vol=float(raw.get('volume',0))
                    if not (bid>0 and ask>=bid and oi>=0 and vol>=0): return {'status':'BLOCKED','reason':'INVALID_QUOTE'}
                    key=(c.symbol,c.option_type,c.strike,c.expiry)
                    if key in seen:return {'status':'BLOCKED','reason':'DUPLICATE_CONTRACT'}
                    seen.add(key); out.append((c,bid,ask,oi,vol)); count+=1
                normalized.append((dt,spot,expiry,out))
        except (KeyError,TypeError,ValueError,OverflowError): return {'status':'BLOCKED','reason':'INVALID_SNAPSHOT'}
        digest=self._digest(snapshots)
        with self.lock:
            c=self._connect()
            try:
                c.execute('BEGIN IMMEDIATE')
                if c.execute('SELECT 1 FROM datasets WHERE name=?',(name,)).fetchone(): c.execute('ROLLBACK'); return {'status':'BLOCKED','reason':'DATASET_EXISTS'}
                c.execute('INSERT INTO datasets VALUES(?,?,?,?,?,?)',(name,datetime.now(IST).isoformat(),len(normalized),count,digest,json.dumps(metadata or {},sort_keys=True)))
                for dt,spot,expiry,contracts in normalized:
                    cur=c.execute('INSERT INTO snapshots(dataset,ts,spot,expiry) VALUES(?,?,?,?)',(name,dt.isoformat(),spot,expiry)); sid=cur.lastrowid
                    for cc,bid,ask,oi,vol in contracts:
                        c.execute('INSERT INTO contracts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(name,sid,cc.symbol,cc.instrument_token,cc.exchange_segment,cc.underlying,cc.expiry,cc.strike,cc.option_type,bid,ask,oi,vol))
                c.execute('COMMIT')
            except Exception:
                c.execute('ROLLBACK'); raise
            finally: c.close()
        return {'status':'READY','dataset':name,'snapshots':len(normalized),'contracts':count,'sha256':digest,'storage':'sqlite','path':str(self.path)}
    def read(self,dataset):
        name=re.sub(r'[^A-Za-z0-9_-]','',str(dataset)) or 'dataset'
        with self.lock:
            c=self._connect(); ds=c.execute('SELECT * FROM datasets WHERE name=?',(name,)).fetchone()
            if not ds: c.close(); return {'status':'BLOCKED','reason':'DATASET_NOT_FOUND'}
            snaps=[]
            for s in c.execute('SELECT * FROM snapshots WHERE dataset=? ORDER BY ts',(name,)).fetchall():
                contracts=[]
                for r in c.execute('SELECT * FROM contracts WHERE dataset=? AND snapshot_id=? ORDER BY strike,option_type',(name,s['snapshot_id'])):
                    contracts.append({k:r[k] for k in ('symbol','instrument_token','exchange_segment','underlying','expiry','strike','option_type','bid','ask','oi','volume')})
                snaps.append({'timestamp':s['ts'],'spot':s['spot'],'expiry':s['expiry'],'contracts':contracts})
            c.close()
        return {'status':'READY','dataset':name,'rows':snaps,'snapshots':len(snaps),'contracts':sum(len(x['contracts']) for x in snaps),'sha256':ds['sha256'],'storage':'sqlite'}

class CSVOptionChainImporter:
    """Strict CSV adapter. It only maps known aliases and requires broker identity fields."""
    ALIASES={'timestamp':'timestamp','ts':'timestamp','spot':'spot','underlying_price':'spot','expiry':'expiry','symbol':'symbol','trading_symbol':'symbol','instrument_token':'instrument_token','token':'instrument_token','exchange_segment':'exchange_segment','segment':'exchange_segment','underlying':'underlying','strike':'strike','option_type':'option_type','side':'option_type','lot_size':'lot_size','tick_size':'tick_size','bid':'bid','best_bid':'bid','ask':'ask','best_ask':'ask','oi':'oi','open_interest':'oi','volume':'volume'}
    @classmethod
    def read(cls,path):
        rows=[]
        with open(path,newline='',encoding='utf-8-sig') as f:
            for row in csv.DictReader(f): rows.append({cls.ALIASES.get(k.strip().lower(),k.strip().lower()):v for k,v in row.items()})
        return rows
    @classmethod
    def snapshots(cls,path):
        rows=cls.read(path); grouped={}
        for r in rows:
            key=(str(r['timestamp']),str(r['expiry'])[:10]); grouped.setdefault(key,{'timestamp':r['timestamp'],'spot':float(r['spot']),'expiry':key[1],'contracts':[]})['contracts'].append(r)
        return [grouped[k] for k in sorted(grouped)]

class ParquetExporter:
    @staticmethod
    def export(snapshots,path):
        try:
            import pandas as pd
            rows=[]
            for s in snapshots:
                for c in s['contracts']:
                    r={'timestamp':s['timestamp'],'spot':s['spot'],**c}; rows.append(r)
            pd.DataFrame(rows).to_parquet(path,index=False)
            return {'status':'READY','path':str(path),'rows':len(rows),'format':'parquet'}
        except ImportError:return {'status':'BLOCKED','reason':'PARQUET_ENGINE_UNAVAILABLE'}
        except Exception as e:return {'status':'BLOCKED','reason':'PARQUET_EXPORT_FAILED','detail':type(e).__name__}
