# NIFTY Options Terminal V27.3 — Complete Dashboard Release

V27.3 is a read-only/paper-trading NIFTY options terminal with Kotak Neo market-data connectivity, options/OI/PCR intelligence, risk/strategy/research services, agentic analysis, runtime self-healing, verified code self-repair, alerts, and the V27 dashboard.

## Safety
- `LIVE_TRADING=false` is the required/default safety state.
- Live order placement is not exposed by this release.
- Self-repair is sandbox-first; automatic promotion is disabled by default.
- Credentials belong only in a local `.env`/environment and must never be committed.

## Install
```bash
python -m pip install -r requirements.txt
```

## Run locally
```bash
python server.py
```
Then open `http://127.0.0.1:8500/`.

## Tests
```bash
pytest -q
```

## Important deployment status
This package is **not a public/internet-facing production deployment bundle**: the built-in server is intentionally localhost-only and has no authentication/TLS layer. It is suitable for a controlled workstation/paper-trading deployment. Public/cloud deployment requires a hardened reverse proxy, authentication, TLS, secret management, process supervision, monitoring, and an explicit security review.

## AI status
The package contains an `ExtremeSuperAgent` and a Pass-17 agentic research core. They are deterministic/evidence-driven agent components, not a general-purpose autonomous LLM/Codex. The verified code self-repair engine can diagnose known failure signatures and validate supplied/provider patches, but its default offline provider does not invent arbitrary fixes.


## V27.1 Paper Auto Self-Repair
Use `START_PAPER_MODE.bat` (Windows), `START_PAPER_MODE.ps1`, or `START_PAPER_MODE.sh` to run the isolated paper auto-repair profile. It forces paper-only execution and enables automatic promotion only after sandbox verification. Live-mode auto-promotion is hard-blocked by policy.


## V27.3 — AI-assisted paper repair provider

V27.3 can use the OpenAI Responses API as an optional repair/reasoning provider. It is **disabled by default** and no API key is bundled. Configure locally in `.env`:

```text
LLM_GATEWAY_ENABLED=true
LLM_PROVIDER=openai
LLM_MODEL=gpt-5.6-sol
LLM_API_KEY=<your local key>
REPAIR_LLM_ENABLED=true
REPAIR_LLM_MODEL=gpt-5.6-sol
PAPER_AUTO_SELF_REPAIR=true
SELF_REPAIR_AUTO_PROMOTE=false
TRADING_MODE=paper
LIVE_TRADING=false
LIVE_ORDERS_ENABLED=false
```

The LLM can propose code only. The existing sandbox, compile, full-test, security, promotion and rollback gates remain authoritative. Live mode cannot use automatic repair promotion. Never put API keys in chat or source control.
