# V27 Paper Auto Self-Repair

Paper Mode can automatically promote a **verified** repair, while Live Mode is hard-blocked.

## Paper launcher policy
The dedicated paper launchers force:
- `TRADING_MODE=paper`
- `LIVE_TRADING=false`
- `LIVE_ORDERS_ENABLED=false`
- `PAPER_AUTO_SELF_REPAIR=true`
- `SELF_REPAIR_AUTO_PROMOTE=false`
- localhost binding

Promotion still requires the V27 sandbox compile, full test, and security gates to pass.

## Live isolation
Auto-promotion is allowed only when `TRADING_MODE=paper`, `LIVE_TRADING` is not true,
and `LIVE_ORDERS_ENABLED` is not true. Merely leaving `SELF_REPAIR_AUTO_PROMOTE=false`
in an environment cannot authorize live promotion.

The repair engine cannot modify `.env`/secret files and rejects attempts to enable
`LIVE_TRADING`, `live_orders_enabled`, or add an order-placement function.

## Important limitation
The automatic loop can only repair incidents for which a configured repair provider
can generate a patch. The default offline provider is intentionally conservative and
does not claim to be a general autonomous programmer. Runtime self-healing and verified
code self-repair remain separate mechanisms.
