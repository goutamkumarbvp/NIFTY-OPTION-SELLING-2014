from __future__ import annotations
from dataclasses import dataclass, asdict
from math import isfinite, sqrt
from statistics import mean
from typing import Any

@dataclass(frozen=True)
class BacktestConfig:
    initial_capital:float=1_000_000.0
    fee_per_trade:float=20.0
    slippage_pct:float=0.0005
    risk_fraction:float=0.01

class ResearchBacktester:
    """Long-only bar backtester. Signals are evaluated on bar t and filled on t+1, preventing look-ahead."""
    def __init__(self,config=None):self.config=config or BacktestConfig();self.last={'status':'NO_DATA'}
    def run(self,bars:list[dict],signals:list[int]|None=None)->dict[str,Any]:
        if not isinstance(bars,list) or len(bars)<3:return self._set({'status':'BLOCKED','reason':'INSUFFICIENT_BARS'})
        clean=[]
        for b in bars:
            try:
                o=float(b['open']); c=float(b['close']);
                if o<=0 or c<=0 or not all(isfinite(x) for x in (o,c)):continue
                clean.append({'open':o,'close':c,'timestamp':b.get('timestamp')})
            except (KeyError,TypeError,ValueError):continue
        if len(clean)<3:return self._set({'status':'BLOCKED','reason':'NO_VALID_BARS'})
        sig=signals if signals is not None else [0]*len(clean)
        if len(sig)!=len(clean):return self._set({'status':'BLOCKED','reason':'SIGNAL_LENGTH_MISMATCH'})
        capital=self.config.initial_capital; equity=[capital]; trades=[]; pos=0; entry=0
        for i in range(len(clean)-1):
            s=int(sig[i])
            if s not in (-1,0,1):return self._set({'status':'BLOCKED','reason':'INVALID_SIGNAL'})
            if pos==0 and s==1:
                fill=clean[i+1]['open']*(1+self.config.slippage_pct); pos=1; entry=fill; trades.append({'entry_index':i+1,'entry':fill})
            elif pos==1 and s==-1:
                fill=clean[i+1]['open']*(1-self.config.slippage_pct); pnl=fill-entry-self.config.fee_per_trade; capital+=pnl; trades[-1].update({'exit_index':i+1,'exit':fill,'pnl':pnl}); pos=0
            equity.append(capital)
        if pos: # mark open position, do not pretend it was closed
            mark=clean[-1]['close']; trades[-1].update({'open':True,'mark':mark,'unrealized':mark-entry})
        peak=equity[0]; maxdd=0
        for e in equity:peak=max(peak,e);maxdd=max(maxdd,(peak-e)/peak if peak else 0)
        closed=[t for t in trades if 'pnl' in t]; wins=sum(t['pnl']>0 for t in closed); rets=[t['pnl']/self.config.initial_capital for t in closed]
        sharpe=(mean(rets)/((sum((x-mean(rets))**2 for x in rets)/max(1,len(rets)-1))**0.5)*sqrt(len(rets))) if len(rets)>=2 and len(set(rets))>1 else 0.0
        return self._set({'status':'READY','initial_capital':self.config.initial_capital,'final_capital':capital,'closed_trades':len(closed),'open_trades':len(trades)-len(closed),'win_rate':wins/len(closed) if closed else 0.0,'total_pnl':capital-self.config.initial_capital,'max_drawdown_pct':maxdd,'sharpe':sharpe,'trades':trades,'equity_curve':equity,'lookahead_protection':'signal_t_fills_bar_t_plus_1'})
    def _set(self,x):self.last=x;return x
    def health(self):return {'healthy':self.last.get('status')=='READY','config':asdict(self.config),'last_status':self.last.get('status')}
