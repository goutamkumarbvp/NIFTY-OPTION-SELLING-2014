from __future__ import annotations
import os, re, time, hashlib
from urllib.parse import unquote
from dataclasses import dataclass
from typing import Optional

SCHEMA_VERSION='v14.0'

class Pass14SafetyError(ValueError): pass

_SECRET_KEYS=('NEO_CONSUMER_KEY','NEO_MPIN','NEO_TOTP_SECRET','NEO_PASSWORD','NEO_API_SECRET','LIVE_CONFIRM')

@dataclass(frozen=True)
class KotakReadOnlyConfig:
    consumer_key: str
    mobile_number: str
    ucc: str
    mpin: str
    totp_secret: Optional[str] = None
    environment: str = 'prod'
    live_trading: bool = False

    @classmethod
    def from_env(cls, env=None):
        e=os.environ if env is None else env
        live=str(e.get('LIVE_TRADING','false')).strip().lower()=='true'
        # Pass 14 deliberately refuses live mode. This is a research/read-only adapter.
        if live:
            raise Pass14SafetyError('LIVE_TRADING_MUST_REMAIN_FALSE_IN_PASS14')
        vals={k:str(e.get(k,'' )).strip() for k in ('NEO_CONSUMER_KEY','NEO_MOBILE_NUMBER','NEO_UCC','NEO_MPIN','NEO_TOTP_SECRET')}
        return cls(vals['NEO_CONSUMER_KEY'],vals['NEO_MOBILE_NUMBER'],vals['NEO_UCC'],vals['NEO_MPIN'],vals['NEO_TOTP_SECRET'] or None,str(e.get('NEO_ENVIRONMENT','prod')),False)

    def validate(self):
        if not self.consumer_key: raise Pass14SafetyError('MISSING_NEO_CONSUMER_KEY')
        if not self.mobile_number: raise Pass14SafetyError('MISSING_NEO_MOBILE_NUMBER')
        if not self.ucc: raise Pass14SafetyError('MISSING_NEO_UCC')
        if not self.mpin: raise Pass14SafetyError('MISSING_NEO_MPIN')
        if self.live_trading is not False: raise Pass14SafetyError('LIVE_TRADING_NOT_FALSE')
        return True


def redact(value: object, key: str='') -> str:
    s='' if value is None else str(value)
    k=key.upper()
    if any(x in k for x in _SECRET_KEYS): return '***REDACTED***' if s else ''
    if len(s)>8 and ('KEY' in k or 'TOKEN' in k or 'SECRET' in k): return s[:3]+'…'+s[-3:]
    return s


def redacted_env(env=None):
    e=os.environ if env is None else env
    return {k:redact(v,k) for k,v in e.items() if k.startswith('NEO_') or k in ('LIVE_TRADING','LIVE_CONFIRM')}


def generate_totp(secret: str) -> str:
    if not secret: raise Pass14SafetyError('TOTP_SECRET_REQUIRED')
    try:
        import pyotp
        return pyotp.TOTP(secret).now()
    except ImportError as exc:
        raise Pass14SafetyError('PYOTP_REQUIRED_FOR_TOTP_GENERATION') from exc

@dataclass
class ConnectionState:
    authenticated: bool = False
    feed_connected: bool = False
    market_status: str = 'UNKNOWN'
    last_tick_at: float = 0.0
    last_error: str = ''
    reconnects: int = 0
    subscribed_tokens: int = 0
    auth_at: float = 0.0

    def snapshot(self, freshness_seconds=10):
        age=None if not self.last_tick_at else max(0,time.time()-self.last_tick_at)
        return {
            'authenticated':self.authenticated,
            'feed_connected':self.feed_connected,
            'market_status':self.market_status,
            'last_tick_age_seconds':None if age is None else round(age,3),
            'feed_fresh':bool(self.feed_connected and age is not None and age<=freshness_seconds),
            'last_error':self.last_error,
            'reconnects':self.reconnects,
            'subscribed_tokens':self.subscribed_tokens,
            'auth_age_seconds':None if not self.auth_at else round(max(0,time.time()-self.auth_at),3),
            'live_orders_enabled':False,
        }

class ReadOnlyGate:
    """Hard application-level interlock: no order-placement capability is exposed."""
    FORBIDDEN=('place_order','modify_order','cancel_order','cancel_all','amo_order')
    def validate_adapter(self, adapter):
        for name in self.FORBIDDEN:
            if callable(getattr(adapter,name,None)):
                raise Pass14SafetyError(f'LIVE_ORDER_METHOD_PRESENT:{name}')
        return True
    def assert_paper(self, live_trading):
        if live_trading is not False: raise Pass14SafetyError('LIVE_TRADING_NOT_FALSE')
        return True

class ReadOnlyConnectionManager:
    def __init__(self, config: KotakReadOnlyConfig):
        config.validate(); self.config=config; self.state=ConnectionState(); self.client=None
        self.gate=ReadOnlyGate()
    def load(self):
        try:
            from neo_api_client import NeoAPI
        except ImportError as exc:
            raise RuntimeError('INSTALL kotakneoapi==3.0.6') from exc
        self.client=NeoAPI(consumer_key=self.config.consumer_key, environment=self.config.environment)
        # The raw SDK intentionally has order methods; Pass 14 never exposes that client to the UI/API.
        return self.client
    def authenticate(self, totp=None):
        if not self.client: self.load()
        code=totp or generate_totp(unquote(self.config.totp_secret or ''))
        login=self.client.totp_login(mobile_number=self.config.mobile_number, ucc=self.config.ucc, totp=code)
        validate=self.client.totp_validate(mpin=self.config.mpin)
        self.state.authenticated=True; self.state.auth_at=time.time(); self.state.last_error=''
        return {'login':self._status(login),'validate':self._status(validate),'live_orders_enabled':False}
    @staticmethod
    def _status(x):
        if isinstance(x,dict):
            if x.get('stat')=='Not_Ok' or x.get('error'): return 'ERROR'
            return x.get('stat') or x.get('status') or 'OK'
        return 'OK'
    def require_auth(self):
        if not self.client or not self.state.authenticated: raise RuntimeError('NOT_AUTHENTICATED')
    def read_positions(self): self.require_auth(); return self.client.positions()
    def read_holdings(self): self.require_auth(); return self.client.holdings()
    def read_limits(self): self.require_auth(); return self.client.limits()
    def read_expiries(self, **kwargs): self.require_auth(); return self.client.expiries(**kwargs)
    def read_option_chain(self, **kwargs): self.require_auth(); return self.client.option_chain(**kwargs)
    def read_quotes(self, **kwargs): self.require_auth(); return self.client.quotes(**kwargs)

class TickQuality:
    def __init__(self): self.last_sequence=None; self.duplicates=0; self.out_of_order=0; self.invalid=0; self.total=0
    def observe(self, tick):
        self.total+=1
        seq=getattr(tick,'local_sequence',None)
        if seq is not None:
            if self.last_sequence is not None and seq==self.last_sequence: self.duplicates+=1
            if self.last_sequence is not None and seq<self.last_sequence: self.out_of_order+=1
            self.last_sequence=seq
        ltp=getattr(tick,'ltp',None)
        if ltp is None or ltp<=0: self.invalid+=1
    def snapshot(self):
        return {'total':self.total,'duplicates':self.duplicates,'out_of_order':self.out_of_order,'invalid':self.invalid,'last_sequence':self.last_sequence,'status':'GOOD' if self.total and not self.duplicates and not self.out_of_order and not self.invalid else ('WAITING' if not self.total else 'DEGRADED')}
