# V27.3 P0-1 / P0-2 Repair Report

## Safety
- Paper/read-only only.
- `LIVE_TRADING=false` and `LIVE_ORDERS_ENABLED=false` retained.
- No real broker credentials, orders, positions, funds, or OpenAI credentials used.

## P0-1 — Paper P&L fill-level accounting
### Before
Paper P&L aggregated fills by side using simple average prices. A multi-fill close could therefore produce incorrect realized P&L.

### After
`PaperExecutionLedger` now reconstructs fills chronologically and performs FIFO matching at fill level. Realized P&L is calculated for each matched quantity; remaining lots drive unrealized P&L.

### Evidence
- `SELL 50 @ 100`
- `SELL 100 @ 120`
- `BUY 150 @ 90`
- Expected/observed realized P&L: `₹3500`
- Partial reversal test: `BUY 100 @ 100`, `SELL 150 @ 120`, mark at `110` => realized `₹2000`, unrealized `₹500`, total `₹2500`.

## P0-2 — Invalid OI / volume gate
### Before
Negative OI or volume could enter `OptionsIntelligence` and influence PCR, support/resistance, and liquidity calculations.

### After
`OptionsIntelligence.analyze()` fail-closes with `BLOCKED / INVALID_MARKET_DATA` when supplied OI or volume is negative.

### Evidence
- Negative CE OI => BLOCKED
- Negative CE volume => BLOCKED

## Validation
- Targeted tests: `31 passed`
- Full suite after repair: `332 passed in 27.79s`
- `compileall`: PASS
- Independent security verifier: PASS, zero violations
- Live flag safety test: startup rejected `LIVE_TRADING=true`
