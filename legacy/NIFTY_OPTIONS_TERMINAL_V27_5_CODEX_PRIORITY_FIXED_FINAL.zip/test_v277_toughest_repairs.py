import time
from types import SimpleNamespace


def _ready_feed(tb, symbol='NIFTY', price=100.0, age=0.2):
    class State:
        def snapshot(self):
            return {'connected': True, 'age': age, 'local_sequence': 1, 'market_status': 'OPEN'}
    tb.feed = SimpleNamespace(state=State())
    tb.ticks[('nse_fo','paper')] = SimpleNamespace(
        trading_symbol=symbol, instrument_token='paper', ltp=price,
        timestamp=time.time()-age)


def _stop(tb):
    if getattr(tb,'_auto_repair_stop',None): tb._auto_repair_stop.set()
    if getattr(tb,'self_healing',None): tb.self_healing.stop()


def test_client_limits_and_daily_pnl_are_ignored(tmp_path, monkeypatch):
    import terminal_backend
    monkeypatch.setattr(terminal_backend, 'ROOT', tmp_path)
    tb=terminal_backend.TerminalBackend()
    try:
        r=tb.risk_evaluate({'limits':{'data':{'availableMargin':1e12,'marginUsed':0}}, 'daily_pnl':0, 'order':{'side':'BUY','quantity':1500,'price':100}})
        assert r['ok']
        assert r['decision']['decision']=='BLOCK'
        assert 'MARGIN_UTILIZATION_LIMIT_EXCEEDED' in r['decision']['reasons']
    finally: _stop(tb)


def test_paper_order_requires_fresh_market_data(tmp_path, monkeypatch):
    import terminal_backend
    monkeypatch.setattr(terminal_backend, 'ROOT', tmp_path)
    tb=terminal_backend.TerminalBackend()
    try:
        rr=tb.risk_evaluate({'limits':{'data':{'availableMargin':1e12,'marginUsed':0}}, 'daily_pnl':0, 'order':{'side':'BUY','quantity':75,'price':100}})
        assert rr['decision']['decision']=='ALLOW_PAPER'
        r=tb.paper_order({'symbol':'NIFTY','side':'BUY','quantity':75,'fill_price':100})
        assert not r['ok'] and 'PAPER_MARKET_DATA_NOT_FRESH' in r['error']
        assert tb.paper_ledger.orders()==[]
    finally: _stop(tb)


def test_paper_order_uses_trusted_tick_price(tmp_path, monkeypatch):
    import terminal_backend
    monkeypatch.setattr(terminal_backend, 'ROOT', tmp_path)
    tb=terminal_backend.TerminalBackend()
    try:
        _ready_feed(tb, 'NIFTY', 100.0)
        rr=tb.risk_evaluate({'limits':{'data':{'availableMargin':1e12,'marginUsed':0}}, 'daily_pnl':0, 'order':{'side':'BUY','quantity':75,'price':100}})
        assert rr['decision']['decision']=='ALLOW_PAPER'
        r=tb.paper_order({'symbol':'NIFTY','side':'BUY','quantity':75,'fill_price':500})
        assert not r['ok'] and 'FILL_PRICE_MISMATCH_MARKET' in r['error']
        assert tb.paper_ledger.orders()==[]
        r=tb.paper_order({'symbol':'NIFTY','side':'BUY','quantity':75,'fill_price':100})
        assert r['ok'] and r['data']['avg_fill_price']==100.0
    finally: _stop(tb)


def test_risk_health_invalid_snapshot_is_not_healthy():
    from risk_brain import RiskBrain, RiskSnapshot
    rb=RiskBrain()
    bad=RiskSnapshot(float('nan'),0,0,100000,0,0,0)
    assert rb.health(bad)['healthy'] is False


def test_concurrent_paper_orders_cannot_bypass_risk_limit(tmp_path, monkeypatch):
    import concurrent.futures
    import terminal_backend
    monkeypatch.setattr(terminal_backend, 'ROOT', tmp_path)
    tb=terminal_backend.TerminalBackend()
    try:
        _ready_feed(tb, 'NIFTY', 100.0)
        rr=tb.risk_evaluate({'limits':{'data':{'availableMargin':1e12,'marginUsed':0}}, 'daily_pnl':0, 'order':{'side':'BUY','quantity':75,'price':100}})
        assert rr['decision']['decision']=='ALLOW_PAPER'
        with concurrent.futures.ThreadPoolExecutor(max_workers=40) as ex:
            results=list(ex.map(lambda _: tb.paper_order({'symbol':'NIFTY','side':'BUY','quantity':75,'fill_price':100}), range(40)))
        filled=sum(1 for r in results if r.get('ok'))
        positions=tb.paper_ledger.positions()
        qty=positions[0]['net_quantity'] if positions else 0
        assert filled <= 10
        assert qty <= 750
        assert any(not r.get('ok') for r in results)
    finally: _stop(tb)
