# NIFTY OPTIONS TERMINAL V4.0 — PASS 4

## Strategy Brain / Deterministic Trade-Plan Engine

Pass 4 upgrades V3.0 with a deterministic Strategy Brain. It consumes the normalized option chain, observable OI/ΔOI, PCR, strike grid, spot and market-regime evidence and produces ranked candidate strategies.

### Safety boundaries
- Strategy Brain never places broker orders.
- Every candidate carries `risk_gate_required=true`.
- Execution remains `DISABLED`.
- Missing/insufficient chain or spot evidence fails closed.
- No synthetic price, PCR, IV rank or regime values are introduced by Strategy Brain.

### Backend-wired controls
- `POST /api/strategy/analyze`
- `POST /api/strategy/health`
- Existing `POST /api/trade-plan` now delegates to the Strategy Brain rather than returning a static placeholder.

### Candidate logic
- Short Put candidate when bullish/neutral evidence supports put-side selling.
- Short Call candidate when bearish/neutral evidence supports call-side selling.
- Iron Condor candidate when evidence is neutral and both sides are available.
- Data-quality and evidence scoring is deterministic and configurable.

### Verification
- Full test suite: **34/34 PASS**
- Python compilation: **PASS**
- Dashboard API-route wiring scan: **PASS**
- No `place_order` path in server: **PASS**
- Execution remains locked: **PASS**
