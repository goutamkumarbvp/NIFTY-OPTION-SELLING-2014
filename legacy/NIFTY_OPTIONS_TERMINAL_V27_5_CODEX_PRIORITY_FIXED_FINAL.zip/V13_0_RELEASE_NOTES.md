# NIFTY OPTIONS TERMINAL — PASS 13

## Objective
Turn the V12 historical-data foundation into a stricter canonical NIFTY research-data layer suitable for large historical datasets and deterministic replay, while keeping live order execution disabled.

## Added
- Canonical NIFTY option record schema (`pass13_engine.py`)
- Strict timezone/identity/quote/OI/volume validation
- Duplicate, invalid-row and out-of-order detection
- NSE F&O 2026 regular-session calendar baseline from NSE circular NSE/FAOP/71777
- Explicit contract-chain grouping across expiries/strikes and nearest-future-expiry selection
- Streaming CSV/JSONL normalizer primitives
- Dataset certification with SHA-256 content digest and integrity score
- Bounded fast replay engine with order-preserving validation and throughput measurement
- 7 backend API routes under `/api/research/v13/*`
- Pass 13 dashboard controls

## Safety
- Paper/research only.
- `live_orders_enabled` remains `false`.
- No `place_order()` definitions found.
- No `live_orders_enabled=True` assignment found.
- Existing Kotak integration remains read-only.

## Verification
- Full regression: **189/189 PASS**
- Pass 13 tests: **17/17 PASS**
- Python compileall: **PASS**
- HTTP smoke: **PASS** for health + all 7 Pass 13 routes
- Dashboard scan: **97 unique IDs / 63 handlers / 0 missing handler IDs**
- Safety static scan: **0 live order definitions / 0 live_orders_enabled=True**

## Important limitation
This pass does **not** create historical market data and does not claim that a dataset is complete merely because it is syntactically valid. Certification requires the supplied dataset to pass integrity checks and the requested expected-day/expiry coverage. Exchange holiday/session rules should be refreshed from current NSE notices before any production research certification.

## GO / NO-GO
- Historical data engineering: **GO**
- Deterministic replay research: **GO**
- Production historical performance claims without an authorized dataset: **NO-GO**
- Live trading: **NO-GO**
- Autonomous trading: **ABSOLUTE NO-GO**
