import os, tempfile, time
from types import SimpleNamespace
from pathlib import Path
os.environ.setdefault('TRADING_MODE','paper')
os.environ.setdefault('LIVE_TRADING','false')
os.environ.setdefault('LIVE_ORDERS_ENABLED','false')

def _tb(tmp_path, monkeypatch):
    import terminal_backend
    monkeypatch.setattr(terminal_backend, "ROOT", tmp_path)
    return terminal_backend.TerminalBackend()

def _ready_feed(tb, symbol='NIFTY', price=100.0):
    class State:
        def snapshot(self):
            return {'connected': True, 'age': 0.2, 'local_sequence': 1, 'market_status': 'OPEN'}
    tb.feed=SimpleNamespace(state=State())
    tb.ticks[('nse_fo','paper')]=SimpleNamespace(trading_symbol=symbol, instrument_token='paper', ltp=price, timestamp=time.time()-0.2)

def test_paper_order_requires_risk_gate(tmp_path, monkeypatch):
    tb=_tb(tmp_path, monkeypatch)
    try:
        r=tb.paper_order({'symbol':'NIFTY','side':'BUY','quantity':75,'fill_price':100})
        assert not r['ok']
        assert 'PAPER_RISK_EVALUATION_REQUIRED' in r['error']
        assert tb.paper_ledger.orders()==[]
    finally:
        getattr(tb,'_auto_repair_stop',None) and tb._auto_repair_stop.set()
        getattr(tb,'self_healing',None) and tb.self_healing.stop()

def test_paper_order_risk_limit_cannot_be_bypassed(tmp_path, monkeypatch):
    tb=_tb(tmp_path, monkeypatch)
    try:
        rr=tb.risk_evaluate({'limits':{'data':{'availableMargin':100000,'marginUsed':0}},'order':{'side':'BUY','quantity':1,'price':100}})
        assert rr['ok']
        r=tb.paper_order({'symbol':'NIFTY','side':'BUY','quantity':999999,'fill_price':100})
        assert not r['ok']
        assert 'ORDER_QTY_LIMIT_EXCEEDED' in r['error']
        assert tb.paper_ledger.orders()==[]
    finally:
        getattr(tb,'_auto_repair_stop',None) and tb._auto_repair_stop.set()
        getattr(tb,'self_healing',None) and tb.self_healing.stop()

def test_paper_order_allowed_after_risk_gate(tmp_path, monkeypatch):
    tb=_tb(tmp_path, monkeypatch)
    try:
        _ready_feed(tb)
        rr=tb.risk_evaluate({'limits':{'data':{'availableMargin':100000,'marginUsed':0}},'order':{'side':'BUY','quantity':75,'price':100}})
        assert rr['ok'] and rr['decision']['decision']=='ALLOW_PAPER'
        r=tb.paper_order({'symbol':'NIFTY','side':'BUY','quantity':75,'fill_price':100})
        assert r['ok'] and r['data']['status']=='FILLED'
        assert tb.paper_ledger.positions()[0]['net_quantity']==75
    finally:
        getattr(tb,'_auto_repair_stop',None) and tb._auto_repair_stop.set()
        getattr(tb,'self_healing',None) and tb.self_healing.stop()


def test_paper_execution_stays_blocked_after_risk_rejection(tmp_path, monkeypatch):
    tb=_tb(tmp_path, monkeypatch)
    try:
        rr=tb.risk_evaluate({'limits':{'data':{'availableMargin':100000,'marginUsed':0}},'order':{'side':'BUY','quantity':999999,'price':100}})
        assert rr['ok'] and rr['decision']['decision']=='BLOCK'
        r=tb.paper_order({'symbol':'NIFTY','side':'BUY','quantity':75,'fill_price':100})
        assert not r['ok'] and 'EXECUTION_PAUSED' in r['error']
        assert tb.paper_ledger.orders()==[]
    finally:
        tb._auto_repair_stop.set(); tb.self_healing.stop()
