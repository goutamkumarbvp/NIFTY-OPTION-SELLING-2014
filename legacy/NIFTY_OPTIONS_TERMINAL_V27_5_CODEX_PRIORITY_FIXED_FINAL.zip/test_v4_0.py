from strategy_brain import StrategyBrain, StrategyConfig
from server import APP, Handler
import json, threading
from urllib.request import urlopen, Request
from http.server import ThreadingHTTPServer

def chain():
    return [
      {'strike':24900,'pe':{'ltp':20,'oi':1000,'doi':200},'ce':{'ltp':150,'oi':300,'doi':-50}},
      {'strike':25000,'pe':{'ltp':30,'oi':1500,'doi':300},'ce':{'ltp':100,'oi':1000,'doi':50}},
      {'strike':25100,'pe':{'ltp':50,'oi':800,'doi':100},'ce':{'ltp':60,'oi':1800,'doi':200}},
      {'strike':25200,'pe':{'ltp':80,'oi':500,'doi':50},'ce':{'ltp':30,'oi':2200,'doi':300}},
    ]

def test_strategy_requires_spot():
    assert StrategyBrain().analyze(chain())['status']=='BLOCKED'

def test_strategy_produces_candidates():
    p=StrategyBrain().analyze(chain(),25000,'RANGE')
    assert p['candidates'] and p['execution']=='DISABLED'

def test_low_quality_blocks():
    c=[{'strike':24900,'pe':{},'ce':{}},{'strike':25000,'pe':{},'ce':{}},{'strike':25100,'pe':{},'ce':{}}]
    assert StrategyBrain().analyze(c,25000)['status']=='NO_TRADE'

def test_no_order_api():
    assert not hasattr(APP,'place_order')

def test_strategy_health_endpoint():
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
    try:
        req=Request(f'http://127.0.0.1:{srv.server_address[1]}/api/strategy/health',data=b'{}',headers={'Content-Type':'application/json'})
        out=json.loads(urlopen(req).read()); assert out['ok'] and out['strategy']['execution_enabled'] is False
    finally: srv.shutdown(); srv.server_close()
