import json
import threading
from pathlib import Path


def test_release_version_matches_metadata_and_server_health_contract():
    root = Path(__file__).resolve().parent
    data = json.loads((root / "VERSION.json").read_text(encoding="utf-8"))
    assert data["release"] == "V27.5"
    server = (root / "server.py").read_text(encoding="utf-8")
    assert "version_data.get('release')" in server


def test_self_healing_stop_contract_is_joinable():
    from self_healing import SelfHealingSupervisor
    s = SelfHealingSupervisor(lambda: {}, lambda: {"ok": False}, interval=0.5)
    s.start()
    s.stop()
    t = getattr(s, "_thread", None)
    assert t is None or not t.is_alive()
