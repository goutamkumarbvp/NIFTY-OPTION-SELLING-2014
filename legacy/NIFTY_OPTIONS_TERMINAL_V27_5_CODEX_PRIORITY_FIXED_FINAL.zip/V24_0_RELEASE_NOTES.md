# V24.0 — LLM Reasoning Gateway
- Provider-neutral reasoning boundary.
- Deterministic offline mode is default.
- Remote gateway is opt-in via `LLM_GATEWAY_ENABLED=true` + `LLM_GATEWAY_URL`.
- Evidence is bounded, secrets are redacted, timeout is bounded, remote failure falls back safely.
- No order execution or risk-policy override capability.
