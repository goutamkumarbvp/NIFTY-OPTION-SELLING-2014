# NIFTY Options Terminal V6.0 — Pass 6

## Scope
Research/Backtesting + full Black-Scholes Greeks + bounded implied volatility + observed volatility surface + event intelligence + FII/DII intelligence.

## Safety
- Live order execution remains disabled.
- Research engines consume supplied evidence; they do not fabricate market data.
- Backtest fills signal at t on bar t+1 to reduce look-ahead bias.
- Volatility surface refuses extrapolation outside observed bounds.
- IV solver rejects prices outside no-arbitrage bounds.
- Event and institutional-flow modules fail closed when required evidence is missing.

## Verification
- 62/62 regression tests passed.
- Python compilation passed.
- Dashboard/backend route audit passed.
- Live `place_order` implementation scan: 0.
- ZIP integrity verified.
