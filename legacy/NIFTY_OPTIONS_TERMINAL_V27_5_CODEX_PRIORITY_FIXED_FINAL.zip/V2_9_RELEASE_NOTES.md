# V2.9 Release Notes

## PASS criteria
1. Dashboard actions map to backend routes.
2. Kotak read-only portfolio paths use the current SDK methods.
3. Position reconciliation is explicit and fail-closed.
4. Feed soak produces evidence instead of claiming success from socket connection alone.
5. Live orders remain locked.

The release does not claim a credentialed live soak was executed unless the user's real Kotak session is supplied.
