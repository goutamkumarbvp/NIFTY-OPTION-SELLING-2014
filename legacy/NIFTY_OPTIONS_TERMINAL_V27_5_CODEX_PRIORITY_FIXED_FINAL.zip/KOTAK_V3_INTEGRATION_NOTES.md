# Kotak Neo v3.0.6 integration notes

V2.7 targets the actively maintained official Python SDK v3.0.6. The v3 SDK uses TOTP + MPIN authentication, async/await SFeed, typed messages, and market-data methods including expiries and option_chain. The adapter intentionally exposes no order-placement method.

The dashboard's live-data endpoints fail closed when authentication is absent. A successful WebSocket socket alone is not considered healthy; the backend requires fresh received feed evidence for a HEALTHY/FRESH state.
