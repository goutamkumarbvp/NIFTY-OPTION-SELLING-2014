from __future__ import annotations
"""V21 composition root: concrete implementations are wired here only."""
import os
from pathlib import Path
from event_bus import EventBus
from service_contracts import ApplicationDependencies, MarketDependencies, IntelligenceDependencies, ResearchDependencies, AIDependencies
from kotak_neo_adapter import NeoConfig, KotakNeoMarketAdapter
from market_feed import KotakSFeedBridge, FeedSupervisor
from pass14_engine import KotakReadOnlyConfig, ReadOnlyConnectionManager, redacted_env
from market_intelligence import build_chain, chain_metrics, chain_feed_tokens
from pass15_engine import KotakResponseExtractor, NiftyTokenResolver, SubscriptionPlanner, TickSoakMonitor, Pass15Error
from reconciliation import reconcile
from risk_brain import RiskBrain
from advanced_risk import AdvancedRiskBrain
from strategy_brain import StrategyBrain
from options_intelligence import OptionsIntelligence
from market_regime import MarketRegimeEngine
from quant_engine import QuantEngine
from vol_surface import VolatilitySurface
from event_intelligence import EventIntelligence
from fii_dii_intelligence import FiiDiiIntelligence
from research_backtest import ResearchBacktester
from research_data import HistoricalDataStore
from options_backtest import OptionBacktester
from walk_forward import WalkForwardValidator
from stress_monte_carlo import StressEngine
from strategy_backtest import MultiLegStrategyBacktester, StrategyOptimizer, robustness, monte_carlo_validate
from historical_option_store import HistoricalOptionChainStore
from options_replay import OptionChainReplay
from research_margin import ResearchMarginEngine
from market_data_v10 import OptionChainSQLiteStore, CSVOptionChainImporter, ParquetExporter, NSECalendar, ContractMapper
from pass11_engine import DatasetVersionRegistry, ContractSeriesManager, HistoricalQueryLayer, DataQualityScorer, HighSpeedReplayEngine
from pass12_engine import ProvenanceRegistry, PartitionedStore, CoverageAnalyzer, ReplaySource, DatasetCompleteness
from pass13_engine import CanonicalNiftySchema, IntegrityScanner, SessionCalendar, ContractChain, StreamingNormalizer, DatasetCertifier, FastReplay
from super_ai_agent import ExtremeSuperAgent
from pass17_agent_engine import Pass17Agent
from alert_engine import AlertManager
from self_repair import CodeSelfRepairEngine
from paper_execution import PaperExecutionLedger
from v24_llm_gateway import LLMReasoningGateway
from v25_agent_memory import AgentLongTermMemory
from v26_autonomous_research import AdvancedAutonomousResearch
from v27_verified_autonomous_repair import VerifiedAutonomousRepair

def build_dependencies(root: Path, audit_callback):
    market=MarketDependencies(KotakReadOnlyConfig,ReadOnlyConnectionManager,KotakNeoMarketAdapter,NeoConfig,redacted_env,KotakSFeedBridge,FeedSupervisor,build_chain,chain_metrics,chain_feed_tokens,KotakResponseExtractor,NiftyTokenResolver,SubscriptionPlanner,TickSoakMonitor,Pass15Error,reconcile)
    intel=IntelligenceDependencies(RiskBrain(),AdvancedRiskBrain(),StrategyBrain(),OptionsIntelligence(),MarketRegimeEngine(),QuantEngine(),VolatilitySurface(),EventIntelligence(),FiiDiiIntelligence())
    research=ResearchDependencies(ResearchBacktester(),lambda p:HistoricalDataStore(p),OptionBacktester(),WalkForwardValidator(),lambda p:HistoricalOptionChainStore(p),OptionChainReplay(),ResearchMarginEngine(),StressEngine(),MultiLegStrategyBacktester(),lambda x:StrategyOptimizer(x),lambda p:OptionChainSQLiteStore(p),CSVOptionChainImporter,ParquetExporter,NSECalendar(),ContractMapper,lambda p:DatasetVersionRegistry(p),ContractSeriesManager(),lambda p:HistoricalQueryLayer(p),DataQualityScorer(),HighSpeedReplayEngine(),lambda p:ProvenanceRegistry(p),lambda p:PartitionedStore(p),CoverageAnalyzer(),ReplaySource(),DatasetCompleteness(),CanonicalNiftySchema,IntegrityScanner(),SessionCalendar(),ContractChain(),StreamingNormalizer(),DatasetCertifier(),FastReplay(),robustness,monte_carlo_validate)
    ai=AIDependencies(ExtremeSuperAgent(),lambda p:Pass17Agent(p),lambda p,e:AlertManager(p,e),lambda p,a:CodeSelfRepairEngine(p,a),LLMReasoningGateway(),lambda p:AgentLongTermMemory(p),AdvancedAutonomousResearch(),lambda e:VerifiedAutonomousRepair(e))
    return ApplicationDependencies(market,intel,research,ai,PaperExecutionLedger,EventBus())
