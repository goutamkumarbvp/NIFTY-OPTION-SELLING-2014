from __future__ import annotations
"""V27 orchestration around V18 verified repair: diagnose -> sandbox -> verify -> optional gated promotion.
Promotion is disabled by default and never touches live-trading policy.
"""
import hashlib, os
from pathlib import Path
from typing import Any

class VerifiedAutonomousRepair:
    VERSION="v27.5"
    def __init__(self,engine): self.engine=engine
    def status(self):
        s=dict(self.engine.status()); s.update({"version":self.VERSION,"autonomous_diagnosis":True,"sandbox_verification":True,"mandatory_tests":True,"automatic_rollback":True,"live_orders_enabled":False,"promotion_default":False,"repair_provider":type(getattr(self.engine,"provider",None)).__name__}); return s
    def run(self,error:str,target:Path,new_source:Any=None,approve=False):
        if not target: return {"ok":False,"status":"BLOCKED","error":"TARGET_FILE_REQUIRED","version":self.VERSION}
        d=self.engine.diagnose(error,target)
        # Sandbox verification is always attempted; promotion requires explicit approval and policy.
        r=self.engine.propose_and_verify(d,target,new_source,promote=False)
        out={"version":self.VERSION,"ok":r.ok,"status":r.status,"diagnosis":d.__dict__,"result":r.__dict__,"live_orders_enabled":False,"code_mutation":False if not r.promoted else True,"promotion_requested":False,"promotion_policy_enabled":False}
        return out
