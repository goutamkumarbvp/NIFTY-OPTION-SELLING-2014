import tempfile, unittest, time, os
from pathlib import Path
from alert_engine import AlertManager

class T(unittest.TestCase):
    def setUp(self):
        self.d=tempfile.TemporaryDirectory(); self.sent=[]
        self.a=AlertManager(Path(self.d.name)/'alerts.json', {'ALERT_COOLDOWN_SECONDS':'60','ALERT_BIG_MOVE_PCT':'1','ALERT_BLACK_SWAN_MOVE_PCT':'2','ALERT_MOVE_WINDOW_SECONDS':'300'}, sender=lambda ch,a: self.sent.append(a) or True)
    def tearDown(self): self.d.cleanup()
    def test_stop_loss(self):
        r=self.a.evaluate_risk(None,-2500,2500); self.assertTrue(r[0]['emitted']); self.assertEqual(r[0]['alert']['kind'],'STOP_LOSS')
    def test_new_trade(self):
        r=self.a.new_trade({'candidates':[{'type':'IRON_CONDOR','score':8.5}]},'abc'); self.assertTrue(r[0]['emitted']); self.assertEqual(r[0]['alert']['kind'],'NEW_TRADE')
    def test_big_move(self):
        self.a.evaluate_market(25000,None,None,True); r=self.a.evaluate_market(25250,25000,None,True); self.assertTrue(any(x.get('alert',{}).get('kind')=='BIG_MOVE' for x in r))
    def test_black_swan(self):
        self.a.evaluate_market(25000,None,None,True); r=self.a.evaluate_market(25500,25000,None,True); self.assertTrue(any(x.get('alert',{}).get('kind')=='BLACK_SWAN' for x in r))
    def test_stale(self):
        r=self.a.evaluate_market(None,None,6,True); self.assertEqual(r[0]['alert']['kind'],'FEED_STALE')
    def test_disconnect(self):
        r=self.a.evaluate_market(None,25000,None,False); self.assertEqual(r[0]['alert']['kind'],'BROKER_DISCONNECTED')
    def test_dedupe(self):
        self.a.emit('X','CRITICAL','x','x','k'); r=self.a.emit('X','CRITICAL','x','x','k'); self.assertFalse(r['emitted'])
    def test_persistence(self):
        self.a.emit('X','INFO','x','x','k'); b=AlertManager(Path(self.d.name)/'alerts.json', {'ALERT_COOLDOWN_SECONDS':'60'}); self.assertEqual(len(b.recent()),1)
    def test_redaction_not_needed(self): self.assertTrue(self.a.sender)
    def test_multichannel_config_flags(self):
        env={'ALERT_COOLDOWN_SECONDS':'60','TELEGRAM_BOT_TOKEN':'t','TELEGRAM_CHAT_ID':'c','TWILIO_ACCOUNT_SID':'ACx','TWILIO_AUTH_TOKEN':'secret','TWILIO_SMS_FROM':'+10000000000','ALERT_SMS_TO':'+910000000000','TWILIO_WHATSAPP_FROM':'whatsapp:+10000000000','ALERT_WHATSAPP_TO':'whatsapp:+910000000000'}
        a=AlertManager(Path(self.d.name)/'multi.json', env)
        self.assertTrue(a.telegram_enabled); self.assertTrue(a.sms_enabled); self.assertTrue(a.whatsapp_enabled)
    def test_twilio_delivery_is_fail_safe_without_network(self):
        env={'TWILIO_ACCOUNT_SID':'ACx','TWILIO_AUTH_TOKEN':'secret','TWILIO_SMS_FROM':'+10000000000','ALERT_SMS_TO':'+910000000000'}
        a=AlertManager(Path(self.d.name)/'twilio.json', env)
        r=a.emit('TEST','CRITICAL','Test','No network expected',force=True)
        self.assertTrue(r['emitted']); self.assertFalse(r['alert']['delivered'].get('sms',True))
if __name__=='__main__': unittest.main()

# extra trade-stop coverage
class TradeStopT(T):
    def test_trade_stop_loss(self):
        r=self.a.evaluate_risk(None, trade_pnl=-500, trade_stop_loss=500)
        self.assertTrue(r[0]['emitted']); self.assertEqual(r[0]['alert']['kind'],'STOP_LOSS')
