
from __future__ import annotations
import csv, io, math, re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Optional
import urllib.request

@dataclass(frozen=True)
class InstrumentRecord:
    token:str
    symbol:str
    underlying:str
    segment:str
    expiry:str
    strike:float
    option_type:str
    lot_size:int
    tick_size:float
    freeze_qty:int=1800
    tradable:bool=True

def _pick(row,*names):
    for n in names:
        if n in row and row[n] not in (None,""): return row[n]
    return None

def parse_scrip_csv(text:str, segment_hint:str="nse_fo")->list[InstrumentRecord]:
    """Defensive parser for Kotak Neo scrip-master CSV variants."""
    if not text.strip(): return []
    rows=list(csv.DictReader(io.StringIO(text)))
    out=[]
    for raw in rows:
        row={str(k).strip().strip(";"):v for k,v in raw.items()}
        token=_pick(row,"pSymbol","pTrdSymbol","instrument_token","token")
        symbol=_pick(row,"pTrdSymbol","pSymbolName","trading_symbol","symbol")
        underlying=_pick(row,"pSymbolName","underlying","symbol_name") or ""
        seg=_pick(row,"pExchSeg","exch_seg","exchange_segment") or segment_hint
        expiry=_pick(row,"pExpiryDate","expiry","expiry_date") or ""
        strike_raw=_pick(row,"dStrikePrice","strike","strike_price") or "0"
        opt=_pick(row,"pOptionType","option_type") or ""
        lot_raw=_pick(row,"lLotSize","lot_size","lotSz") or "0"
        tick_raw=_pick(row,"dTickSize","tick_size") or "0.05"
        freeze_raw=_pick(row,"lFreezeQty","freeze_qty") or "1800"
        try:
            strike=float(str(strike_raw).replace(";",""))
            lot=int(float(str(lot_raw).replace(";","")))
            tick=float(str(tick_raw).replace(";",""))
            freeze=int(float(str(freeze_raw).replace(";","")))
        except (ValueError,TypeError):
            continue
        if not token or not symbol or lot<=0 or tick<=0: continue
        # Keep only options for the option-master path.
        opt=str(opt).upper()
        if opt in ("CE","PE"):
            out.append(InstrumentRecord(str(token),str(symbol),str(underlying),str(seg),
                                        str(expiry),strike,opt,lot,tick,freeze,True))
    return out

class ScripMasterClient:
    """Fetches exact URLs returned by Neo's scrip_master(), never hard-coding daily paths."""
    def __init__(self, neo_client, timeout:float=10):
        self.neo=neo_client; self.timeout=timeout
    def discover(self, exchange_segment:Optional[str]=None)->list[str]:
        result=self.neo.scrip_master(**({"exchange_segment":exchange_segment} if exchange_segment else {}))
        if isinstance(result,str): return [result]
        if not isinstance(result,dict): raise ValueError("INVALID_SCRIP_MASTER_RESPONSE")
        paths=result.get("filesPaths") or []
        if exchange_segment and not paths and result.get("filePath"): paths=[result["filePath"]]
        if not paths: raise ValueError("NO_SCRIP_MASTER_PATHS")
        return [str(x) for x in paths]
    def download(self,url:str)->str:
        req=urllib.request.Request(url,headers={"Accept":"text/csv"})
        with urllib.request.urlopen(req,timeout=self.timeout) as r:
            return r.read().decode("utf-8-sig")
    def load_segment(self,exchange_segment:str)->list[InstrumentRecord]:
        paths=self.discover(exchange_segment)
        records=[]
        for url in paths:
            records.extend(parse_scrip_csv(self.download(url),exchange_segment))
        return records
