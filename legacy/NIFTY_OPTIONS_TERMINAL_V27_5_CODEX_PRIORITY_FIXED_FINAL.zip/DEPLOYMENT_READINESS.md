# V27.3 Complete Program — Deployment Readiness

## Included
- Dashboard + HTTP API
- Kotak Neo read-only market-data path
- NIFTY option-chain/OI/ΔOI/PCR intelligence
- Risk and strategy services
- Historical research/backtesting/replay
- Agentic analysis, memory/tools/critic components
- Runtime feed self-healing
- Verified sandbox code self-repair with checkpoint/rollback
- Dashboard/Telegram/SMS/WhatsApp alert integration
- Architecture contracts and event isolation
- Windows + Linux launchers
- Docker image definition
- Health endpoint and request-size/auth boundary

## Safety boundary
`LIVE_TRADING=false` and `live_orders_enabled=false` are hard defaults. The release does not expose a live order placement route.

## Workstation deployment
This release is suitable for controlled workstation/paper-trading deployment. Run `START_TERMINAL.bat` on Windows or `./START_TERMINAL.sh` on Linux/macOS.

## Remote/cloud deployment
The built-in HTTP server is not a substitute for a production edge. Put HTTPS, authentication, rate limiting, network policy, logging/monitoring and secret management in front of it. If `BIND_HOST` is non-loopback, `API_AUTH_TOKEN` is mandatory. TLS remains the reverse proxy's responsibility.

## External integrations
Real Kotak/Telegram/Twilio delivery requires the user's own credentials in a local `.env` or secret manager. No credentials are bundled or tested in this package.
