import tempfile, os
from historical_option_store import HistoricalOptionChainStore
from options_replay import OptionChainReplay
from research_margin import ResearchMarginEngine
from research_data import HistoricalOptionChainValidator

def snap(ts, spot=25000):
 return {'timestamp':ts,'spot':spot,'expiry':'2026-09-24','contracts':[
  {'symbol':'NIFTY','option_type':'CE','strike':25000,'expiry':'2026-09-24','bid':100,'ask':102,'oi':1000,'volume':100,'instrument_token':'1'},
  {'symbol':'NIFTY','option_type':'PE','strike':25000,'expiry':'2026-09-24','bid':90,'ask':92,'oi':1200,'volume':120,'instrument_token':'2'}]}

def snaps(): return [snap('2026-09-15T09:15:00+05:30'),snap('2026-09-15T09:16:00+05:30'),snap('2026-09-15T15:29:00+05:30',24900)]

def legs(): return [{'symbol':'NIFTY','option_type':'CE','strike':25000,'expiry':'2026-09-24','side':-1,'qty':1,'lot_size':75}]

def test_store_immutable_and_hash():
 with tempfile.TemporaryDirectory() as d:
  st=HistoricalOptionChainStore(d); a=st.ingest('nifty_sep',snaps()); assert a['status']=='READY' and len(a['sha256'])==64
  b=st.ingest('nifty_sep',snaps()); assert b['reason']=='DATASET_EXISTS'
  r=st.read('nifty_sep'); assert r['status']=='READY' and len(r['rows'])==3

def test_schema_rejects_missing_symbol():
 x=snaps(); del x[0]['contracts'][0]['symbol']; assert HistoricalOptionChainValidator.validate(x)['reason']=='INVALID_CONTRACT'

def test_schema_rejects_negative_oi():
 x=snaps(); x[0]['contracts'][0]['oi']=-1; assert HistoricalOptionChainValidator.validate(x)['reason']=='INVALID_CONTRACT_METADATA'

def test_replay_short_option():
 r=OptionChainReplay().replay(snaps(),legs()); assert r['status']=='READY' and r['entry_index']==1 and r['pnl'] != 0

def test_replay_missing_contract_blocks():
 x=snaps(); del x[1]['contracts'][0]; assert OptionChainReplay().replay(x,legs())['reason']=='MISSING_CONTRACT'

def test_replay_duplicate_contract_blocks():
 x=snaps(); x[0]['contracts'].append(dict(x[0]['contracts'][0])); assert OptionChainReplay().replay(x,legs())['reason']=='DUPLICATE_CONTRACT'

def test_margin_defined_and_stress():
 r=ResearchMarginEngine().estimate(legs(),[100],25000,1_000_000); assert r['status']=='READY' and r['estimated_margin']>=r['stress_loss'] and r['research_only']

def test_margin_invalid_capital_fail_closed():
 assert ResearchMarginEngine().estimate(legs(),[100],25000,0)['reason']=='INVALID_MARGIN_INPUT'

def test_schema_rejects_contract_expiry_mismatch():
 x=snaps(); x[0]['contracts'][0]['expiry']='2026-10-01'; assert HistoricalOptionChainValidator.validate(x)['reason']=='EXPIRY_MISMATCH'

def test_replay_rejects_bad_time_order():
 x=snaps(); x[1]['timestamp']=x[0]['timestamp']; assert OptionChainReplay().replay(x,legs())['reason']=='NON_MONOTONIC_TIMESTAMP'

def test_margin_blocks_invalid_price():
 assert ResearchMarginEngine().estimate(legs(),[0],25000,1_000_000)['reason']=='INVALID_ENTRY_PRICE'

def test_backend_pass9_routes():
 from server import TerminalBackend
 a=TerminalBackend(); assert a.research_margin_engine and a.option_replay and a.option_chain_store
