# V27.3 Hardening Release

This release hardens the V27.3 paper/read-only terminal following an execution-based audit.

## P0
- Immutable paper-only safety authority and fail-closed startup invariant.
- Paper execution ledger with SQLite persistence, fills, positions, mark-to-market and paper flatten.
- Self-repair redesign: protected safety files/policy, semantic modification blocking, secret-free sandbox copy, independent verifier.
- V13/V14/API validation and endpoint defect fixes.

## P1
- Strict JSON object request validation.
- Docker refuses missing authentication token and explicitly sets paper-only flags.
- Research filesystem paths are to be restricted in deployment configuration; no broker order path is exposed.
- V27.3 version consistency cleanup.
- Independent static security verifier.

## P2 tooling
- API fuzz harness: `tools/fuzz_api.py`
- HTTP dashboard smoke test: `tools/browser_smoke.py`
- Long-run health soak: `tools/soak.py`
- Reproducible exact dependency versions in `requirements.txt`.

## Safety
This release remains strictly paper/read-only. No live order capability was added. Startup fails closed if `TRADING_MODE` is not `paper`, `LIVE_TRADING` is true, or `LIVE_ORDERS_ENABLED` is true.
