# V21.0 Extremely Deep Architecture Audit

## Scope
V20 was audited and refactored for dependency inversion, concrete-wiring isolation, service boundaries, event isolation, and regression safety. The release remains paper/read-only: live order execution is disabled.

## Key findings and repairs
1. **Concrete dependency imports in services** — repaired. Market, Intelligence, Research and AI services now depend on `service_contracts.py` bundles rather than importing concrete domain/infrastructure classes.
2. **Composition leakage** — repaired. `composition.py` is the sole concrete wiring point. `terminal_backend.py` loads the composition root through an isolated loader and owns lifecycle/state coordination.
3. **Cross-service imports** — none detected among the four application services.
4. **Server/domain coupling** — server imports only the backend transport facade; no domain implementation is imported by `server.py`.
5. **Event isolation** — added `event_bus.py`, independent of trading/domain modules. Event handler failure is isolated and reported rather than stopping subsequent handlers.
6. **V18 self-repair API defect found during audit** — `ai_service.py` used `Path`/`ROOT` without safe qualification. `Path` was imported and relative target resolution was corrected to `self.ctx.ROOT`.
7. **V20 compatibility regression found during refactor** — missing injected `reconcile`, `robustness`, and `monte_carlo_validate` dependencies and a direct `chain_feed_tokens` reference were caught by tests and repaired before release.

## Dependency measurements
Production modules: 44
Production import edges: 48

| Module | Production fan-out |
|---|---:|
| server.py | 1 |
| terminal_backend.py | 5 |
| market_service.py | 2 |
| intelligence_service.py | 1 |
| research_service.py | 1 |
| ai_service.py | 1 |
| service_contracts.py | 0 |
| event_bus.py | 0 |
| composition.py | 34 |

The high fan-out of `composition.py` is intentional: it is the composition root and the only location where concrete implementations are wired.

## Architectural invariants
- Service -> server: **0**
- Service -> terminal_backend: **0**
- Service -> another service: **0**
- Service -> concrete domain/infrastructure modules: **0**
- Contracts -> concrete domain modules: **0**
- Event bus -> trading/domain modules: **0**
- Backend -> concrete domain modules: **0** (composition loaded as an isolated composition-root module)
- Server -> concrete domain modules: **0**

## Verification
- Python compilation: PASS
- Full regression: **294/294 PASS**
- Architecture tests: PASS
- Event-bus fault isolation: PASS
- Existing V18 self-repair tests: PASS
- Existing V19/V20 architecture tests: PASS
- Live-order safety invariants: preserved
- `LIVE_TRADING`: false/default-safe
- `live_orders_enabled`: false

## Residual coupling
V21 does **not** claim zero logical coupling. Services still coordinate through the shared application context/state object for backward-compatible state and response assembly. V22 can move those state reads/writes into typed application ports/DTOs and command/event contracts.

## Verdict
**V21 PASS — dependency inversion and concrete-wiring isolation achieved.**
