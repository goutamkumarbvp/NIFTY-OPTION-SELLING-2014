from __future__ import annotations
import re, time, threading
from dataclasses import dataclass, field
from typing import Any, Iterable

SCHEMA_VERSION = 'v15.0'

class Pass15Error(ValueError):
    pass

@dataclass(frozen=True)
class InstrumentRef:
    exchange_segment: str
    instrument_token: str
    trading_symbol: str | None = None
    underlying: str = 'NIFTY'

@dataclass
class LiveChainSnapshot:
    expiry: str
    contracts: list[dict[str, Any]] = field(default_factory=list)
    source: str = 'kotak_neo'
    received_at: float = field(default_factory=time.time)

class KotakResponseExtractor:
    """Defensive extractor for SDK response envelopes; never invents tokens."""
    @staticmethod
    def walk(obj: Any) -> Iterable[dict]:
        if isinstance(obj, dict):
            yield obj
            for v in obj.values():
                yield from KotakResponseExtractor.walk(v)
        elif isinstance(obj, list):
            for v in obj:
                yield from KotakResponseExtractor.walk(v)

    @staticmethod
    def _first(d: dict, keys: tuple[str, ...]):
        lower = {str(k).lower(): v for k, v in d.items()}
        for k in keys:
            if k.lower() in lower and lower[k.lower()] not in (None, ''):
                return lower[k.lower()]
        return None

    @classmethod
    def instrument_refs(cls, response: Any) -> list[InstrumentRef]:
        out, seen = [], set()
        for d in cls.walk(response):
            seg = cls._first(d, ('exchange_segment','segment','exchange'))
            tok = cls._first(d, ('instrument_token','instrumentToken','token','scrip_token'))
            sym = cls._first(d, ('trading_symbol','tradingSymbol','symbol','display_name'))
            if seg and tok:
                ref = InstrumentRef(str(seg).lower(), str(tok), None if sym is None else str(sym))
                key=(ref.exchange_segment,ref.instrument_token)
                if key not in seen:
                    seen.add(key); out.append(ref)
        return out

    @classmethod
    def option_contracts(cls, response: Any) -> list[dict[str, Any]]:
        contracts=[]; seen=set()
        for d in cls.walk(response):
            seg=cls._first(d, ('exchange_segment','segment','exchange'))
            tok=cls._first(d, ('instrument_token','instrumentToken','token','scrip_token'))
            strike=cls._first(d, ('strike','strike_price','strikePrice','dStrikePrice'))
            typ=cls._first(d, ('option_type','optionType','optiontype','instrument_type','right'))
            exp=cls._first(d, ('expiry','expiry_date','expiryDate'))
            if not (seg and tok and strike is not None and typ and exp):
                continue
            typ=str(typ).upper()
            if typ not in ('CE','PE'): continue
            try: strike_f=float(str(strike).replace(',',''))
            except Exception: continue
            rec={'exchange_segment':str(seg).lower(),'instrument_token':str(tok),'strike':strike_f,'option_type':typ,'expiry':str(exp)[:10],
                 'trading_symbol':cls._first(d,('trading_symbol','tradingSymbol','symbol')),
                 'lot_size':cls._first(d,('lot_size','lotSize','lot')),'tick_size':cls._first(d,('tick_size','tickSize','tick')),
                 'ltp':cls._first(d,('last_traded_price','lastTradedPrice','ltp','LTP')),'bid':cls._first(d,('best_bid_price','bestBidPrice','bid_price','bidPrice','bid')),
                 'ask':cls._first(d,('best_ask_price','bestAskPrice','ask_price','askPrice','ask')),'oi':cls._first(d,('open_interest','openInterest','oi')),
                 'doi':cls._first(d,('change_in_oi','changeInOi','changeInOI','doi','oi_change')),'volume':cls._first(d,('volume','vol')),
                 'iv':cls._first(d,('implied_volatility','impliedVolatility','iv'))}
            key=(rec['exchange_segment'],rec['instrument_token'],rec['strike'],rec['option_type'],rec['expiry'])
            if key not in seen: seen.add(key); contracts.append(rec)
        return contracts

class NiftyTokenResolver:
    """Resolves NIFTY underlying from broker evidence; never uses a hard-coded token."""
    def __init__(self, adapter): self.adapter=adapter
    def resolve(self) -> InstrumentRef:
        queries=(
            {'search':'NIFTY','exchange_segment':'nse_cm'},
            {'search':'NIFTY 50','exchange_segment':'nse_cm'},
            {'search':'NIFTY','segment':'nse_cm'},
        )
        for q in queries:
            try:
                r=self.adapter.search_scrip(**q)
                refs=KotakResponseExtractor.instrument_refs(r)
                preferred=[x for x in refs if x.exchange_segment=='nse_cm' and x.trading_symbol and re.search(r'nifty',x.trading_symbol,re.I)]
                if preferred:
                    # Prefer exact index-like symbol over derivatives/equity symbols.
                    preferred.sort(key=lambda x: (0 if str(x.trading_symbol).upper() in ('NIFTY','NIFTY 50','NIFTY50') else 1, len(str(x.trading_symbol))))
                    return preferred[0]
            except Exception:
                continue
        raise Pass15Error('NIFTY_UNDERLYING_TOKEN_NOT_RESOLVED_FROM_KOTAK')

class SubscriptionPlanner:
    def plan(self, contracts: list[dict[str,Any]], max_tokens=3000) -> list[tuple[str,str]]:
        unique=[]; seen=set()
        for c in contracts:
            seg=str(c.get('exchange_segment','')).lower(); tok=str(c.get('instrument_token',''))
            if seg!='nse_fo' or not tok: continue
            key=(seg,tok)
            if key not in seen: seen.add(key); unique.append(key)
        if not unique: raise Pass15Error('NO_VALID_NIFTY_OPTION_TOKENS')
        if len(unique)>max_tokens: raise Pass15Error(f'SFEED_SUBSCRIPTION_LIMIT_EXCEEDED:{max_tokens}')
        return unique

class TickSoakMonitor:
    def __init__(self):
        self.lock=threading.RLock(); self.started=time.time(); self.messages=0; self.invalid=0; self.duplicates=0; self.out_of_order=0; self.last_seq=None; self.last_tick=0.0; self.tokens=set()
    def observe(self,tick):
        with self.lock:
            self.messages += 1
            seq=getattr(tick,'local_sequence',None)
            if seq is not None:
                if self.last_seq is not None and seq==self.last_seq: self.duplicates += 1
                elif self.last_seq is not None and seq<self.last_seq: self.out_of_order += 1
                self.last_seq=seq
            ltp=getattr(tick,'ltp',None)
            if ltp is None or ltp<=0: self.invalid += 1
            seg=getattr(tick,'exchange_segment',None); tok=getattr(tick,'instrument_token',None)
            if seg and tok:self.tokens.add((seg,tok))
            self.last_tick=time.time()
    def snapshot(self):
        with self.lock:
            elapsed=max(time.time()-self.started,1e-9)
            return {'status':'GOOD' if self.messages and self.invalid==0 and self.duplicates==0 and self.out_of_order==0 else ('WAITING' if not self.messages else 'DEGRADED'),
                    'messages':self.messages,'invalid':self.invalid,'duplicates':self.duplicates,'out_of_order':self.out_of_order,
                    'unique_tokens':len(self.tokens),'events_per_second':round(self.messages/elapsed,2),'last_tick_age_seconds':None if not self.last_tick else round(time.time()-self.last_tick,3)}
