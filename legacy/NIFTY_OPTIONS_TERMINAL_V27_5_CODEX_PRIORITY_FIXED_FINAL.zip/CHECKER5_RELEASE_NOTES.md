# V27.3 CODEX CHECKER-5 — Extreme Hardening

## Safety scope
- Paper-only release.
- LIVE_TRADING=false.
- LIVE_ORDERS_ENABLED=false.
- No live order endpoint is enabled.

## Repairs in this release
1. Paper risk evidence is server-derived; caller-supplied margin/P&L is not authoritative.
2. Paper mark-to-market rejects caller-supplied prices and derives marks from fresh trusted ticks.
3. NIFTY market evidence uses exact canonical identity and does not accept BANKNIFTY by substring match.
4. Loopback POST requests reject cross-origin browser requests via Origin/Sec-Fetch-Site validation.
5. Runtime self-repair promotion cannot be enabled by ordinary environment variables; promotion authority remains false by default.
6. Regression tests cover the above controls.

## Verification
- 371 tests are collected in the release after adding CHECKER-5 tests.
- 365 tests passed in one uninterrupted pytest process when the self-repair test module is excluded.
- The 6 self-repair tests passed independently.
- Additional focused CHECKER-5/CSRF/safety suite: 77 passed.
- compileall: PASS.
- security_verifier.py: PASS (exit code 0).
- Runtime HTTP CSRF attack: cross-origin POST returned 403; same-origin POST returned 200.

## Remaining certification limitations
The following were not independently certified in this environment:
- Full browser desktop/mobile E2E with Chromium.
- Clean online dependency installation on a network-isolated environment.
- Meaningful multi-hour soak.
- Complete kill-at-every-critical-point recovery matrix.
- Real Kotak read-only runtime authentication/feed.
- Live trading (intentionally disabled and not tested).

These limitations must not be represented as PASS.
