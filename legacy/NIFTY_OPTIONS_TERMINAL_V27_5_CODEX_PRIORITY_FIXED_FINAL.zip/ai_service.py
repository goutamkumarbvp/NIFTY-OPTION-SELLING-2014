from __future__ import annotations

import os
from pathlib import Path
from dataclasses import asdict
from service_contracts import AIDependencies

class Ai:
    """Application service boundary. Trading components are reached only through the injected context."""
    def __init__(self, ctx, deps: AIDependencies):
        self.ctx = ctx; self.deps = deps; c=ctx
        c.super_agent=deps.super_agent; c.last_super_agent=None; c.pass17=deps.pass17_factory(c.ROOT/'runtime'/'agent_memory.sqlite3'); c.last_pass17=None
        c.alerts=deps.alert_manager_factory(c.ROOT/'runtime'/'alerts.json', os.environ); c.previous_nifty=None; c.last_alert_eval=0.0
        c.self_repair=deps.self_repair_factory(c.ROOT, c._healing_audit)
        c.llm_gateway=deps.llm_gateway
        c.long_term_memory=deps.long_term_memory_factory(c.ROOT/'runtime'/'agent_long_term_memory.sqlite3')
        c.autonomous_research=deps.autonomous_research
        c.verified_repair=deps.verified_repair_factory(c.self_repair)

    def super_ai_analyze(self,b=None):
        try:
            result=self.ctx.super_agent.run(self.ctx.state(), self.ctx.last_plan, self.ctx.last_intelligence, self.ctx.last_regime, self.ctx.last_advanced_risk, self.ctx.last_events, self.ctx.last_flows)
            self.ctx.last_super_agent=result
            return {"ok":True,"agent":result,"state":self.ctx.state(),"action":self.ctx._log("EXTREME_SUPER_AI_ANALYZE",detail={"decision":result["decision"]["decision"],"confidence":result["decision"]["confidence"]})}
        except Exception as e:
            return self.ctx._fail("EXTREME_SUPER_AI_ANALYZE",e)

    def pass17_run(self,b=None):
        try:
            ctx={
                'state':self.ctx.state(),
                'plan':self.ctx.last_plan,
                'intelligence':self.ctx.last_intelligence,
                'regime':self.ctx.last_regime,
                'advanced_risk':self.ctx.last_advanced_risk,
            }
            self.ctx.pass17.register_default_tools(ctx)
            r=self.ctx.pass17.run(ctx); self.ctx.last_pass17=r
            return {'ok':True,'data':r,'state':self.ctx.state(),'action':self.ctx._log('PASS17_AGENTIC_RUN',detail={'trace_id':r['trace_id'],'decision':r['decision']})}
        except Exception as e: return self.ctx._fail('PASS17_AGENTIC_RUN',e)

    def pass17_memory(self,b=None):
        try:
            return {'ok':True,'memory':self.ctx.pass17.memory.recent(b.get('kind') if isinstance(b,dict) else None, (b or {}).get('limit',20) if isinstance(b,dict) else 20),'state':self.ctx.state(),'action':self.ctx._log('PASS17_MEMORY_READ')}
        except Exception as e:return self.ctx._fail('PASS17_MEMORY_READ',e)

    def pass17_tools(self,b=None):
        try:return {'ok':True,'tools':self.ctx.pass17.tools.list(),'policy':{'order_placement':False,'code_mutation':False},'state':self.ctx.state(),'action':self.ctx._log('PASS17_TOOLS')}
        except Exception as e:return self.ctx._fail('PASS17_TOOLS',e)

    def self_repair_status(self,b=None):
        return {'ok':True,'self_repair':self.ctx.self_repair.status(),'state':self.ctx.state(),'action':self.ctx._log('SELF_REPAIR_STATUS')}

    def self_repair_diagnose(self,b=None):
        try:
            target=Path(str(b.get('target_file'))) if b.get('target_file') else None
            if target and not target.is_absolute(): target=self.ctx.ROOT/target
            d=self.ctx.self_repair.diagnose(str(b.get('error') or b.get('traceback') or b.get('log') or ""),target)
            return {'ok':True,'diagnosis':asdict(d),'state':self.ctx.state(),'action':self.ctx._log('SELF_REPAIR_DIAGNOSE',detail=asdict(d))}
        except Exception as e: return self.ctx._fail('SELF_REPAIR_DIAGNOSE',e)

    def self_repair_run(self,b=None):
        try:
            target=Path(str(b.get('target_file'))) if b.get('target_file') else None
            if not target: raise ValueError('TARGET_FILE_REQUIRED')
            if not target.is_absolute(): target=self.ctx.ROOT/target
            d=self.ctx.self_repair.diagnose(str(b.get('error') or b.get('traceback') or b.get('log') or ""),target)
            r=self.ctx.self_repair.propose_and_verify(d,target,b.get('new_source'),promote=bool(b.get('promote',False)))
            return {'ok':r.ok,'repair':asdict(r),'state':self.ctx.state(),'action':self.ctx._log('SELF_REPAIR_RUN','OK' if r.ok else 'BLOCKED',asdict(r))}
        except Exception as e: return self.ctx._fail('SELF_REPAIR_RUN',e)


    def v24_reason(self,b=None):
        b=b or {}; evidence=b.get("evidence") or {"state":self.ctx.state(),"decision":(self.ctx.last_plan or {}).get("status","NO TRADE")}; r=self.ctx.llm_gateway.reason(evidence,b.get("instruction","Analyze the supplied trading evidence conservatively.")); return {"ok":bool(r.get("ok")),"gateway":r,"state":self.ctx.state(),"action":self.ctx._log("V24_LLM_REASON",detail={"mode":r.get("mode"),"blocked":r.get("blocked")})}

    def v25_memory(self,b=None):
        b=b or {}; m=self.ctx.long_term_memory
        if b.get("record"):
            x=b["record"]; result=m.remember(str(x.get("trace_id") or __import__("uuid").uuid4()),str(x.get("decision","UNKNOWN")),float(x.get("confidence",0)),x.get("context") or {},str(x.get("outcome","PENDING")),x.get("reward"))
        elif b.get("outcome") and b.get("trace_id"):
            m.record_outcome(str(b["trace_id"]),str(b["outcome"]),float(b.get("reward",0))) ; result={"updated":True}
        else: result={"recent":m.recent(b.get("limit",30)),"knowledge":m.knowledge()}
        return {"ok":True,"memory":result,"state":self.ctx.state(),"action":self.ctx._log("V25_MEMORY")}

    def v26_research(self,b=None):
        b=b or {}; r=self.ctx.autonomous_research.run(b.get("bars"),b.get("hypotheses"),b.get("context")); return {"ok":r["status"]=="READY","research":r,"state":self.ctx.state(),"action":self.ctx._log("V26_AUTONOMOUS_RESEARCH",detail={"status":r["status"],"research_id":r["research_id"]})}

    def v27_repair(self,b=None):
        try:
            b=b or {}; target=Path(str(b.get("target_file"))) if b.get("target_file") else None
            if target and not target.is_absolute(): target=self.ctx.ROOT/target
            r=self.ctx.verified_repair.run(str(b.get("error") or b.get("traceback") or b.get("log") or ""),target,b.get("new_source"),bool(b.get("approve",False)))
            return {"ok":r.get("ok",False),"repair":r,"state":self.ctx.state(),"action":self.ctx._log("V27_VERIFIED_REPAIR","OK" if r.get("ok") else "BLOCKED",r)}
        except Exception as e: return self.ctx._fail("V27_VERIFIED_REPAIR",e)

    def v27_repair_status(self,b=None): return {"ok":True,"repair":self.ctx.verified_repair.status(),"state":self.ctx.state()}

    def alerts_recent(self,b=None):
        return {'ok':True,'alerts':self.ctx.alerts.recent((b or {}).get('limit',50)),'channels':{'dashboard':True,'telegram_configured':self.ctx.alerts.telegram_enabled,'sms_configured':self.ctx.alerts.sms_enabled,'whatsapp_configured':self.ctx.alerts.whatsapp_enabled,'email_configured':self.ctx.alerts.email_enabled},'thresholds':{'big_move_pct':self.ctx.alerts.big_move,'black_swan_move_pct':self.ctx.alerts.black_swan,'feed_stale_seconds':self.ctx.alerts.stale_seconds,'cooldown_seconds':self.ctx.alerts.cooldown},'state':self.ctx.state()}

    def alerts_config(self,b=None):
        return {'ok':True,'config':{'dashboard':True,'telegram_configured':self.ctx.alerts.telegram_enabled,'sms_configured':self.ctx.alerts.sms_enabled,'whatsapp_configured':self.ctx.alerts.whatsapp_enabled,'email_configured':self.ctx.alerts.email_enabled,'min_severity':self.ctx.alerts.min_severity,'big_move_pct':self.ctx.alerts.big_move,'black_swan_move_pct':self.ctx.alerts.black_swan,'feed_stale_seconds':self.ctx.alerts.stale_seconds,'cooldown_seconds':self.ctx.alerts.cooldown},'live_orders_enabled':False,'state':self.ctx.state()}

    def alerts_test(self,b=None):
        return {'ok':True,'result':self.ctx.alerts.emit('TEST','INFO','Alert test','Live alert channel test from the terminal.','manual-test',force=True),'state':self.ctx.state()}

    def alerts_emit(self,b=None):
        b=b or {}
        return {'ok':True,'result':self.ctx.alerts.emit(b.get('kind','UNDESIRABLE'),b.get('severity','CRITICAL'),b.get('title','Undesirable event'),b.get('message','An undesirable event was detected.'),b.get('dedupe_key'),bool(b.get('force',False))),'state':self.ctx.state()}
