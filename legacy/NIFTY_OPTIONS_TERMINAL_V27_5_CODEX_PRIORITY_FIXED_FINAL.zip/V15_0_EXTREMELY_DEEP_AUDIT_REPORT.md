# PASS 15 — Extremely Deep Audit Report

## Scope
Audited V14 source, repaired the Kotak session/data path, added broker-evidence NIFTY discovery, automatic option-chain acquisition, SFeed subscription planning, tick-quality soak monitoring, dashboard wiring, and regression compatibility.

## Critical defect found and repaired
V14's authentication path authenticated `ReadOnlyConnectionManager` but did not bind the authenticated SDK client to `TerminalBackend.adapter`. The feed path subsequently used `self.adapter.client`, which could be a separate unauthenticated SDK instance. Pass 15 now binds the same authenticated Kotak SDK client to the read-only adapter before any feed/read pipeline proceeds.

## Data-integrity controls
1. NIFTY underlying token must be returned by Kotak search evidence.
2. No hard-coded token fallback.
3. Option contracts require exchange segment, token, strike, option type and expiry.
4. Only `nse_fo` contracts enter SFeed subscription planning.
5. Duplicate subscription tokens are removed.
6. >3000 unique tokens fail closed.
7. Tick monitor records invalid LTP, duplicate local sequence, out-of-order local sequence and freshness.

## Safety controls
- LIVE_TRADING is hard-rejected when true.
- Browser cannot submit MPIN.
- No live order endpoint is exposed.
- No `place_order()` definition exists.
- No `live_orders_enabled=True` exists.
- Paper-only state is returned by V15 APIs.

## Verification results
- pytest: **207 passed**
- compileall: **PASS**
- HTTP `/api/health`: **PASS**, release `v15.0`
- V15 discover route: correctly fail-closed when unauthenticated in smoke test
- Dashboard IDs: **108**
- Dashboard handlers: **73**
- Missing handlers: **0**
- V15 backend routes: **4**
- Safety scan: **clean**

## Production credential test boundary
The build container did not execute a real Kotak login because that requires the user's live credentials/current TOTP and external network access. Therefore this audit does not claim that the user's Kotak account is authenticated or that a live SFeed is currently flowing.

## Decision
- Data architecture: **GO**
- Kotak read-only pipeline: **READY FOR LOCAL CREDENTIALED TEST**
- Paper trading: **GO**
- Live orders: **NO-GO**
- Autonomous live trading: **ABSOLUTE NO-GO**
