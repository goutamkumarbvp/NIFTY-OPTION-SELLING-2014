# V27.3 Post-Audit Hardening

This patch release addresses execution-based audit findings without enabling live trading.

## Security / Self-Repair
- Added OS-level Linux verification isolation using user, mount, PID and network namespaces plus chroot.
- Verification fails closed when required sandbox primitives are unavailable.
- Candidate security validation now uses AST capability checks for dangerous imports/calls and live-enabling environment mutation.
- Independent verifier supports candidate-file scoped capability validation.
- Repair workspace is created outside the source tree to prevent recursive self-copy contamination.

## Trading / Quant Correctness
- Option-chain identity now includes expiry and strike, preventing cross-expiry contract collisions.
- Paper LIMIT orders cannot fill through their limit price.
- Paper P&L separates realized and unrealized P&L for matched trades.
- Zero/unknown available margin fails closed in the deterministic risk gate.
- Market tick normalization rejects non-finite/non-positive LTP and invalid/crossed quotes.

## API / UI
- HTTP input parser rejects non-standard JSON NaN/Infinity constants.
- Dashboard data rendering moved from direct data-derived innerHTML to DOM textContent construction for the main dynamic panels.

## Memory
- V25 episode storage is bounded by MEMORY_MAX_EPISODES (default 10,000; capped at 100,000).

## Safety
- TRADING_MODE remains paper.
- LIVE_TRADING remains false.
- LIVE_ORDERS_ENABLED remains false.
- No real credentials, real broker orders, or real financial transactions are used by this release.
