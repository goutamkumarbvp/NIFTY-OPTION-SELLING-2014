# V27.3 CODEX CHECKER-3 Toughest Repair Notes

## Release safety
- Paper-only invariant remains enforced.
- `LIVE_TRADING=false` and `LIVE_ORDERS_ENABLED=false` are required.
- No real broker order endpoint was enabled or exercised.

## Repairs applied
1. Risk/account evidence is server-owned. Unauthenticated HTTP callers can no longer supply margin, available margin, or daily P&L authority to the RiskBrain.
2. Paper-entry execution requires a connected, fresh feed and a fresh instrument-matched market tick.
3. Paper fills are derived from the trusted tick price; caller-supplied fill price is accepted only when it matches the trusted price within 1%.
4. Risk now checks projected margin utilization, not only current utilization.
5. Paper risk evidence is rebuilt immediately before execution from the paper ledger.
6. Paper order check/risk/quote/ledger is serialized under the backend lock to prevent concurrent risk-gate bypasses.
7. Risk health is false when the snapshot contains non-finite or otherwise invalid account values.
8. Health endpoint now separates current runtime state from static capability metadata.
9. Self-repair verification excludes its own orchestration test file from nested pytest invocations to prevent recursive test execution while preserving separate self-repair tests.

## Verified evidence
- Critical/repair tests: PASS.
- Full release test inventory: 358 collected and executed successfully in test shards; no failed test was observed.
- Compilation: PASS.
- Independent security verifier: PASS, zero violations.
- Concurrent paper-order attack: 40 concurrent requests could not exceed the deterministic risk limit after serialization.
- Client-controlled margin attack: blocked by server-owned paper evidence and projected margin-utilization gate.
- Stale/no-feed paper entry: blocked.
- Fill-price mismatch against trusted tick: blocked.
- Restart: server restarted with clean paper state and live orders disabled.

## Remaining unverified areas
- Browser desktop/mobile E2E.
- Long-duration soak.
- Crash-at-database-commit / process-kill matrix.
- Real Kotak runtime.
- Real order placement (intentionally not tested).
- Clean online dependency installation in an unrestricted fresh-machine environment.

## Certification note
This repair does not claim production readiness. Remaining untested production-critical paths must be closed before any live-trading architecture is considered.
