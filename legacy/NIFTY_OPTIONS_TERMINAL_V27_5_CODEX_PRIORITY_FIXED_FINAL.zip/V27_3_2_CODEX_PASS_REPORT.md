# V27.3.2 Codex Re-Verification / Repair Report

## Scope
Independent execution against the V27.3.2 release tree. Paper-only safety configuration was preserved.

## Reproduced defect
The original V27.3.2 release's full pytest run could stall in the alert delivery path because `_twilio_message()` performed synchronous DNS/network work. A test using deliberately fake Twilio credentials entered `urllib.request.urlopen()` and could remain blocked in `socket.getaddrinfo()` despite the urllib timeout. This violated the requirement that alert delivery not block the application/test process.

## Repair
`alert_engine.py` now performs Twilio and Telegram network delivery on daemon worker threads and bounds the caller wait using `ALERT_DELIVERY_WAIT_SECONDS` (default 0.25s). The trading/risk path therefore fails closed/returns promptly instead of waiting on external DNS/network behavior.

## Verification
- Full pytest suite: **374 passed**
- Runtime: **33.25s**
- Exit code: **0**
- Python compile: verified after repair
- No test was deselected for the final run
- No production/live-order enablement was introduced

## Important boundary
This certifies the repaired release against the local automated suite. It does not certify real Kotak credentials, real S-FEED connectivity, Windows browser E2E, mobile/PWA E2E, long-duration soak, or live trading.
