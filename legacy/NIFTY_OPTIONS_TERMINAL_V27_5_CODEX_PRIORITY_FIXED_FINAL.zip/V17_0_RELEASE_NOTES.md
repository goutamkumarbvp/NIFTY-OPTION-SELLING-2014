# V17.0 — Agentic Memory, Tool Governance, Hypothesis Loop & Adversarial Self-Evaluation

PASS 17 evolves the V16 deterministic Super AI core into a bounded agentic research/control layer.

## Added
- Durable SQLite agent memory with bounded retention and secret-key redaction.
- Allow-listed read/research tool registry; execution/code-mutation tool names and high-risk tool calls are rejected.
- Hypothesis generation from supplied regime/options/strategy evidence only.
- Adversarial critic that attacks hypotheses using data-quality, feed-freshness and risk evidence.
- Self-evaluation of decision consistency and missing evidence.
- Trace IDs and decision-memory lineage.
- Backend APIs for agent loop, memory inspection and tool inspection.
- Dashboard controls for the PASS 17 agentic loop.

## Safety
- `LIVE_TRADING=false` remains mandatory for this release.
- No `place_order()` implementation is introduced.
- No live-order capability is exposed to the agent tool registry.
- No code mutation, shell execution or arbitrary eval/exec capability is exposed.
- Agent confidence is evidence confidence, not profit probability.
- Missing/unsafe dependencies fail closed to `NO TRADE` or `REVIEW`.

## Verification
- Full pytest regression: 235 passed.
- Python compileall: PASS.
- HTTP health/state: PASS.
- PASS 17 run/memory/tools APIs: PASS.
- Dashboard API references: 73; missing backend routes: 0.
- Live order definitions: 0.
- `live_orders_enabled=True` literals: 0.
