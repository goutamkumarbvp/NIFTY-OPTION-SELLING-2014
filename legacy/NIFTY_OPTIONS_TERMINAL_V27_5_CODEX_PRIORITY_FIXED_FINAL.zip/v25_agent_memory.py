from __future__ import annotations
"""V25 durable agent memory and bounded long-term learning."""
import hashlib, json, sqlite3, threading, time
from pathlib import Path
from typing import Any

class AgentLongTermMemory:
    VERSION="v25.0"
    def __init__(self,path: Path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self.lock=threading.RLock(); self.max_episodes=max(100,min(int(__import__('os').getenv('MEMORY_MAX_EPISODES','10000')),100000))
        with self._db() as c:
            c.execute("CREATE TABLE IF NOT EXISTS episodes(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, trace_id TEXT, decision TEXT, confidence REAL, context_hash TEXT, outcome TEXT, reward REAL, evidence TEXT)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_episodes_ts ON episodes(ts)")
            c.execute("CREATE TABLE IF NOT EXISTS hypotheses(key TEXT PRIMARY KEY, statement TEXT, tests INTEGER, successes INTEGER, failures INTEGER, updated REAL)")

    def _db(self): return sqlite3.connect(self.path,timeout=5)
    @staticmethod
    def _redact(obj):
        if isinstance(obj,dict): return {str(k):("[REDACTED]" if any(x in str(k).lower() for x in ("secret","password","token","api_key")) else AgentLongTermMemory._redact(v)) for k,v in obj.items()}
        if isinstance(obj,(list,tuple)): return [AgentLongTermMemory._redact(x) for x in obj]
        return obj
    def remember(self, trace_id:str, decision:str, confidence:float, context:dict[str,Any], outcome:str="PENDING", reward:float|None=None):
        safe=self._redact(context); blob=json.dumps(safe,sort_keys=True,separators=(",",":"),default=str); h=hashlib.sha256(blob.encode()).hexdigest()
        with self.lock, self._db() as c:
            c.execute("INSERT INTO episodes(ts,trace_id,decision,confidence,context_hash,outcome,reward,evidence) VALUES(?,?,?,?,?,?,?,?)",(time.time(),trace_id,decision,float(confidence),h,outcome,reward,blob))
            c.execute("DELETE FROM episodes WHERE id NOT IN (SELECT id FROM episodes ORDER BY id DESC LIMIT ?)",(self.max_episodes,))
        return {"context_hash":h,"outcome":outcome}
    def record_outcome(self,trace_id:str,outcome:str,reward:float):
        with self.lock, self._db() as c: c.execute("UPDATE episodes SET outcome=?,reward=? WHERE trace_id=?",(outcome,float(reward),trace_id))
    def recent(self,limit=50):
        with self.lock, self._db() as c:
            rows=c.execute("SELECT ts,trace_id,decision,confidence,outcome,reward,context_hash FROM episodes ORDER BY id DESC LIMIT ?",(max(1,min(int(limit),200)),)).fetchall()
        return [dict(zip(("ts","trace_id","decision","confidence","outcome","reward","context_hash"),r)) for r in rows]
    def learn(self, key:str, statement:str, success:bool):
        with self.lock, self._db() as c:
            row=c.execute("SELECT tests,successes,failures FROM hypotheses WHERE key=?",(key,)).fetchone()
            tests=(row[0] if row else 0)+1; successes=(row[1] if row else 0)+(1 if success else 0); failures=(row[2] if row else 0)+(0 if success else 1)
            c.execute("INSERT OR REPLACE INTO hypotheses VALUES(?,?,?,?,?,?)",(key,statement,tests,successes,failures,time.time()))
        return {"key":key,"tests":tests,"successes":successes,"failures":failures,"success_rate":successes/tests}
    def knowledge(self):
        with self.lock, self._db() as c:
            rows=c.execute("SELECT key,statement,tests,successes,failures,updated FROM hypotheses ORDER BY updated DESC LIMIT 100").fetchall()
        return [dict(zip(("key","statement","tests","successes","failures","updated"),r)) for r in rows]
