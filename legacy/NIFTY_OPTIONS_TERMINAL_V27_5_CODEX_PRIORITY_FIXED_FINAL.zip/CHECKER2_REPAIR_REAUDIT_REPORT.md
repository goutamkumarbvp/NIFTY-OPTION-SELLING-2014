# V27.3 Checker-2 Repair / Re-audit

## Confirmed defect repaired
The HTTP `paper_order` command previously called `PaperExecutionLedger.submit()` directly, bypassing `RiskBrain`.

Observed before repair: a synthetic `quantity=999999` order was accepted despite `max_order_qty=1500` and `max_position_qty=1500`.

## Repair
Every paper order now requires:
1. an existing valid risk snapshot;
2. an immediate re-evaluation against current paper positions;
3. `ALLOW_PAPER` from the deterministic RiskBrain;
4. NORMAL/non-paused execution state.

Rejected risk decisions do not reach the paper ledger.

## Verification
- `python3 -m compileall -q .` — PASS
- new paper execution/risk-gate tests — 4 PASS
- self-healing fault-injection tests — 5 PASS
- previous hardening/risk/quant tests — 28 PASS
- remaining original suite excluding long fault-injection file — 344 PASS
- aggregate post-repair tests executed across isolated runs — 353 PASS
- independent security verifier — PASS, 0 violations
- actual server `/api/health` — HTTP 200
- actual server oversized paper order after RiskGate — HTTP 409, no fill

## Remaining evidence gaps
Browser E2E, real Kotak connectivity, real OpenAI API, multi-hour soak, and crash-at-transaction-commit remain NOT TESTED.
