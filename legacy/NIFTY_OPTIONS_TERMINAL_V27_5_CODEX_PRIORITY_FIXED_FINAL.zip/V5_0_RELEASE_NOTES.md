# V5.0 — Options Intelligence + Regime + Advanced Risk

Adds a deterministic intelligence layer above V4.0 without enabling live order execution.

## Added
- Options Intelligence: PCR OI/ΔOI, support/resistance from OI, IV samples, liquidity score, data quality.
- Market Regime Engine: evidence-based BULL/BEAR/RANGE/UNKNOWN classification; no synthetic values.
- Strategy Brain upgraded to consume independent intelligence and liquidity evidence.
- Advanced Risk Brain: liquidity, spread, strategy-loss, delta/vega/theta and high-volatility policy gates.
- New API endpoints: `/api/intelligence/options`, `/api/intelligence/regime`, `/api/risk/advanced`.

## Safety
- Live order execution remains disabled.
- Missing evidence fails closed for advanced risk.
- No fabricated IV, regime, Greeks, P&L or strategy performance.
