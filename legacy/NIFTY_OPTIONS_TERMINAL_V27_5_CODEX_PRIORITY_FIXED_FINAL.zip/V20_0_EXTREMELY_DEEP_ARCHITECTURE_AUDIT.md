# V20.0 — Extremely Deep Architecture / Coupling Audit

## Scope
V19.0 was audited and refactored to remove the remaining application-backend concentration identified in V19. The goal is application-service decomposition while preserving the existing public `TerminalBackend` facade and all historical API commands.

## Implemented
- `market_service.py`: broker, feed, option-chain and market I/O boundary.
- `intelligence_service.py`: risk, strategy, options, quant and intelligence boundary.
- `research_service.py`: historical/research/backtest/data boundary.
- `ai_service.py`: Super AI, agentic memory/tools, alerts and verified self-repair boundary.
- `terminal_backend.py`: composition/state coordinator and thin compatibility facade.
- `server.py`: HTTP transport only.
- Added V20 architecture contract tests covering forbidden imports, service cross-imports, bounded fan-out and backend instantiation isolation.

## Measured dependency fan-out
| Module | Production-module imports |
|---|---:|
| server.py | 1 |
| terminal_backend.py | 5 service/lifecycle boundaries |
| market_service.py | 7 |
| intelligence_service.py | 9 |
| research_service.py | 13 |
| ai_service.py | 4 |

V19 `server.py` had already been reduced to transport-only, but V19 `terminal_backend.py` still directly imported and instantiated most domain engines. V20 removes those direct domain imports and moves construction/logic ownership into four service boundaries.

## Boundary invariants
- Services do not import `server` or `terminal_backend`.
- Services do not import one another.
- Domain modules do not import `server`.
- `server.py` does not import trading/domain engines.
- `terminal_backend.py` contains no direct domain-class construction for the extracted components.
- Existing public backend methods remain available through a thin facade, preserving compatibility.
- Live order execution remains disabled.

## Verification
- Full pytest suite: **285/285 PASS**
- Python compilation: **PASS**
- Architecture contract tests: **10/10 PASS**
- Circular/boundary checks: **PASS**
- Existing V2–V19 regression suite: **PASS**
- Live orders: **FALSE**

## Remaining coupling
The service modules intentionally depend on their own domain implementations. This is normal composition-level coupling, not cross-domain coupling. The next possible improvement would be replacing concrete domain imports inside each service with explicit Protocol/port interfaces and event DTOs. That is a separate dependency-inversion pass and was not falsely claimed as complete in V20.
