from market_intelligence import chain_metrics
from options_intelligence import OptionsIntelligence

def test_delta_oi_pcr_exact_requested_formula_with_negative_ce_delta():
    chain=[{"strike":25000,"ce":{"oi":1000,"doi":-100,"ltp":100,"bid":99,"ask":101,"volume":100},"pe":{"oi":1200,"doi":200,"ltp":90,"bid":89,"ask":91,"volume":100}}]
    m=chain_metrics(chain)
    assert m["call_doi"] == -100 and m["put_doi"] == 200
    assert m["pcr_doi"] == -2.0
    assert m["pcr_change_oi"] == -2.0
    oi=OptionsIntelligence().analyze(chain,25000)
    assert oi["pcr_doi"] == -2.0 and oi["pcr_change_oi"] == -2.0

def test_delta_oi_pcr_undefined_only_when_ce_delta_zero():
    chain=[{"strike":25000,"ce":{"oi":1000,"doi":0},"pe":{"oi":1200,"doi":200}}]
    m=chain_metrics(chain)
    assert m["pcr_doi"] is None


def test_delta_oi_pcr_zero_ce_change_is_not_zero_or_infinity():
    chain=[{"strike":25000,"ce":{"oi":1000,"doi":0,"ltp":100,"bid":99,"ask":101,"volume":100},"pe":{"oi":1200,"doi":-50,"ltp":90,"bid":89,"ask":91,"volume":100}}]
    oi=OptionsIntelligence().analyze(chain,25000)
    assert oi["pcr_doi"] is None

def test_kotak_v15_chain_preserves_oi_change_fields_for_pcr_pipeline():
    from pass15_engine import KotakResponseExtractor
    raw={'data':[{'exchange_segment':'nse_fo','instrument_token':'101','strike_price':25000,'option_type':'CE','expiry':'2026-09-24','last_traded_price':100,'open_interest':1000,'change_in_oi':-100,'volume':500},
                 {'exchange_segment':'nse_fo','instrument_token':'102','strike_price':25000,'option_type':'PE','expiry':'2026-09-24','last_traded_price':90,'open_interest':1200,'change_in_oi':200,'volume':600}]}
    c=KotakResponseExtractor.option_contracts(raw)
    assert c[0]['doi']==-100 and c[1]['doi']==200
