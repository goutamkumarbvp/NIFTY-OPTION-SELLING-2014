import unittest
from super_ai_agent import ExtremeSuperAgent

class V23SuperAITests(unittest.TestCase):
    def setUp(self): self.a=ExtremeSuperAgent()
    def ctx(self):
        return {'state':{'paper_only':True,'live_orders_enabled':False,'mode':'NORMAL','feed':{'connected':True,'fresh':True}},
                'intelligence':{'data_quality':.95,'pcr_oi':1.1,'pcr_doi':1.3},
                'regime':{'regime':'RANGE','confidence':.8},
                'plan':{'status':'TRADE','candidates':[{'type':'IRON_CONDOR'}]},
                'advanced_risk':{'decision':'ALLOW'}}
    def test_four_specialists(self):
        r=self.a.run(**self.ctx()); self.assertEqual(len(r['specialists']),4)
        self.assertEqual(r['decision']['decision'],'PAPER CANDIDATE')
    def test_diagnosis_stale(self):
        c=self.ctx(); c['state']['feed']['fresh']=False
        r=self.a.run(**c); self.assertEqual(r['decision']['decision'],'NO TRADE'); self.assertIn('market feed stale',r['diagnostic']['root_causes'])
    def test_safety_is_hard(self):
        c=self.ctx(); c['state']['live_orders_enabled']=True
        r=self.a.run(**c); self.assertEqual(r['decision']['decision'],'NO TRADE'); self.assertFalse(r['policy']['live_orders_enabled'])
    def test_risk_block(self):
        c=self.ctx(); c['advanced_risk']['decision']='BLOCK'
        self.assertEqual(self.a.run(**c)['decision']['decision'],'NO TRADE')
    def test_action_plan(self):
        r=self.a.run(**self.ctx()); self.assertGreaterEqual(len(r['action_plan']),1); self.assertEqual(r['autonomy']['level'],3)
    def test_learning(self):
        self.a.run(**self.ctx()); self.a.run(**self.ctx()); self.assertEqual(self.a.last['learning']['prior_decisions'],1)
    def test_no_execution_capability(self):
        r=self.a.run(**self.ctx()); self.assertFalse(r['policy']['order_placement']); self.assertFalse(r['policy']['code_mutation']); self.assertFalse(r['autonomy']['live_execution'])
    def test_pcr_doi(self): self.assertIn('PCR(ΔOI)=1.300',self.a.run(**self.ctx())['decision']['evidence'])

if __name__=='__main__': unittest.main()
