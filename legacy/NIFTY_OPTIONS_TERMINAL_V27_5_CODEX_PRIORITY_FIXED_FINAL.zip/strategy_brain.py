from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
from math import isfinite

@dataclass(frozen=True)
class StrategyConfig:
    min_score: float=6.0
    min_data_quality: float=0.75
    min_liquidity_score: float=0.55
    max_strike_distance: float=500.0

class StrategyBrain:
    """Deterministic strategy planner. It consumes independent intelligence and NEVER executes."""
    def __init__(self,config:StrategyConfig|None=None): self.config=config or StrategyConfig(); self.last_plan={'status':'NO_DATA','candidates':[]}
    @staticmethod
    def _num(v):
        try:
            x=float(v); return x if isfinite(x) else None
        except (TypeError,ValueError): return None
    def analyze(self,chain:list[dict],spot:float|None=None,regime='UNKNOWN',intelligence:dict|None=None)->dict[str,Any]:
        if not isinstance(chain,list) or len(chain)<3:return self._set({'status':'BLOCKED','reason':'INSUFFICIENT_OPTION_CHAIN','candidates':[]})
        rows=[]
        for r in chain:
            if not isinstance(r,dict):continue
            s=self._num(r.get('strike')); ce=r.get('ce') or {}; pe=r.get('pe') or {}
            if s is not None: rows.append((s,ce,pe))
        if not rows or self._num(spot) is None:return self._set({'status':'BLOCKED','reason':'SPOT_REQUIRED' if spot is None else 'NO_VALID_STRIKES','candidates':[]})
        spot=float(spot); intel=intelligence or {}; pcr=self._num(intel.get('pcr_oi')); pcr_doi=self._num(intel.get('pcr_doi')); quality=self._num(intel.get('data_quality')) or 0; liq=self._num(intel.get('liquidity_score')) or 0
        reg=str(regime or 'UNKNOWN').upper(); bias='bullish' if 'BULL' in reg else ('bearish' if 'BEAR' in reg else ('bullish' if pcr and pcr>=1.15 else ('bearish' if pcr and pcr<=.85 else 'neutral')))
        spacing=min([b-a for a,b in zip(sorted({x[0] for x in rows}),sorted({x[0] for x in rows})[1:]) if b>a] or [0])
        c=[]
        if bias in ('bullish','neutral'):
            ps=[x for x in rows if x[0]<spot and abs(x[0]-spot)<=self.config.max_strike_distance and (self._num(x[2].get('oi')) or 0)>0]
            if ps:
                s=max(ps,key=lambda x:(self._num(x[2].get('oi')) or 0,-abs(x[0]-spot)))[0]; c.append(self._candidate('SHORT_PUT',bias,s,None,pcr,pcr_doi,quality,liq,spacing,reg))
        if bias in ('bearish','neutral'):
            cs=[x for x in rows if x[0]>spot and abs(x[0]-spot)<=self.config.max_strike_distance and (self._num(x[1].get('oi')) or 0)>0]
            if cs:
                s=min(cs,key=lambda x:abs(x[0]-spot))[0]; c.append(self._candidate('SHORT_CALL',bias,None,s,pcr,pcr_doi,quality,liq,spacing,reg))
        if bias=='neutral' and len(c)>=2:c.append(self._candidate('IRON_CONDOR_CANDIDATE','neutral',c[0]['short_put_strike'],c[1]['short_call_strike'],pcr,pcr_doi,quality,liq,spacing,reg))
        c.sort(key=lambda x:x['score'],reverse=True); status='READY' if c and c[0]['score']>=self.config.min_score and quality>=self.config.min_data_quality and liq>=self.config.min_liquidity_score else 'NO_TRADE'
        return self._set({'status':status,'spot':spot,'regime':reg,'directional_bias':bias,'data_quality':quality,'liquidity_score':liq,'metrics':intel,'candidates':c,'risk_gate_required':True,'execution':'DISABLED'})
    def _candidate(self,kind,bias,put,call,pcr,pd,q,liq,spacing,reg):
        score=0.; reasons=[]
        if q>=.9:score+=3;reasons.append('high_chain_data_quality')
        elif q>=.75:score+=2;reasons.append('acceptable_chain_data_quality')
        if liq>=.8:score+=2;reasons.append('strong_liquidity')
        elif liq>=.55:score+=1;reasons.append('acceptable_liquidity')
        if pcr is not None and ((bias=='bullish' and pcr>=1.15) or (bias=='bearish' and pcr<=.85) or (bias=='neutral' and .9<=pcr<=1.1)):score+=2;reasons.append('pcr_confirmation')
        if pd is not None and ((bias=='bullish' and pd>=1) or (bias=='bearish' and pd<=1) or (bias=='neutral' and .8<=pd<=1.25)):score+=1;reasons.append('delta_oi_confirmation')
        if spacing>0:score+=1;reasons.append('valid_strike_grid')
        if 'HIGH_VOL' in reg: reasons.append('high_volatility_requires_stricter_risk')
        return {'type':kind,'bias':bias,'score':round(score,2),'short_put_strike':put,'short_call_strike':call,'reasons':reasons,'risk_gate_required':True,'execution':'DISABLED'}
    def _set(self,p):self.last_plan=p;return p
    def health(self):return {'healthy':True,'execution_enabled':False,'config':asdict(self.config),'last_status':self.last_plan.get('status')}
