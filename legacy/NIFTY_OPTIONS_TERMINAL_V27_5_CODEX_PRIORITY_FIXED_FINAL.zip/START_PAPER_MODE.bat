@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  python -m venv .venv
  if errorlevel 1 exit /b 1
)
call .venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
set "TRADING_MODE=paper"
set "LIVE_TRADING=false"
set "LIVE_ORDERS_ENABLED=false"
set "PAPER_AUTO_SELF_REPAIR=true"
set "SELF_REPAIR_AUTO_PROMOTE=false"
set "BIND_HOST=127.0.0.1"
set "PORT=8500"
echo ================================================================
echo   NIFTY OPTIONS TERMINAL V27.3.1 - SAFE PAPER MODE
echo ================================================================
echo   LIVE_TRADING=false
 echo   LIVE_ORDERS_ENABLED=false
 echo   PAPER_AUTO_SELF_REPAIR=true
 echo   SELF_REPAIR_AUTO_PROMOTE=false
echo ================================================================
.venv\Scripts\python.exe -m compileall -q .
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe server.py
exit /b %errorlevel%
