#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Keep pytest isolated from globally installed plugins. Some host plugins can
# retain background resources and make an otherwise-complete suite appear to hang.
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PYTHONFAULTHANDLER=1
# Bound the test runner so a future teardown regression cannot block CI forever.
# The application itself remains unchanged; this is a release-test safety net.
exec timeout --foreground --signal=TERM --kill-after=5s 180s python3 -m pytest -q "$@"
