from research_data import HistoricalDataValidator, HistoricalDataStore
from options_backtest import OptionBacktester
from walk_forward import WalkForwardValidator
from stress_monte_carlo import StressEngine
import tempfile, os

def bars(n=6): return [{'timestamp':f'2026-01-01T09:{10+i:02d}:00+05:30','open':100+i,'high':101+i,'low':99+i,'close':100.5+i,'volume':100} for i in range(n)]
def test_validator_ready(): assert HistoricalDataValidator.validate(bars())['status']=='READY'
def test_validator_nonmonotonic():
 x=bars(); x[2]['timestamp']=x[1]['timestamp']; assert HistoricalDataValidator.validate(x)['reason']=='NON_MONOTONIC_TIMESTAMP'
def test_validator_ohlc():
 x=bars(); x[1]['high']=1; assert HistoricalDataValidator.validate(x)['reason']=='INVALID_OHLC'
def test_store_roundtrip():
 with tempfile.TemporaryDirectory() as d:
  s=HistoricalDataStore(d); a=s.ingest('x',bars()); assert a['status']=='READY'; assert s.read('x')['status']=='READY'
def test_store_no_overwrite():
 with tempfile.TemporaryDirectory() as d:
  s=HistoricalDataStore(d); s.ingest('x',bars()); assert s.ingest('x',bars())['reason']=='DATASET_EXISTS'
def test_option_bt_requires_quotes(): assert OptionBacktester().run([{'bid':1,'ask':2}]*3,[1,0,-1])['status']=='READY'
def test_option_bt_missing_quotes(): assert OptionBacktester().run([{'bid':1,'ask':2},{'bid':1,'ask':2},{}],[1,0,-1])['reason']=='MISSING_BID_ASK'
def test_option_bt_invalid_quote(): assert OptionBacktester().run([{'bid':1,'ask':2},{'bid':3,'ask':2},{'bid':1,'ask':2}],[1,0,-1])['reason']=='INVALID_BID_ASK'
def test_option_bt_next_bar_rule():
 x=OptionBacktester().run([{'bid':1,'ask':2},{'bid':10,'ask':11},{'bid':5,'ask':6}],[1,-1,0]); assert x['trades'][0]['entry']==11.011

def test_wf_split(): assert len(WalkForwardValidator().split(list(range(150)))['windows'])==2
def test_wf_insufficient(): assert WalkForwardValidator().split(list(range(20)))['status']=='BLOCKED'
def test_wf_invalid_config(): assert WalkForwardValidator(type('C',(),{'train_bars':0,'test_bars':1,'step':1})()).split(list(range(10)))['status']=='BLOCKED'
def test_wf_eval():
 x=WalkForwardValidator(type('C',(),{'train_bars':4,'test_bars':2,'step':2})()).evaluate(list(range(10)),lambda tr:{'score':len(tr),'test_score':2}); assert x['status']=='READY' and x['avg_test_score']==2

def test_stress_ready(): assert StressEngine().deterministic(0,delta=1,price=100,vol=.2)['status']=='READY'
def test_stress_worst(): assert StressEngine().deterministic(0,delta=1,price=100,vol=.2)['worst_case']<0
def test_mc_ready(): assert StressEngine().monte_carlo([10,-5,3])['status']=='READY'
def test_mc_deterministic_seed():
 a=StressEngine().monte_carlo([10,-5,3]); b=StressEngine().monte_carlo([10,-5,3]); assert a==b
