from __future__ import annotations
from dataclasses import dataclass
from math import isfinite

@dataclass(frozen=True)
class OptionBacktestConfig:
    initial_capital: float=1_000_000.0
    fee_per_contract: float=20.0
    slippage_pct: float=0.001
    lot_size: int=75
    max_loss_per_trade: float=50_000.0

class OptionBacktester:
    """Evidence-based option trade simulator. Entries use next bar bid/ask; missing quote blocks."""
    def __init__(self,config=None): self.config=config or OptionBacktestConfig()
    def run(self,bars,signals):
        if not isinstance(bars,list) or len(bars)<3 or len(signals)!=len(bars): return {'status':'BLOCKED','reason':'INVALID_INPUT'}
        cap=self.config.initial_capital; trades=[]; eq=[cap]; pos=None
        for i in range(len(bars)-1):
            s=signals[i]
            if s not in (-1,0,1): return {'status':'BLOCKED','reason':'INVALID_SIGNAL'}
            b=bars[i+1]
            try: bid=float(b['bid']); ask=float(b['ask']);
            except (KeyError,TypeError,ValueError): return {'status':'BLOCKED','reason':'MISSING_BID_ASK'}
            if not all(isfinite(x) and x>0 for x in (bid,ask)) or ask<bid: return {'status':'BLOCKED','reason':'INVALID_BID_ASK'}
            if pos is None and s==1:
                entry=ask*(1+self.config.slippage_pct); pos={'entry':entry,'i':i+1}
            elif pos is not None and s==-1:
                exitp=bid*(1-self.config.slippage_pct); pnl=(exitp-pos['entry'])*self.config.lot_size-self.config.fee_per_contract; cap+=pnl
                trades.append({'entry_index':pos['i'],'exit_index':i+1,'entry':pos['entry'],'exit':exitp,'pnl':pnl}); pos=None
            eq.append(cap)
        if pos is not None: trades.append({'entry_index':pos['i'],'open':True})
        peak=eq[0]; dd=0
        for e in eq: peak=max(peak,e); dd=max(dd,(peak-e)/peak if peak else 0)
        closed=[t for t in trades if 'pnl' in t]
        return {'status':'READY','initial_capital':self.config.initial_capital,'final_capital':cap,'total_pnl':cap-self.config.initial_capital,'closed_trades':len(closed),'open_trades':len(trades)-len(closed),'max_drawdown_pct':dd,'trades':trades,'equity_curve':eq,'fill_rule':'long entry=next-bar ask; exit=next-bar bid','lookahead_protection':True}
