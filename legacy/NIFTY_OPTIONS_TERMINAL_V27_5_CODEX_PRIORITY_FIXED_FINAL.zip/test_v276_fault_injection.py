import time
from self_healing import SelfHealingSupervisor

BASE = {'authenticated': True, 'feed_enabled': True, 'feed_thread_alive': True,
        'connected': True, 'age': 0, 'market_status': 'OPEN', 'mode': 'NORMAL', 'paused': False}

def _run(h, repair, duration=1.0, max_recoveries=5, window_seconds=30.0):
    calls=[]
    def health(): return dict(h)
    def recover(): calls.append(1); return repair(h)
    s=SelfHealingSupervisor(health, recover, interval=.5, stale_seconds=2,
                            cooldown_seconds=2, max_recoveries=max_recoveries,
                            window_seconds=window_seconds)
    s.start(); s.arm(); time.sleep(duration); s.stop()
    # The helper owns the supervisor lifecycle; require deterministic shutdown
    # so the test suite cannot leave a non-daemon worker behind.
    thread = getattr(s, '_thread', None)
    if thread is not None:
        thread.join(timeout=2)
        assert not thread.is_alive(), 'self-healing worker failed to stop'
    return calls, s.snapshot()

def test_nonfinite_feed_age_is_not_healthy():
    for bad in ('nan', float('nan'), float('inf'), -1):
        h=dict(BASE, age=bad)
        calls, snap=_run(h, lambda h: (h.update(age=0) or {'ok': True}))
        assert len(calls) == 1
        assert snap['status'] == 'HEALTHY'
        assert snap['recoveries'] == 1

def test_false_success_never_becomes_healthy():
    h=dict(BASE, feed_thread_alive=False, connected=False, age=99)
    calls, snap=_run(h, lambda h: {'ok': True})
    assert len(calls) == 1
    assert snap['recoveries'] == 0
    assert snap['failures'] == 1
    assert snap['status'] != 'HEALTHY'

def test_recovery_exception_never_becomes_healthy():
    h=dict(BASE, feed_thread_alive=False, connected=False, age=99)
    def boom(_): raise RuntimeError('boom')
    calls, snap=_run(h, boom)
    assert len(calls) == 1
    assert snap['recoveries'] == 0
    assert snap['failures'] == 1
    assert snap['status'] != 'HEALTHY'

def test_repeated_failed_recovery_opens_circuit():
    h=dict(BASE, feed_thread_alive=False, connected=False, age=99)
    calls, snap=_run(h, lambda h: {'ok': False, 'error': 'boom'}, duration=6.5, max_recoveries=2)
    assert len(calls) == 2
    assert snap['circuit_open'] is True
    assert snap['status'] == 'CIRCUIT_OPEN'
    assert snap['recoveries'] == 0
    assert snap['consecutive_failures'] == 2

def test_recovery_cannot_promote_stale_feed_to_healthy():
    h=dict(BASE, age=99)
    calls=[]
    def health(): return dict(h)
    def recover():
        calls.append(1)
        h.update(feed_thread_alive=True, connected=True, age=99)
        return {'ok': True}
    s=SelfHealingSupervisor(health, recover, interval=.5, stale_seconds=2,
                            cooldown_seconds=2, max_recoveries=5)
    s.start(); s.arm(); time.sleep(1.2); s.stop()
    snap=s.snapshot()
    assert len(calls) == 1
    assert snap['recoveries'] == 0
    assert snap['failures'] == 1
    assert snap['status'] != 'HEALTHY'
    assert snap['last_error'] == 'recovery verification failed'
