# NIFTY OPTIONS TERMINAL V14.0 — RELEASE NOTES

## Scope
Pass 14 hardens the Kotak Neo integration as a **read-only / paper-only connectivity layer**.

## Implemented
- Canonical `NEO_*` environment configuration.
- Hard fail if `LIVE_TRADING=true`.
- MPIN is loaded only from local environment; HTTP/browser requests never accept MPIN.
- Optional TOTP-secret generation using `pyotp`; URL-encoded TOTP secrets are decoded before use.
- Secret redaction for diagnostics.
- Read-only connection manager for authentication and account/market reads.
- Explicit read-only endpoints for config/status/positions/holdings/limits/expiries/option-chain/quotes.
- Feed freshness and connection state model.
- Tick-quality counters for duplicate/out-of-order/invalid observations.
- Dashboard Pass-14 controls.
- No order-placement method exposed through Pass-14 manager/API.
- `LIVE_TRADING=false` remains a hard application invariant.

## Kotak SDK baseline
Target: official `kotakneoapi` 3.0.6+ / modern SFeed API.
The current official SDK documents TOTP authentication and async SFeed WebSocket streaming.

## Verification
- Full regression: **200/200 PASS**
- Python compile: **PASS**
- HTTP `/api/health`: **PASS**
- HTTP `/api/state`: **PASS**
- V14 config route: **PASS**
- V14 status route: **PASS**
- Dashboard IDs: **103**
- Dashboard handlers: **69**
- Missing handlers: **0**
- Dashboard API references with missing backend routes: **0**
- `place_order()` definitions: **0** (production source scan)
- `live_orders_enabled=True`: **0**
- Credentialed Kotak production login: **NOT EXECUTED in build environment**; credentials are not bundled or logged.

## Safety decision
- Research/data infrastructure: **GO**
- Kotak read-only connectivity layer: **READY FOR LOCAL CREDENTIAL TEST**
- Paper execution: **GO**
- Live order execution: **NO-GO**
- Autonomous trading: **ABSOLUTE NO-GO**
