import time, unittest
from self_healing import SelfHealingSupervisor

class T(unittest.TestCase):
    def test_recovers_dead_feed(self):
        h={'authenticated':True,'feed_enabled':True,'feed_thread_alive':False,'connected':False,'age':99,'market_status':'OPEN','mode':'NORMAL','paused':False}
        calls=[]
        def health(): return dict(h)
        def recover(): calls.append(1); h.update(feed_thread_alive=True,connected=True,age=0); return {'ok':True}
        s=SelfHealingSupervisor(health,recover,interval=.05,stale_seconds=1,cooldown_seconds=2,max_recoveries=2)
        s.start(); s.arm(); time.sleep(1.5); s.stop()
        self.assertEqual(len(calls),1); self.assertEqual(s.snapshot()['status'],'HEALTHY')

    def test_never_heals_emergency(self):
        h={'authenticated':True,'feed_enabled':True,'feed_thread_alive':False,'connected':False,'age':99,'market_status':'OPEN','mode':'EMERGENCY','paused':True}
        calls=[]
        s=SelfHealingSupervisor(lambda:dict(h),lambda:(calls.append(1) or {'ok':True}),interval=.05,stale_seconds=1)
        s.start(); s.arm(); time.sleep(.2); s.stop()
        self.assertEqual(calls,[])

    def test_circuit_breaker(self):
        h={'authenticated':True,'feed_enabled':True,'feed_thread_alive':False,'connected':False,'age':99,'market_status':'OPEN','mode':'NORMAL','paused':False}
        calls=[]
        s=SelfHealingSupervisor(lambda:dict(h),lambda:(calls.append(1) or {'ok':False,'error':'x'}),interval=.05,stale_seconds=1,cooldown_seconds=1,max_recoveries=2)
        s.start(); s.arm(); time.sleep(4.0); s.stop()
        self.assertEqual(s.snapshot()['status'],'CIRCUIT_OPEN'); self.assertGreaterEqual(len(calls),2)

if __name__=='__main__': unittest.main()
