from __future__ import annotations
import os

from service_contracts import IntelligenceDependencies

class Intelligence:
    """Application service boundary. Trading components are reached only through the injected context."""
    def __init__(self, ctx, deps: IntelligenceDependencies):
        self.ctx = ctx; self.deps = deps; c=ctx
        c.risk_brain=deps.risk_brain; c.advanced_risk=deps.advanced_risk; c.risk_snapshot=None
        c.strategy_brain=deps.strategy_brain; c.options_intel=deps.options_intel; c.regime_engine=deps.regime_engine
        c.last_intelligence={'status':'NO_DATA'}; c.last_regime={'regime':'UNKNOWN','confidence':0}; c.last_advanced_risk=None; c.last_plan=None
        c.quant=deps.quant; c.vol_surface=deps.vol_surface; c.event_intel=deps.event_intel; c.fii_dii=deps.fii_dii

    def risk_evaluate(self,b=None):
        try:
            # Account/risk evidence is never authoritative from HTTP input.
            # Authenticated mode reads broker-owned positions/limits; paper mode
            # uses the server-owned paper-account ledger/evidence. Client-supplied
            # limits and daily_pnl are intentionally ignored.
            if self.ctx.authenticated:
                if not self.ctx.broker_positions:
                    self.ctx.broker_positions=self.ctx.adapter.positions()
                limits=self.ctx.adapter.limits()
                daily_pnl=getattr(self.ctx, 'broker_daily_pnl', 0.0)
                positions=self.ctx.broker_positions
            else:
                evidence=self.ctx.paper_risk_evidence()
                limits=evidence['limits']
                daily_pnl=evidence['daily_pnl']
                positions=evidence['positions']
            self.ctx.risk_snapshot=self.ctx.risk_brain.snapshot(positions,limits,daily_pnl)
            decision=self.ctx.risk_brain.evaluate(self.ctx.risk_snapshot,b.get('order',{}))
            if decision['decision']=='BLOCK': self.ctx.mode='PAUSED' if self.ctx.mode!='EMERGENCY' else self.ctx.mode
            self.ctx.alerts.evaluate_risk(decision, daily_pnl, b.get('stop_loss', os.getenv('DAILY_MAX_LOSS','2500')), b.get('trade_pnl'), b.get('trade_stop_loss'))
            return {'ok':True,'decision':decision,'snapshot':self.ctx.risk_snapshot.__dict__,'health':self.ctx.risk_brain.health(self.ctx.risk_snapshot),'state':self.ctx.state(),'action':self.ctx._log('RISK_EVALUATE',detail=decision)}
        except Exception as e:return self.ctx._fail('RISK_EVALUATE',e)

    def options_intelligence(self,b=None):
        try:
            spot=self.ctx.state()['market'].get('nifty')
            self.ctx.last_intelligence=self.ctx.options_intel.analyze(self.ctx.chain,spot)
            return {'ok':self.ctx.last_intelligence.get('status')!='BLOCKED','intelligence':self.ctx.last_intelligence,'state':self.ctx.state(),'action':self.ctx._log('OPTIONS_INTELLIGENCE',detail={'status':self.ctx.last_intelligence.get('status')})}
        except Exception as e:return self.ctx._fail('OPTIONS_INTELLIGENCE',e)

    def regime_analyze(self,b=None):
        try:
            m=self.ctx.state()['market']; intel=self.ctx.last_intelligence
            self.ctx.last_regime=self.ctx.regime_engine.classify(spot=m.get('nifty'),prev_close=b.get('prev_close'),pcr=intel.get('pcr_oi'),iv=intel.get('iv_mean'),breadth=b.get('breadth'),trend=b.get('trend'))
            return {'ok':True,'regime':self.ctx.last_regime,'state':self.ctx.state(),'action':self.ctx._log('MARKET_REGIME_ANALYZE',detail={'regime':self.ctx.last_regime.get('regime')})}
        except Exception as e:return self.ctx._fail('MARKET_REGIME_ANALYZE',e)

    def advanced_risk_evaluate(self,b=None):
        try:
            if not self.ctx.last_intelligence or self.ctx.last_intelligence.get('status')=='NO_DATA': self.ctx.options_intelligence()
            plan=self.ctx.last_plan or self.ctx.strategy_brain.last_plan
            self.ctx.last_advanced_risk=self.ctx.advanced_risk.evaluate(plan,liquidity_score=self.ctx.last_intelligence.get('liquidity_score'),spread_pct=b.get('spread_pct'),delta=b.get('delta'),vega=b.get('vega'),theta=b.get('theta'),estimated_max_loss=b.get('estimated_max_loss'),high_vol='HIGH_VOL' in str(self.ctx.last_regime.get('regime','')))
            if self.ctx.last_advanced_risk['decision']=='BLOCK' and self.ctx.mode!='EMERGENCY': self.ctx.mode='PAUSED'
            return {'ok':True,'decision':self.ctx.last_advanced_risk,'state':self.ctx.state(),'action':self.ctx._log('ADVANCED_RISK_EVALUATE',detail=self.ctx.last_advanced_risk)}
        except Exception as e:return self.ctx._fail('ADVANCED_RISK_EVALUATE',e)

    def strategy_analyze(self,b=None):
        try:
            m=self.ctx.state()['market']; spot=m.get('nifty')
            if not self.ctx.last_intelligence.get('status') in {'READY','DEGRADED'}: self.ctx.last_intelligence=self.ctx.options_intel.analyze(self.ctx.chain,spot)
            plan=self.ctx.strategy_brain.analyze(self.ctx.chain, spot=spot, regime=self.ctx.last_regime.get('regime','UNKNOWN'), intelligence=self.ctx.last_intelligence)
            self.ctx.last_plan=plan
            if isinstance(plan,dict) and plan.get('candidates'):
                top=plan['candidates'][0] if isinstance(plan['candidates'][0],dict) else {'type':str(plan['candidates'][0])}
                fingerprint=hashlib.sha256(json.dumps(top,sort_keys=True,default=str).encode()).hexdigest()[:16]
                self.ctx.alerts.new_trade(plan, trace=fingerprint)
            # Strategy Brain cannot override Risk Brain or enable execution.
            return {'ok':True,'plan':plan,'risk_gate':'REQUIRED','execution':'DISABLED','state':self.ctx.state(),'action':self.ctx._log('STRATEGY_ANALYZE',detail={'status':plan.get('status')})}
        except Exception as e: return self.ctx._fail('STRATEGY_ANALYZE',e)

    def quant_greeks(self,b=None):
        try:
            req=['spot','strike','time_to_expiry','rate','iv']
            if any(k not in b for k in req): raise ValueError('GREEKS_INPUTS_REQUIRED')
            g=self.ctx.quant.greeks(float(b['spot']),float(b['strike']),float(b['time_to_expiry']),float(b['rate']),float(b['iv']),float(b.get('dividend_yield',0)),str(b.get('option_type','CE')).upper()=='CE')
            self.ctx.last_greeks=g.__dict__; return {'ok':True,'greeks':self.ctx.last_greeks,'source':'black_scholes_dividend_adjusted','state':self.ctx.state(),'action':self.ctx._log('QUANT_GREEKS')}
        except Exception as e:return self.ctx._fail('QUANT_GREEKS',e)

    def quant_iv(self,b=None):
        try:
            req=['market_price','spot','strike','time_to_expiry','rate']
            if any(k not in b for k in req): raise ValueError('IV_INPUTS_REQUIRED')
            iv=self.ctx.quant.implied_vol(float(b['market_price']),float(b['spot']),float(b['strike']),float(b['time_to_expiry']),float(b['rate']),float(b.get('dividend_yield',0)),str(b.get('option_type','CE')).upper()=='CE')
            if iv is None: return {'ok':False,'error':'IV_NO_ARBITRAGE_SOLUTION','state':self.ctx.state()}
            return {'ok':True,'iv':iv,'method':'bounded_bisection','state':self.ctx.state(),'action':self.ctx._log('QUANT_IMPLIED_VOL')}
        except Exception as e:return self.ctx._fail('QUANT_IMPLIED_VOL',e)

    def surface_load(self,b=None):
        try:
            self.ctx.last_surface=self.ctx.vol_surface.load(b.get('points'))
            return {'ok':self.ctx.last_surface['status']=='READY','surface':self.ctx.last_surface,'state':self.ctx.state(),'action':self.ctx._log('VOL_SURFACE_LOAD')}
        except Exception as e:return self.ctx._fail('VOL_SURFACE_LOAD',e)

    def surface_query(self,b=None):
        try:
            
            if not isinstance(b,dict) or b.get('expiry') is None or b.get('strike') is None: raise ValueError('EXPIRY_AND_STRIKE_REQUIRED')
            out=self.ctx.vol_surface.interpolate(float(b['expiry']),float(b['strike']),b.get('option_type','CE')); return {'ok':out['status']=='READY','surface':out,'state':self.ctx.state(),'action':self.ctx._log('VOL_SURFACE_QUERY')}
        except Exception as e:return self.ctx._fail('VOL_SURFACE_QUERY',e)

    def event_analyze(self,b=None):
        try:
            self.ctx.last_events=self.ctx.event_intel.analyze(b.get('events'),horizon_minutes=float(b.get('horizon_minutes',1440))); return {'ok':self.ctx.last_events['status']=='READY','events':self.ctx.last_events,'state':self.ctx.state(),'action':self.ctx._log('EVENT_INTELLIGENCE')}
        except Exception as e:return self.ctx._fail('EVENT_INTELLIGENCE',e)

    def flow_analyze(self,b=None):
        try:
            self.ctx.last_flows=self.ctx.fii_dii.analyze(b.get('rows')); return {'ok':self.ctx.last_flows['status']=='READY','flows':self.ctx.last_flows,'state':self.ctx.state(),'action':self.ctx._log('FII_DII_INTELLIGENCE')}
        except Exception as e:return self.ctx._fail('FII_DII_INTELLIGENCE',e)

    def strategy_health(self,b=None):
        return {'ok':True,'strategy':self.ctx.strategy_brain.health(),'state':self.ctx.state(),'action':self.ctx._log('STRATEGY_HEALTH')}

    def risk_health(self,b=None):
        return {'ok':True,'risk':self.ctx.risk_brain.health(self.ctx.risk_snapshot),'state':self.ctx.state(),'action':self.ctx._log('RISK_HEALTH')}

    def read_limits(self,b=None):
        try:
            self.ctx._require(); raw=self.ctx.adapter.limits(); return {'ok':True,'data':raw,'state':self.ctx.state(),'action':self.ctx._log('READ_BROKER_LIMITS')}
        except Exception as e:return self.ctx._fail('READ_BROKER_LIMITS',e)
