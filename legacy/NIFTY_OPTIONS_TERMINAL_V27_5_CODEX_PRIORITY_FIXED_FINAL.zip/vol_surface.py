from __future__ import annotations
from dataclasses import dataclass
from math import isfinite
from typing import Any
from quant_engine import QuantEngine

@dataclass(frozen=True)
class VolPoint:
    expiry: float
    strike: float
    iv: float
    option_type: str='CE'

class VolatilitySurface:
    """Observed-IV surface only. Interpolation is allowed; extrapolation is blocked."""
    def __init__(self): self.points:list[VolPoint]=[]; self.last={'status':'NO_DATA'}
    def load(self, points:list[dict]|list[VolPoint])->dict[str,Any]:
        out=[]
        for p in points or []:
            try:
                e=float(p.expiry if isinstance(p,VolPoint) else p.get('expiry')); k=float(p.strike if isinstance(p,VolPoint) else p.get('strike')); v=float(p.iv if isinstance(p,VolPoint) else p.get('iv')); typ=(p.option_type if isinstance(p,VolPoint) else p.get('option_type','CE')).upper()
                if isfinite(e) and isfinite(k) and isfinite(v) and e>0 and k>0 and 0<v<=5 and typ in {'CE','PE'}: out.append(VolPoint(e,k,v,typ))
            except (TypeError,ValueError): continue
        self.points=out; self.last={'status':'READY' if out else 'BLOCKED','points':len(out),'source':'observed_iv'}; return self.last
    def interpolate(self,expiry:float,strike:float,option_type='CE')->dict[str,Any]:
        if not self.points:return {'status':'BLOCKED','reason':'NO_SURFACE_DATA'}
        typ=option_type.upper(); pts=[p for p in self.points if p.option_type==typ]
        if not pts:return {'status':'BLOCKED','reason':'NO_TYPE_DATA'}
        e=float(expiry); k=float(strike); es=sorted({p.expiry for p in pts}); ks=sorted({p.strike for p in pts})
        if e<min(es) or e>max(es) or k<min(ks) or k>max(ks): return {'status':'BLOCKED','reason':'EXTRAPOLATION_NOT_ALLOWED'}
        # nearest inverse-distance weighted interpolation, exact observations preserved
        weighted=[]
        for p in pts:
            d=max(1e-12,abs(p.expiry-e)+abs(p.strike-k)/max(k,1)); weighted.append((1/d,p.iv))
        top=sorted(weighted,reverse=True)[:8]; iv=sum(w*v for w,v in top)/sum(w for w,_ in top)
        return {'status':'READY','iv':iv,'expiry':e,'strike':k,'option_type':typ,'method':'bounded_idw','observations_used':len(top)}
    def smile(self,expiry:float,option_type='CE')->dict[str,Any]:
        pts=sorted([p for p in self.points if p.expiry==float(expiry) and p.option_type==option_type.upper()],key=lambda x:x.strike)
        if not pts:return {'status':'BLOCKED','reason':'NO_EXACT_EXPIRY'}
        return {'status':'READY','points':[p.__dict__ for p in pts]}
