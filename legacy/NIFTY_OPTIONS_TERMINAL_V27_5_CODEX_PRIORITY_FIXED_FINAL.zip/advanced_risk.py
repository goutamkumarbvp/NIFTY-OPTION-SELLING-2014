from __future__ import annotations
from dataclasses import dataclass, asdict
from math import isfinite
from typing import Any
@dataclass(frozen=True)
class AdvancedRiskLimits:
    max_strategy_loss:float=50000.0
    max_delta_abs:float=1000.0
    max_vega_abs:float=100000.0
    max_theta_abs:float=100000.0
    min_liquidity_score:float=.55
    max_spread_pct:float=.08
    block_high_vol:bool=False
class AdvancedRiskBrain:
    """Additional fail-closed risk layer for strategy plans; informational Greeks are accepted only when supplied."""
    def __init__(self,limits=None):self.limits=limits or AdvancedRiskLimits();self.last={'decision':'BLOCK','reasons':['NO_RISK_EVIDENCE']}
    def evaluate(self,plan:dict,*,liquidity_score=None,spread_pct=None,delta=None,vega=None,theta=None,estimated_max_loss=None,high_vol=False):
        r=[]
        vals={'liquidity_score':liquidity_score,'spread_pct':spread_pct,'delta':delta,'vega':vega,'theta':theta,'estimated_max_loss':estimated_max_loss}
        for k,v in vals.items():
            if v is not None:
                try:
                    if not isfinite(float(v)):r.append(f'INVALID_{k.upper()}')
                except: r.append(f'INVALID_{k.upper()}')
        if plan.get('status')!='READY':r.append('STRATEGY_NOT_READY')
        if liquidity_score is None:r.append('LIQUIDITY_EVIDENCE_REQUIRED')
        elif float(liquidity_score)<self.limits.min_liquidity_score:r.append('LIQUIDITY_BELOW_FLOOR')
        if spread_pct is not None and float(spread_pct)>self.limits.max_spread_pct:r.append('SPREAD_TOO_WIDE')
        if delta is not None and abs(float(delta))>self.limits.max_delta_abs:r.append('DELTA_LIMIT')
        if vega is not None and abs(float(vega))>self.limits.max_vega_abs:r.append('VEGA_LIMIT')
        if theta is not None and abs(float(theta))>self.limits.max_theta_abs:r.append('THETA_LIMIT')
        if estimated_max_loss is not None and float(estimated_max_loss)>self.limits.max_strategy_loss:r.append('STRATEGY_LOSS_LIMIT')
        if high_vol and self.limits.block_high_vol:r.append('HIGH_VOL_BLOCK')
        self.last={'decision':'BLOCK' if r else 'ALLOW_PAPER','reasons':r,'limits':asdict(self.limits)};return self.last
    def health(self):return {'healthy':True,'fail_closed':True,'limits':asdict(self.limits),'last_decision':self.last}
