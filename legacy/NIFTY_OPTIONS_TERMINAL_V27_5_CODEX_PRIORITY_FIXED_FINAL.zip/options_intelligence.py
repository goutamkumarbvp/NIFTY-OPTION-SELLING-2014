from __future__ import annotations
from dataclasses import dataclass, asdict
from math import isfinite
from statistics import mean, median
from typing import Any

@dataclass(frozen=True)
class OIConfig:
    min_oi: float = 1.0
    max_spread_pct: float = 0.08
    min_liquidity_score: float = 0.55
    iv_floor: float = 0.01
    iv_cap: float = 5.0

class OptionsIntelligence:
    """Deterministic options intelligence. Never invents missing market evidence."""
    def __init__(self, config: OIConfig | None = None):
        self.config = config or OIConfig()
        self.last: dict[str, Any] = {'status':'NO_DATA'}

    @staticmethod
    def num(v):
        try:
            x=float(v); return x if isfinite(x) else None
        except (TypeError, ValueError): return None

    def analyze(self, chain: list[dict], spot: float | None = None) -> dict[str, Any]:
        if not isinstance(chain,list) or not chain: return self._set({'status':'BLOCKED','reason':'NO_CHAIN'})
        rows=[]
        for r in chain:
            if not isinstance(r,dict): continue
            s=self.num(r.get('strike'))
            if s is None: continue
            row={'strike':s,'ce':r.get('ce') or {},'pe':r.get('pe') or {}}
            for side in ('ce','pe'):
                leg=row[side]
                for field in ('oi','volume'):
                    value=self.num(leg.get(field))
                    if value is not None and value < 0:
                        return self._set({'status':'BLOCKED','reason':'INVALID_MARKET_DATA','field':field,'side':side,'strike':s})
            rows.append(row)
        if not rows: return self._set({'status':'BLOCKED','reason':'NO_VALID_STRIKES'})
        if spot is None: return self._set({'status':'BLOCKED','reason':'SPOT_REQUIRED'})
        spot=self.num(spot)
        if spot is None or spot<=0: return self._set({'status':'BLOCKED','reason':'INVALID_SPOT'})
        ce_oi=sum(self.num(r['ce'].get('oi')) or 0 for r in rows)
        pe_oi=sum(self.num(r['pe'].get('oi')) or 0 for r in rows)
        ce_doi=sum(self.num(r['ce'].get('doi')) or 0 for r in rows)
        pe_doi=sum(self.num(r['pe'].get('doi')) or 0 for r in rows)
        pcr=pe_oi/ce_oi if ce_oi>0 else None
        # Exact requested definition: PCR(ΔOI) = ΔPE OI / ΔCE OI.
        # Negative ΔCE OI is valid; zero denominator is undefined.
        pcr_doi=pe_doi/ce_doi if ce_doi != 0 else None
        supports=sorted([{'strike':r['strike'],'oi':self.num(r['pe'].get('oi')) or 0} for r in rows if r['strike']<=spot], key=lambda x:(x['oi'],x['strike']), reverse=True)[:3]
        resistances=sorted([{'strike':r['strike'],'oi':self.num(r['ce'].get('oi')) or 0} for r in rows if r['strike']>=spot], key=lambda x:(x['oi'],-x['strike']), reverse=True)[:3]
        ivs=[]; liquidity=[]; contracts=0; valid=0
        max_oi=max([self.num((r['ce'] if side=='ce' else r['pe']).get('oi')) or 0 for r in rows for side in ('ce','pe')] or [1])
        max_vol=max([self.num((r['ce'] if side=='ce' else r['pe']).get('volume')) or 0 for r in rows for side in ('ce','pe')] or [1])
        for r in rows:
            for side in ('ce','pe'):
                x=r[side]; contracts+=1
                iv=self.num(x.get('iv'))
                if iv is not None and self.config.iv_floor<=iv<=self.config.iv_cap: ivs.append(iv)
                oi=self.num(x.get('oi')) or 0; vol=self.num(x.get('volume')) or 0
                bid=self.num(x.get('bid')); ask=self.num(x.get('ask')); ltp=self.num(x.get('ltp'))
                ref=ltp if ltp and ltp>0 else ((bid+ask)/2 if bid is not None and ask is not None and ask>=bid else None)
                spread=((ask-bid)/ref) if ref and bid is not None and ask is not None and ask>=bid else None
                oi_ratio=min(1.0, oi/max_oi) if max_oi>0 else 0.0
                vol_ratio=min(1.0, vol/max_vol) if max_vol>0 else 0.0
                liq=0.6*oi_ratio+0.4*vol_ratio
                if spread is not None: liq*=max(0.0,1.0-min(spread/self.config.max_spread_pct,1.0))
                liquidity.append(liq)
                if oi>=self.config.min_oi and (ltp is not None or (bid is not None and ask is not None)): valid+=1
        quality=valid/contracts if contracts else 0.0
        liq_score=mean(liquidity) if liquidity else 0.0
        result={'status':'READY' if quality>=0.75 and liq_score>=self.config.min_liquidity_score else 'DEGRADED',
          'spot':spot,'pcr_oi':pcr,'pcr_doi':pcr_doi,'pcr_change_oi':pcr_doi,'call_oi':ce_oi,'put_oi':pe_oi,'call_doi':ce_doi,'put_doi':pe_doi,
          'support_levels':supports,'resistance_levels':resistances,'iv_mean':mean(ivs) if ivs else None,'iv_median':median(ivs) if ivs else None,
          'iv_samples':len(ivs),'liquidity_score':round(liq_score,4),'data_quality':round(quality,4),'contracts':contracts,
          'source':'derived_from_option_chain'}
        return self._set(result)
    def _set(self,x): self.last=x; return x
    def health(self): return {'healthy':self.last.get('status') in {'READY','DEGRADED'},'config':asdict(self.config),'last_status':self.last.get('status')}
