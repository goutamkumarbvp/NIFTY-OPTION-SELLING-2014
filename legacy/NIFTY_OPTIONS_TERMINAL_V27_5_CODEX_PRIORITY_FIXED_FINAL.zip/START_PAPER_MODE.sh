#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON_BIN:-python3}"
if [[ ! -x .venv/bin/python ]]; then
  "$PYTHON_BIN" -m venv .venv
fi
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m compileall -q .
export TRADING_MODE=paper
export LIVE_TRADING=false
export LIVE_ORDERS_ENABLED=false
export PAPER_AUTO_SELF_REPAIR=true
export SELF_REPAIR_AUTO_PROMOTE=false
export BIND_HOST=127.0.0.1
export PORT=8500
echo 'V27.3.2 SAFE PAPER MODE'
echo 'LIVE_TRADING=false | LIVE_ORDERS_ENABLED=false | PAPER_AUTO_SELF_REPAIR=true | SELF_REPAIR_AUTO_PROMOTE=false'
exec .venv/bin/python server.py
