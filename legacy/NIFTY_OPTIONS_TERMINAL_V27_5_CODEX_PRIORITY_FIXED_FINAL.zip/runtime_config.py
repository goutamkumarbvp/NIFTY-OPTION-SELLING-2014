from __future__ import annotations
"""Small dependency-free runtime configuration loader.

Loads a local .env file if present, without overwriting variables already
provided by the process environment. Secrets remain in the environment and
are never returned by this module.
"""
import os
from pathlib import Path


def load_dotenv(path: Path) -> None:
    path = Path(path)
    if not path.exists() or not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key or key.startswith("#"):
            continue
        if value and value[0:1] in {"'", '"'} and value[-1:] == value[0]:
            value = value[1:-1]
        os.environ.setdefault(key, value)


def is_loopback(host: str) -> bool:
    return host in {"127.0.0.1", "localhost", "::1"}


class SafetyInvariantError(RuntimeError): pass

def assert_paper_only(env=None):
    e=dict(os.environ if env is None else env)
    if e.get('TRADING_MODE','paper').strip().lower() != 'paper': raise SafetyInvariantError('TRADING_MODE_MUST_BE_PAPER')
    if e.get('LIVE_TRADING','false').strip().lower() == 'true': raise SafetyInvariantError('LIVE_TRADING_MUST_BE_FALSE')
    if e.get('LIVE_ORDERS_ENABLED','false').strip().lower() == 'true': raise SafetyInvariantError('LIVE_ORDERS_ENABLED_MUST_BE_FALSE')
    return True
