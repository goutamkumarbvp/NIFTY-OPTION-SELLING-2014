from __future__ import annotations
from dataclasses import dataclass, asdict
from math import isfinite
from typing import Any

@dataclass(frozen=True)
class RiskLimits:
    max_daily_loss: float = 100000.0
    max_position_qty: float = 1500.0
    max_order_qty: float = 1500.0
    max_total_exposure: float = 10000000.0
    max_margin_utilization: float = 0.80
    min_available_margin: float = 0.0
    max_orders_per_action: int = 10

@dataclass(frozen=True)
class RiskSnapshot:
    daily_pnl: float
    gross_exposure: float
    margin_used: float
    available_margin: float
    margin_utilization: float
    open_positions: int
    net_qty: float

class RiskBrain:
    """Deterministic, fail-closed pre-trade risk gate. No broker order placement."""
    def __init__(self, limits: RiskLimits | None = None):
        self.limits = limits or RiskLimits()
        self.last_decision: dict[str, Any] = {'decision':'BLOCK','reasons':['NO_RISK_EVIDENCE']}

    @staticmethod
    def _num(v, default=None):
        try:
            x=float(v)
            return x if isfinite(x) else default
        except (TypeError, ValueError): return default

    def snapshot(self, positions: Any, limits_payload: Any, daily_pnl: float = 0.0) -> RiskSnapshot:
        rows = positions.get('data', positions) if isinstance(positions, dict) else positions
        if not isinstance(rows, list): rows=[]
        gross=0.0; net=0.0; count=0
        invalid_position = False
        for r in rows:
            if not isinstance(r,dict):
                invalid_position = True
                continue
            q=self._num(r.get('quantity',r.get('netQuantity',r.get('netQty'))))
            p=self._num(r.get('averagePrice',r.get('avgPrice',r.get('ltp'))))
            if q is None or p is None:
                invalid_position = True
                continue
            gross += abs(q*p); net += q
            if abs(q)>0: count += 1
        if invalid_position:
            return RiskSnapshot(float('nan'),float('nan'),float('nan'),float('nan'),float('nan'),count,net)
        lp=limits_payload.get('data',limits_payload) if isinstance(limits_payload,dict) else limits_payload
        if not isinstance(lp,dict): lp={}
        available=self._num(lp.get('availableMargin',lp.get('available_margin',lp.get('netAvailableMargin'))))
        used=self._num(lp.get('marginUsed',lp.get('margin_used',lp.get('usedMargin'))))
        dp=self._num(daily_pnl)
        if available is None or used is None or dp is None or available<=0 or used<0:
            return RiskSnapshot(float('nan'),float('nan'),float('nan'),float('nan'),float('nan'),count,net)
        total=available+used
        util=(used/total) if total>0 else 0.0
        return RiskSnapshot(dp,gross,used,available,util,count,net)

    def evaluate(self, snapshot: RiskSnapshot, order: dict[str,Any] | None = None) -> dict[str,Any]:
        order=order or {}
        reasons=[]; warnings=[]
        qty=abs(self._num(order.get('quantity',0)))
        price=self._num(order.get('price',order.get('ltp',0)))
        side=str(order.get('side','')).upper()
        if not all(isfinite(x) for x in (snapshot.daily_pnl,snapshot.gross_exposure,snapshot.margin_used,snapshot.available_margin,snapshot.margin_utilization,snapshot.net_qty)): reasons.append('INVALID_RISK_SNAPSHOT')
        if snapshot.daily_pnl <= -self.limits.max_daily_loss: reasons.append('DAILY_LOSS_LIMIT_REACHED')
        if qty > self.limits.max_order_qty: reasons.append('ORDER_QTY_LIMIT_EXCEEDED')
        if qty and not side in {'BUY','SELL'}: reasons.append('INVALID_ORDER_SIDE')
        if qty and price <= 0: reasons.append('POSITIVE_PRICE_REQUIRED_FOR_RISK_ESTIMATE')
        projected_net=abs(snapshot.net_qty + (qty if side=='BUY' else -qty))
        if projected_net > self.limits.max_position_qty: reasons.append('PROJECTED_POSITION_QTY_LIMIT_EXCEEDED')
        incremental=qty*max(price,0)
        if snapshot.gross_exposure + incremental > self.limits.max_total_exposure: reasons.append('PROJECTED_EXPOSURE_LIMIT_EXCEEDED')
        if snapshot.available_margin < self.limits.min_available_margin: reasons.append('AVAILABLE_MARGIN_BELOW_FLOOR')
        projected_margin_used=snapshot.margin_used + incremental
        total_margin=snapshot.available_margin + snapshot.margin_used
        projected_margin_util=(projected_margin_used/total_margin) if total_margin > 0 else float('inf')
        if snapshot.margin_utilization > self.limits.max_margin_utilization or projected_margin_util > self.limits.max_margin_utilization:
            reasons.append('MARGIN_UTILIZATION_LIMIT_EXCEEDED')
        decision='BLOCK' if reasons else 'ALLOW_PAPER'
        self.last_decision={'decision':decision,'reasons':reasons,'warnings':warnings,'projected_net_qty':projected_net,'projected_exposure':snapshot.gross_exposure+incremental,'projected_margin_utilization':projected_margin_util}
        return self.last_decision

    def health(self, snapshot: RiskSnapshot | None = None) -> dict[str,Any]:
        healthy=False
        if snapshot is not None:
            try:
                values=(snapshot.daily_pnl,snapshot.gross_exposure,snapshot.margin_used,snapshot.available_margin,snapshot.margin_utilization,snapshot.net_qty)
                healthy=all(isfinite(float(v)) for v in values) and snapshot.available_margin > 0 and snapshot.margin_used >= 0
            except (TypeError, ValueError, AttributeError):
                healthy=False
        return {'healthy':healthy, 'fail_closed': True, 'limits': asdict(self.limits), 'last_decision': self.last_decision}
