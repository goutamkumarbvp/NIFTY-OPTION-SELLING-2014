#!/usr/bin/env python3
from __future__ import annotations
import json, os, signal, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from runtime_config import load_dotenv, is_loopback, assert_paper_only

ROOT=Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")

from terminal_backend import TerminalBackend, Audit, ROOT

DASHBOARD=ROOT/'dashboard'/'index.html'
MAX_BODY_BYTES=int(os.getenv('MAX_BODY_BYTES','1048576'))
BIND_HOST=os.getenv('BIND_HOST','127.0.0.1')
API_AUTH_TOKEN=os.getenv('API_AUTH_TOKEN','').strip()

# Composition root: exactly one application backend instance.
APP=TerminalBackend()

ROUTES={
'/api/refresh':'refresh','/api/broker/authenticate':'auth','/api/market/expiries':'expiries','/api/market/option-chain':'chain','/api/market/quotes':'quote','/api/account/positions':'positions','/api/account/holdings':'holdings','/api/account/limits':'limits','/api/risk/evaluate':'risk','/api/intelligence/options':'options_intel','/api/intelligence/regime':'regime','/api/risk/advanced':'advanced_risk','/api/risk/health':'risk_health','/api/strategy/analyze':'strategy','/api/strategy/health':'strategy_health','/api/quant/greeks':'greeks','/api/quant/implied-vol':'iv','/api/volatility/surface/load':'surface_load','/api/volatility/surface/query':'surface_query','/api/intelligence/events':'events','/api/intelligence/fii-dii':'flows','/api/research/backtest':'backtest','/api/research/data-ingest':'research_ingest','/api/research/options-backtest':'option_backtest','/api/research/walk-forward':'walk_forward','/api/research/stress':'stress','/api/research/strategy-backtest':'strategy_backtest','/api/research/optimize':'optimize','/api/research/robustness':'robustness','/api/research/mc-validation':'mc_validation','/api/research/options-chain-ingest':'option_chain_ingest','/api/research/options-chain-replay':'option_chain_replay','/api/research/research-margin':'research_margin','/api/research/v10/import-csv':'v10_import_csv','/api/research/v10/ingest':'v10_ingest','/api/research/v10/read':'v10_read','/api/research/v10/export-parquet':'v10_parquet','/api/research/v10/calendar-check':'v10_calendar','/api/research/v10/contract-map':'v10_contract','/api/research/v11/dataset-register':'v11_register','/api/research/v11/dataset-versions':'v11_versions','/api/research/v11/expiry-series':'v11_series','/api/research/v11/query-snapshots':'v11_query_snapshots','/api/research/v11/query-contracts':'v11_query_contracts','/api/research/v11/data-quality':'v11_quality','/api/research/v11/replay':'v11_replay','/api/research/v11/replay-soak':'v11_soak','/api/research/v12/normalize':'v12_normalize','/api/research/v12/import':'v12_import','/api/research/v12/lineage':'v12_lineage','/api/research/v12/coverage':'v12_coverage','/api/research/v12/completeness':'v12_completeness','/api/research/v12/partition-manifest':'v12_manifest','/api/research/v13/normalize':'v13_normalize','/api/research/v13/integrity':'v13_integrity','/api/research/v13/calendar-check':'v13_calendar','/api/research/v13/contract-chain':'v13_chain','/api/research/v13/nearest-expiry':'v13_nearest','/api/research/v13/certify':'v13_certify','/api/research/v13/replay':'v13_replay','/api/kotak/v14/config':'v14_config','/api/kotak/v14/status':'v14_status','/api/kotak/v14/read':'v14_read','/api/kotak/v15/discover':'v15_discover','/api/kotak/v15/option-chain-auto':'v15_chain','/api/kotak/v15/feed-start':'v15_feed','/api/kotak/v15/feed-soak-status':'v15_soak_status','/api/ai/super-analyze':'super_ai','/api/ai/v24/reason':'v24_reason','/api/ai/v25/memory':'v25_memory','/api/ai/v26/research':'v26_research','/api/ai/v27/repair':'v27_repair','/api/ai/v27/repair-status':'v27_repair_status','/api/ai/pass17/run':'pass17_run','/api/ai/pass17/memory':'pass17_memory','/api/ai/pass17/tools':'pass17_tools','/api/self-repair/status':'self_repair_status','/api/self-repair/diagnose':'self_repair_diagnose','/api/self-repair/run':'self_repair_run','/api/alerts/recent':'alerts_recent','/api/alerts/config':'alerts_config','/api/alerts/test':'alerts_test','/api/alerts/emit':'alerts_emit','/api/feed/soak':'soak','/api/feed/start':'feed_start','/api/feed/stop':'feed_stop','/api/feed/reconnect':'feed_reconnect','/api/engine/start':'start','/api/engine/stop':'stop','/api/engine/pause':'pause','/api/engine/resume':'resume','/api/panic':'panic','/api/ai/analyze':'ai','/api/trade-plan':'plan','/api/report':'report','/api/navigation':'nav','/api/paper/order':'paper_order','/api/paper/cancel':'paper_cancel','/api/paper/mark':'paper_mark','/api/paper/flatten':'paper_flatten'}

def json_safe(value):
    if isinstance(value, float) and (value != value or value in (float('inf'), float('-inf'))): return None
    if isinstance(value, dict): return {k: json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [json_safe(v) for v in value]
    return value

class DaemonThreadingHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.0'
    def _send(self,status,obj):
        safe=json_safe(obj)
        raw=json.dumps(safe,ensure_ascii=False,default=str,allow_nan=False).encode(); self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Cache-Control','no-store'); self.send_header('Connection','close'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); self.close_connection=True
    def _authorized(self):
        if is_loopback(BIND_HOST):
            return True
        supplied=self.headers.get('Authorization','')
        if supplied.startswith('Bearer '):
            supplied=supplied[7:]
        supplied=supplied.strip() or self.headers.get('X-API-Key','').strip()
        return bool(API_AUTH_TOKEN) and supplied == API_AUTH_TOKEN

    def _unauthorized(self):
        return self._send(401, {'ok':False,'error':'AUTH_REQUIRED'})

    def do_GET(self):
        p=urlparse(self.path).path
        if p != '/' and not self._authorized(): return self._unauthorized()
        if p=='/':
            raw=DASHBOARD.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Connection','close'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); self.close_connection=True; return
        if p=='/api/state': return self._send(200,{'ok':True,'state':APP.state()})
        if p=='/api/health':
            st=APP.state()
            version = 'v27.5'
            try:
                version_data = json.loads((ROOT/'VERSION.json').read_text(encoding='utf-8'))
                version = str(version_data.get('release') or version).strip() or version
                version = version.removeprefix('v').removeprefix('V')
            except Exception:
                pass
            return self._send(200,{'ok':True,'version':'v'+version.removeprefix('v').lower(),'api_schema_version':'v12.0','release':version,'release_version':version,'backend_wired':True,
                'real_kotak_path':True,'live_market_data_path':True,'option_chain_auto_feed':True,'read_only_reconciliation':True,'feed_soak_endpoint':True,
                'live_orders_enabled':False,'pass_6':'research_backtesting_full_greeks_vol_surface_event_intelligence_fii_dii','pass_7':'historical_data_validation_option_backtest_walk_forward_stress_monte_carlo','pass_8':'multi_leg_expiry_margin_costs_optimization_walk_forward_robustness_monte_carlo','pass_9':'historical_option_chain_store_replay_expiry_aware_margin_and_data_integrity','pass_10':'nifty_historical_optionchain_sqlite_csv_parquet_contract_mapping_calendar_replay_foundation','pass_11':'high_speed_replay_expiry_series_query_layer_dataset_versioning_quality_soak','pass_12':'historical_normalization_provenance_partitioned_storage_coverage_completeness_replay_source','pass_13':'canonical_nifty_schema_integrity_session_calendar_contract_chain_certification_fast_replay','pass_14':'kotak_read_only_auth_security_live_feed_hardening_paper_only_interlock','pass_15':'credentialed_readonly_nifty_token_discovery_auto_chain_sfeed_subscription_tick_soak_quality','pass_16':'extreme_super_agent_multi_agent_evidence_critic_policy_safe_paper_only','pass_17':'agent_memory_tool_registry_hypothesis_loop_adversarial_critic_self_evaluation_safe_paper_only','pass_17_1':'pcr_change_oi_exact_delta_pe_over_delta_ce_dual_pcr_history_chart','pass_17_2':'live_alerts_stop_loss_new_trade_black_swan_big_move_feed_stale_risk_undesirable_dashboard_telegram_optional','pass_17_3':'telegram_sms_whatsapp_multichannel_alert_delivery','pass_17_4':'bounded_runtime_self_healing_feed_supervisor_with_circuit_breaker_and_safe_hold','pass_18':'verified_code_self_repair_ai_diagnostics_test_gate_sandbox_checkpoint_and_rollback','pass_19':'modular_transport_application_backend_dependency_boundary_hardening','pass_20':'application_service_decomposition_domain_dependency_isolation_architecture_contracts','pass_21':'protocol_dependency_inversion_composition_root_event_bus_service_isolation','pass_23':'bounded_super_ai_multi_agent_evidence_critic_policy','pass_24':'provider_neutral_llm_reasoning_gateway_schema_first_fail_closed','pass_25':'durable_agent_memory_long_term_learning_hypothesis_outcomes','pass_26':'bounded_autonomous_research_hypothesis_testing_robustness_ranking','pass_27':'verified_autonomous_repair_sandbox_test_gate_rollback_policy','architecture':'modular_transport_application_service_domain_boundaries_dependency_inversion_event_bus','self_healing_enabled':True,'self_healing':'runtime_feed_recovery_plus_verified_code_self_repair_sandbox_only','code_self_repair':{'enabled':True,'auto_promote':False,'mandatory_tests':True,'automatic_rollback':True,'sandbox_verification':True},
                'runtime':{'authenticated':st['broker']['authenticated'],'feed_connected':st['feed']['connected'],'feed_fresh':st['feed']['fresh'],'option_chain_live':bool(st['option_chain']),'risk_state':st['risk']['risk_state'],'mode':st['mode'],'paused':st['paused'],'paper_only':True,'live_orders_enabled':False},
                'capabilities':{'kotak_read_only':True,'live_market_data':True,'option_chain_auto_feed':True,'self_healing':True,'verified_code_self_repair':True},'health_semantics':{'runtime': 'authoritative_current_state','capabilities': 'static_feature_availability'}})
        return self._send(404,{'ok':False,'error':'NOT_FOUND'})
    def _csrf_ok(self):
        # Same-origin enforcement protects loopback POST endpoints from cross-origin
        # browser forms/simple requests. Non-browser API clients may omit Origin.
        origin=self.headers.get('Origin')
        if origin:
            host=self.headers.get('Host','')
            allowed={f'http://{host}', f'https://{host}'}
            return origin in allowed
        sec_site=self.headers.get('Sec-Fetch-Site','')
        return sec_site in ('','same-origin','same-site','none')

    def do_POST(self):
        p=urlparse(self.path).path
        if not self._authorized(): return self._unauthorized()
        if not self._csrf_ok(): return self._send(403, {'ok':False,'error':'CSRF_ORIGIN_REJECTED'})
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n < 0 or n > MAX_BODY_BYTES: return self._send(413, {'ok':False,'error':'REQUEST_TOO_LARGE'})
            body=json.loads(self.rfile.read(n) or b'{}', parse_constant=lambda x: (_ for _ in ()).throw(ValueError('NON_FINITE_JSON_NUMBER')))
            if not isinstance(body,dict): return self._send(422,{'ok':False,'error':'JSON_OBJECT_REQUIRED'})
        except Exception:
            return self._send(400,{'ok':False,'error':'INVALID_JSON'})
        if p not in ROUTES: return self._send(404,{'ok':False,'error':'NOT_FOUND'})
        try:
            out=APP.command(ROUTES[p], body)
        except Exception:
            return self._send(500,{'ok':False,'error':'INTERNAL_ERROR'})
        return self._send(200 if out.get('ok') else 409,out)
    def log_message(self,*a): pass

def main():
    assert_paper_only()
    port=int(os.getenv('PORT','8500'))
    if not (0 < port < 65536): raise SystemExit('PORT_OUT_OF_RANGE')
    if not is_loopback(BIND_HOST) and not API_AUTH_TOKEN:
        raise SystemExit('NON_LOCAL_BIND_REQUIRES_API_AUTH_TOKEN')
    if not DASHBOARD.exists(): raise SystemExit(f'DASHBOARD_NOT_FOUND: {DASHBOARD}')
    APP.start_workers()
    httpd=DaemonThreadingHTTPServer((BIND_HOST,port),Handler)
    stop=threading.Event()
    def shutdown(*_):
        if not stop.is_set():
            stop.set(); threading.Thread(target=httpd.shutdown, daemon=True).start()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try: signal.signal(sig, shutdown)
        except (ValueError, OSError): pass
    print(f'NIFTY OPTIONS TERMINAL v27.5: http://{BIND_HOST}:{port}')
    try: httpd.serve_forever(poll_interval=0.5)
    finally:
        httpd.server_close()
        try: APP.shutdown()
        except Exception: pass



if __name__=='__main__': main()
