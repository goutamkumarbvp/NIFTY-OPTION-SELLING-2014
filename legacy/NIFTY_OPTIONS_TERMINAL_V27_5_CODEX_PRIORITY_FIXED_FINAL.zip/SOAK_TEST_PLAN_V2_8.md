# V2.8 Credentialed Kotak Soak Test

V2.8 is observation-only. It does not place, modify or cancel orders.

1. Configure `KOTAK_CONSUMER_KEY`, `KOTAK_MOBILE_NUMBER`, `KOTAK_UCC`.
2. Start server and authenticate using TOTP + MPIN.
3. Resolve NIFTY underlying token using the broker's current instrument/search data; never hard-code a dated scrip-master URL.
4. Fetch expiries and select the desired expiry.
5. Fetch option chain. V2.8 extracts CE/PE tokens automatically.
6. Start SFeed with those tokens; subscription is capped at 3000.
7. Verify fresh ticks, local sequence growth, market status, reconnect count and option-chain freshness.
8. Run for at least 30 minutes in market hours; record disconnects, stale intervals and gaps.
9. Any missing/stale feed must remain DEGRADED/BLOCKED. Never label it healthy merely because the socket is connected.

The official SDK documents `expiries()`, `option_chain()`, typed SFeed messages and a 3000-token subscription limit. V2.8 follows those constraints.
