import json, threading
from urllib.request import urlopen, Request
from http.server import ThreadingHTTPServer
from server import APP, Handler
from market_intelligence import normalize_option_chain, build_chain, chain_metrics

class FakeAdapter:
    def authenticate(self,totp,mpin): return {'login_status':'OK','validate_status':'OK'}
    def expiries(self,exchange_segment='nse_fo',instrument_token=None): return {'stat':'Ok','data':['2026-09-17']}
    def option_chain(self,exchange_segment='nse_fo',instrument_token=None,expiry=None):
        return {'data':[
            {'strike_price':25000,'option_type':'CE','instrument_token':'1','last_traded_price':100,'best_bid_price':99,'best_ask_price':101,'open_interest':1000,'change_in_oi':100,'implied_volatility':12.5},
            {'strike_price':25000,'option_type':'PE','instrument_token':'2','last_traded_price':90,'best_bid_price':89,'best_ask_price':91,'open_interest':1200,'change_in_oi':200,'implied_volatility':13.1},
        ]}
    def quotes(self,tokens): return {'stat':'Ok','data':tokens}

def test_chain_normalization_and_metrics():
    c=build_chain(FakeAdapter().option_chain())
    assert len(c)==1 and c[0]['ce']['oi']==1000 and c[0]['pe']['oi']==1200
    m=chain_metrics(c); assert m['pcr_oi']==1.2 and m['pcr_doi']==2.0

def test_no_synthetic_state():
    s=APP.state(); assert s['api_schema_version']=='v12.0'; assert s['market']['nifty'] is None or isinstance(s['market']['nifty'],float); assert s['risk']['live_execution']=='DISABLED'

def test_live_adapter_path_with_fake_client():
    APP.adapter=FakeAdapter(); APP.authenticated=True
    out=APP.command('chain',{'instrument_token':'NIFTY','expiry':'2026-09-17'}); assert out['ok'] and out['metrics']['pcr_oi']==1.2
    APP.adapter=None; APP.authenticated=False

def test_http_routes():
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); port=srv.server_address[1]; t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
    try:
        h=json.loads(urlopen(f'http://127.0.0.1:{port}/api/health').read()); assert h['api_schema_version']=='v12.0' and h['live_market_data_path']
        req=Request(f'http://127.0.0.1:{port}/api/market/option-chain',data=b'{}',headers={'Content-Type':'application/json'},method='POST')
        from urllib.error import HTTPError
        try: urlopen(req); assert False, 'expected 409'
        except HTTPError as e: assert e.code==409
    finally:srv.shutdown();srv.server_close()
