from __future__ import annotations
"""Typed application boundary contracts for V22.

The trading/domain services communicate through small, provider-neutral DTOs and
commands.  HTTP and broker-specific representations stay outside these contracts.
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

class CommandName(str, Enum):
    REFRESH='refresh'; AUTH='auth'; CHAIN='chain'; QUOTE='quote'; POSITIONS='positions'; HOLDINGS='holdings'
    LIMITS='limits'; RISK='risk'; OPTIONS_INTEL='options_intel'; REGIME='regime'; ADVANCED_RISK='advanced_risk'
    RISK_HEALTH='risk_health'; STRATEGY='strategy'; STRATEGY_HEALTH='strategy_health'; GREEKS='greeks'; IV='iv'
    SURFACE_LOAD='surface_load'; SURFACE_QUERY='surface_query'; EVENTS='events'; FLOWS='flows'; BACKTEST='backtest'
    RESEARCH_INGEST='research_ingest'; OPTION_BACKTEST='option_backtest'; WALK_FORWARD='walk_forward'; STRESS='stress'
    STRATEGY_BACKTEST='strategy_backtest'; OPTIMIZE='optimize'; ROBUSTNESS='robustness'; MC_VALIDATION='mc_validation'
    OPTION_CHAIN_INGEST='option_chain_ingest'; OPTION_CHAIN_REPLAY='option_chain_replay'; RESEARCH_MARGIN='research_margin'
    V10_IMPORT='v10_import_csv'; V10_INGEST='v10_ingest'; V10_READ='v10_read'; V10_PARQUET='v10_parquet'
    V10_CALENDAR='v10_calendar'; V10_CONTRACT='v10_contract'; V11_REGISTER='v11_register'; V11_VERSIONS='v11_versions'
    V11_SERIES='v11_series'; V11_QUERY_SNAPSHOTS='v11_query_snapshots'; V11_QUERY_CONTRACTS='v11_query_contracts'
    V11_QUALITY='v11_quality'; V11_REPLAY='v11_replay'; V11_SOAK='v11_soak'; V12_NORMALIZE='v12_normalize'; V12_IMPORT='v12_import'
    V12_LINEAGE='v12_lineage'; V12_COVERAGE='v12_coverage'; V12_COMPLETENESS='v12_completeness'; V12_MANIFEST='v12_manifest'
    V13_NORMALIZE='v13_normalize'; V13_INTEGRITY='v13_integrity'; V13_CALENDAR='v13_calendar'; V13_CHAIN='v13_chain'; V13_NEAREST='v13_nearest'
    V13_CERTIFY='v13_certify'; V13_REPLAY='v13_replay'; V14_CONFIG='v14_config'; V14_STATUS='v14_status'; V14_READ='v14_read'
    V15_DISCOVER='v15_discover'; V15_CHAIN='v15_chain'; V15_FEED='v15_feed'; V15_SOAK_STATUS='v15_soak_status'
    SUPER_AI='super_ai'; PASS17_RUN='pass17_run'; PASS17_MEMORY='pass17_memory'; PASS17_TOOLS='pass17_tools'
    SELF_REPAIR_STATUS='self_repair_status'; SELF_REPAIR_DIAGNOSE='self_repair_diagnose'; SELF_REPAIR_RUN='self_repair_run'
    ALERTS_RECENT='alerts_recent'; ALERTS_CONFIG='alerts_config'; ALERTS_TEST='alerts_test'; ALERTS_EMIT='alerts_emit'
    SOAK='soak'; FEED_START='feed_start'; FEED_STOP='feed_stop'; FEED_RECONNECT='feed_reconnect'; ENGINE_START='start'
    PAPER_ORDER='paper_order'; PAPER_CANCEL='paper_cancel'; PAPER_MARK='paper_mark'; PAPER_FLATTEN='paper_flatten'; ENGINE_STOP='stop'; ENGINE_PAUSE='pause'; ENGINE_RESUME='resume'; PANIC='panic'; AI='ai'; PLAN='plan'; REPORT='report'; NAV='nav'

@dataclass(frozen=True)
class ApplicationCommand:
    name: CommandName
    payload: Mapping[str, Any] = field(default_factory=dict)
    trace_id: str | None = None


@dataclass(frozen=True)
class CommandResult:
    ok: bool
    data: Mapping[str, Any] = field(default_factory=dict)
    error: str | None = None
    trace_id: str | None = None

class EventTopic(str, Enum):
    AUDIT_ACTION='audit.action'; MARKET_UPDATED='market.updated'; CHAIN_UPDATED='chain.updated'
    RISK_EVALUATED='risk.evaluated'; STRATEGY_ANALYZED='strategy.analyzed'; ALERT_RAISED='alert.raised'
    REPAIR_COMPLETED='repair.completed'; SELF_HEALING='self_healing.recovery'

@dataclass(frozen=True)
class DomainEvent:
    topic: EventTopic | str
    payload: Mapping[str, Any] = field(default_factory=dict)
    sequence: int | None = None
    trace_id: str | None = None

    def __getitem__(self, key: str) -> Any:
        if key in self.payload: return self.payload[key]
        if key == "topic": return self.topic.value if isinstance(self.topic, EventTopic) else self.topic
        if key == "sequence": return self.sequence
        if key == "trace_id": return self.trace_id
        raise KeyError(key)

    def get(self, key: str, default: Any = None) -> Any:
        try: return self[key]
        except KeyError: return default
