import tempfile, csv, os
from datetime import date
from market_data_v10 import *

def snap(ts='2026-09-15T09:16:00+05:30'):
 return {'timestamp':ts,'spot':25000,'expiry':'2026-09-24','contracts':[
 {'symbol':'NIFTY24SEP25000CE','instrument_token':'101','exchange_segment':'nse_fo','underlying':'NIFTY','expiry':'2026-09-24','strike':25000,'option_type':'CE','lot_size':75,'tick_size':0.05,'bid':100,'ask':102,'oi':1000,'volume':100},
 {'symbol':'NIFTY24SEP25000PE','instrument_token':'102','exchange_segment':'nse_fo','underlying':'NIFTY','expiry':'2026-09-24','strike':25000,'option_type':'PE','lot_size':75,'tick_size':0.05,'bid':90,'ask':92,'oi':1200,'volume':120}]}

def test_timestamp_normalization_naive_is_ist():
 assert normalize_timestamp('2026-09-15T09:15:00').utcoffset().total_seconds()==19800

def test_calendar_weekend_block(): assert not NSECalendar().is_trading_day('2026-09-19')
def test_calendar_session(): assert NSECalendar().is_market_timestamp('2026-09-15T15:30:00+05:30')
def test_calendar_after_close_block(): assert not NSECalendar().is_market_timestamp('2026-09-15T15:30:01+05:30')
def test_mapper_requires_identity(): assert ContractMapper.map({'symbol':'x'}) is None
def test_mapper_valid(): assert ContractMapper.validate_nifty(ContractMapper.map(snap()['contracts'][0]))
def test_mapper_rejects_non_nifty():
 r=dict(snap()['contracts'][0]); r['underlying']='BANKNIFTY'; assert not ContractMapper.validate_nifty(ContractMapper.map(r))
def test_sqlite_roundtrip():
 with tempfile.TemporaryDirectory() as d:
  r=OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('sep', [snap(),dict(snap('2026-09-15T09:17:00+05:30'))]); assert r['status']=='READY'
  q=OptionChainSQLiteStore(os.path.join(d,'x.db')).read('sep'); assert q['snapshots']==2 and q['contracts']==4 and len(q['sha256'])==64

def test_sqlite_immutable():
 with tempfile.TemporaryDirectory() as d:
  st=OptionChainSQLiteStore(os.path.join(d,'x.db')); assert st.ingest('sep',[snap()])['status']=='READY'; assert st.ingest('sep',[snap()])['reason']=='DATASET_EXISTS'
def test_sqlite_duplicate_time_blocks():
 with tempfile.TemporaryDirectory() as d:
  x=snap(); assert OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('x',[x,dict(x)])['reason']=='NON_MONOTONIC_TIMESTAMP'
def test_sqlite_expiry_mismatch_blocks():
 x=snap(); x['contracts'][0]['expiry']='2026-10-01';
 with tempfile.TemporaryDirectory() as d: assert OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('x',[x])['reason']=='EXPIRY_MISMATCH'
def test_sqlite_crossed_quote_blocks():
 x=snap(); x['contracts'][0]['ask']=99
 with tempfile.TemporaryDirectory() as d: assert OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('x',[x])['reason']=='INVALID_QUOTE'
def test_sqlite_duplicate_contract_blocks():
 x=snap(); x['contracts'].append(dict(x['contracts'][0]))
 with tempfile.TemporaryDirectory() as d: assert OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('x',[x])['reason']=='DUPLICATE_CONTRACT'
def test_csv_importer():
 with tempfile.NamedTemporaryFile('w',suffix='.csv',delete=False,newline='') as f:
  w=csv.DictWriter(f,fieldnames=['timestamp','spot','expiry','symbol','instrument_token','exchange_segment','underlying','strike','option_type','lot_size','tick_size','bid','ask','oi','volume']); w.writeheader(); w.writerow({**snap()['contracts'][0],'timestamp':snap()['timestamp'],'spot':25000}); p=f.name
 try: assert len(CSVOptionChainImporter.snapshots(p))==1
 finally: os.unlink(p)
def test_parquet_graceful():
 with tempfile.TemporaryDirectory() as d:
  r=ParquetExporter.export([snap()],os.path.join(d,'x.parquet')); assert r['status'] in ('READY','BLOCKED')
def test_invalid_expiry_blocks():
 x=snap(); x['expiry']='2026-09-20';
 with tempfile.TemporaryDirectory() as d: assert OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('x',[x])['reason']=='INVALID_EXPIRY_OR_SPOT'
def test_invalid_lot_blocks():
 x=snap(); x['contracts'][0]['lot_size']=0
 with tempfile.TemporaryDirectory() as d: assert OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('x',[x])['reason']=='INVALID_NIFTY_CONTRACT'
def test_negative_oi_blocks():
 x=snap(); x['contracts'][0]['oi']=-1
 with tempfile.TemporaryDirectory() as d: assert OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('x',[x])['reason']=='INVALID_QUOTE'
def test_unknown_segment_blocks():
 x=snap(); x['contracts'][0]['exchange_segment']='nse_cm'
 with tempfile.TemporaryDirectory() as d: assert OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('x',[x])['reason']=='INVALID_NIFTY_CONTRACT'
def test_spot_positive():
 x=snap(); x['spot']=0
 with tempfile.TemporaryDirectory() as d: assert OptionChainSQLiteStore(os.path.join(d,'x.db')).ingest('x',[x])['reason']=='INVALID_EXPIRY_OR_SPOT'
