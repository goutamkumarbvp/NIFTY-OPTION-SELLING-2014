from pathlib import Path


def test_dashboard_has_no_innerhtml_assignment():
    html=Path('dashboard/index.html').read_text(encoding='utf-8')
    assert 'innerHTML' not in html


def test_runtime_auto_repair_worker_never_requests_promotion():
    src=Path('terminal_backend.py').read_text(encoding='utf-8')
    assert 'propose_and_verify(d,target,promote=False)' in src
    assert 'propose_and_verify(d,target,promote=True)' not in src


def test_health_explicitly_separates_runtime_and_capability_semantics():
    src=Path('server.py').read_text(encoding='utf-8')
    assert "'health_semantics'" in src
    assert "'runtime': 'authoritative_current_state'" in src
    assert "'capabilities': 'static_feature_availability'" in src


def test_database_transaction_is_atomic_across_process_kill(tmp_path):
    import os, signal, subprocess, sys, textwrap
    db=tmp_path/'paper.sqlite3'
    child=tmp_path/'kill_tx.py'
    child.write_text(textwrap.dedent(f'''
        import os, signal, sqlite3
        from pathlib import Path
        import paper_execution
        orig=sqlite3.connect
        def connect(*a,**k):
            c=orig(*a,**k)
            def trace(sql):
                if sql.startswith("INSERT INTO orders"):
                    os.kill(os.getpid(), signal.SIGKILL)
            c.set_trace_callback(trace)
            return c
        paper_execution.sqlite3.connect=connect
        paper_execution.PaperExecutionLedger(Path(r"{db}")).submit("NIFTY","BUY",75,"MARKET",fill_price=100)
    '''), encoding='utf-8')
    r=subprocess.run([sys.executable,str(child)], cwd=Path.cwd(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    assert r.returncode != 0
    from paper_execution import PaperExecutionLedger
    ledger=PaperExecutionLedger(db)
    assert ledger.orders()==[]
    assert ledger.positions()==[]


def test_database_lock_recovers_without_duplicate_fill(tmp_path):
    import sqlite3, threading, time
    from paper_execution import PaperExecutionLedger
    db=tmp_path/'paper.sqlite3'; ledger=PaperExecutionLedger(db)
    c=sqlite3.connect(db); c.execute('BEGIN IMMEDIATE')
    result={}
    def worker():
        try: result['order']=ledger.submit('NIFTY','BUY',75,'MARKET',fill_price=100)
        except Exception as e: result['error']=e
    t=threading.Thread(target=worker); t.start(); time.sleep(0.25); c.rollback(); c.close(); t.join(5)
    assert 'order' in result and not result.get('error')
    assert ledger.positions()[0]['net_quantity']==75
    assert len(ledger.orders())==1
