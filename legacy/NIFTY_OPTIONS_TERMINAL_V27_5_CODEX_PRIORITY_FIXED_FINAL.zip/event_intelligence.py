from __future__ import annotations
from datetime import datetime, timezone
from typing import Any

class EventIntelligence:
    """Calendar-aware event gate. Events must be supplied; nothing is fabricated."""
    def __init__(self,blackout_minutes=60): self.blackout_minutes=int(blackout_minutes); self.last={'status':'NO_DATA'}
    def analyze(self,events:list[dict]|None,now=None,horizon_minutes=1440)->dict[str,Any]:
        if events is None:return self._set({'status':'BLOCKED','reason':'EVENT_DATA_REQUIRED','events':[]})
        now=now or datetime.now(timezone.utc); active=[]; valid=0
        for e in events:
            if not isinstance(e,dict):continue
            try:
                ts=e.get('timestamp') or e.get('time') or e.get('datetime'); dt=datetime.fromisoformat(str(ts).replace('Z','+00:00')) if ts else None
                if dt is None:continue
                if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
                delta=(dt-now).total_seconds()/60; valid+=1
                if abs(delta)<=self.blackout_minutes:active.append({'name':e.get('name','EVENT'),'minutes_from_now':round(delta,2),'severity':str(e.get('severity','MEDIUM')).upper()})
                elif 0<=delta<=horizon_minutes: active.append({'name':e.get('name','EVENT'),'minutes_from_now':round(delta,2),'severity':str(e.get('severity','MEDIUM')).upper(),'upcoming':True})
            except Exception:continue
        blocking=[e for e in active if not e.get('upcoming') and e.get('severity') in {'HIGH','CRITICAL','MEDIUM'}]
        return self._set({'status':'BLOCKED' if blocking else 'READY','blocking':blocking,'upcoming':active,'valid_events':valid,'source':'supplied_event_calendar'})
    def _set(self,x):self.last=x;return x
    def health(self):return {'healthy':self.last.get('status') in {'READY','BLOCKED'},'blackout_minutes':self.blackout_minutes,'last':self.last}
