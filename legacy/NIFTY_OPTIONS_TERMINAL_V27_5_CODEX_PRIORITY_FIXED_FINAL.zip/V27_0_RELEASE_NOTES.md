# V27.0 — Verified Autonomous Repair
- Autonomous diagnosis orchestration around the verified V18 repair engine.
- Sandbox/test/security verification remains mandatory.
- Rollback remains automatic when promotion verification fails.
- Promotion is disabled by default and requires explicit policy enablement.
- Live orders remain permanently disabled in this release.
