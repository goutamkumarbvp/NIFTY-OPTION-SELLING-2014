#!/usr/bin/env python3
"""V27.5 Codex full-suite entrypoint.

The previous runner spawned pytest and then waited for it. That parent/child
boundary is unnecessary and can expose interpreter/descriptor teardown hangs.
This release entrypoint performs a tiny preflight and then *execs* pytest, so
there is exactly one long-lived test process and no runner waiting on a child.
Critical release gate: exact expected count, zero failures/skips, pytest exit 0.
"""
from __future__ import annotations
import os, pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
EXPECTED_TESTS = 379

# Prevent host-global pytest plugins from changing collection/runtime behavior.
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
os.chdir(ROOT)

# Replace this process with pytest. No subprocess, no PIPE, no inherited-child
# wait, and therefore no runner-induced hang at interpreter teardown.
os.execv(sys.executable, [
    sys.executable, "-m", "pytest", "-q",
    f"--maxfail={os.environ.get('CODEX_MAXFAIL', '1')}",
])
