import urllib.request
base='http://127.0.0.1:8500/'
raw=urllib.request.urlopen(base,timeout=3).read().decode('utf-8','replace')
assert '<html' in raw.lower() and 'v27' in raw.lower()
print('BROWSER_HTTP_SMOKE_PASS')
