import json, os, time, urllib.request
base=os.getenv('BASE_URL','http://127.0.0.1:8500')
end=time.time()+float(os.getenv('SOAK_SECONDS','60')); n=0
while time.time()<end:
    with urllib.request.urlopen(base+'/api/health',timeout=3) as r:
        assert r.status==200 and json.load(r)['live_orders_enabled'] is False
    n+=1; time.sleep(1)
print(f'SOAK_PASS requests={n}')
