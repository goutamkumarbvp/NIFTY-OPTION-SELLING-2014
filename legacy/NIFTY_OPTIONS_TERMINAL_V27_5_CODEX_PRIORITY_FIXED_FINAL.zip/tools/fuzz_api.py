import json, os, urllib.request
base=os.getenv('BASE_URL','http://127.0.0.1:8500'); paths=['/api/state','/api/refresh','/api/paper/order','/api/research/v13/calendar-check']
inputs=[None,[],1,'x',{}, {'x':None},{'x':'a'*10000}]
for p in paths:
  for body in inputs:
    req=urllib.request.Request(base+p,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'},method='POST')
    try:
      with urllib.request.urlopen(req,timeout=3) as r: assert 200<=r.status<500
    except urllib.error.HTTPError as e: assert e.code in {400,404,409,413,422}
print('FUZZ_PASS')
