from research_data import HistoricalOptionChainValidator

def snap(ts='2026-01-01T09:15:00+05:30'):
 return {'timestamp':ts,'spot':25000,'expiry':'2026-01-01','contracts':[{'symbol':'NIFTY','option_type':'CE','strike':25000,'bid':100,'ask':101,'oi':1000,'volume':100,'instrument_token':'1'}]}
def test_option_chain_schema_ready(): assert HistoricalOptionChainValidator.validate([snap()])['status']=='READY'
def test_option_chain_schema_bad_quote():
 x=snap(); x['contracts'][0]['ask']=0; assert HistoricalOptionChainValidator.validate([x])['reason']=='INVALID_QUOTE'
def test_option_chain_schema_order(): assert HistoricalOptionChainValidator.validate([snap(),snap('2026-01-01T09:14:00+05:30')])['reason']=='NON_MONOTONIC_TIMESTAMP'
