# V25.0 — Agent Memory + Long-Term Learning
- Durable SQLite episode memory.
- Outcome/reward recording and bounded hypothesis knowledge base.
- Secret-key redaction before persistence.
- Bounded retrieval and indexed history.
- Memory is advisory only; it cannot bypass Risk/Safety gates.
