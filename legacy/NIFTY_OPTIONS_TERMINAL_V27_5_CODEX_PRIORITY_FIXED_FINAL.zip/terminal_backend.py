#!/usr/bin/env python3
from __future__ import annotations

import json, os, threading, time, uuid, hashlib, traceback, re, math, weakref
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from market_service import Market
from intelligence_service import Intelligence
from research_service import Research
from ai_service import Ai
import importlib
from self_healing import SelfHealingSupervisor

ROOT=Path(__file__).resolve().parent
_BACKENDS = weakref.WeakSet()
_BACKENDS_LOCK = threading.RLock()

class Audit:
    _global_lock=threading.RLock()
    """Append-only hash-chained audit log; corruption fails closed at startup."""
    def __init__(self,path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self.lock=threading.Lock(); self.previous_hash='0'*64
        self.verify()
    def _hash(self,row):
        body=json.dumps(row,sort_keys=True,separators=(',',':')).encode()
        return hashlib.sha256(body).hexdigest()
    def verify(self):
        if not self.path.exists(): return True
        prev='0'*64
        for line in self.path.read_text(encoding='utf-8').splitlines():
            row=json.loads(line); expected=row.pop('hash',None)
            if row.get('prev_hash')!=prev or expected!=self._hash(row): raise RuntimeError('AUDIT_CHAIN_CORRUPTED')
            prev=expected
        self.previous_hash=prev; return True
    def record(self,event,detail=None):
        with Audit._global_lock:
            # Refresh the chain head immediately before append so multiple terminal
            # objects in one process cannot fork the audit chain.
            self.verify()
            row={'ts':datetime.now(timezone.utc).isoformat(),'event':event,'detail':detail or {},'prev_hash':self.previous_hash}
            h=self._hash(row); row['hash']=h
            with self.path.open('a',encoding='utf-8') as f:
                f.write(json.dumps(row,separators=(',',':'))+'\n'); f.flush(); os.fsync(f.fileno())
            self.previous_hash=h
            return row
class TerminalBackend:
    def __init__(self):
        importlib.import_module("runtime_config").assert_paper_only()
        self.ROOT=ROOT
        self.lock=threading.RLock(); self.audit=Audit(ROOT/'runtime'/'audit.jsonl')
        self.mode='NORMAL'; self.engine_running=False; self.paused=False; self.live_orders_enabled=False
        self.last_error=''; self.action_log=[]
        # Server-owned paper account risk state; HTTP input has no account authority.
        try:
            self.paper_initial_margin=float(os.getenv('PAPER_INITIAL_MARGIN','100000'))
        except (TypeError, ValueError):
            self.paper_initial_margin=100000.0
        if not math.isfinite(self.paper_initial_margin) or self.paper_initial_margin <= 0:
            raise RuntimeError('PAPER_INITIAL_MARGIN_INVALID')
        self.paper_daily_pnl=0.0
        self.broker_daily_pnl=0.0
        # V22 composition root: concrete implementations are created once here and
        # injected through explicit dependency contracts. Services no longer import
        # infrastructure/domain implementations directly.
        self.dependencies=importlib.import_module("composition").build_dependencies(ROOT, self._healing_audit)
        self.paper_ledger=self.dependencies.paper_execution_factory(ROOT/'runtime'/'paper_trading.sqlite3')
        self.event_bus=self.dependencies.event_bus
        self.market_service=Market(self, self.dependencies.market)
        self.intelligence_service=Intelligence(self, self.dependencies.intelligence)
        self.research_service=Research(self, self.dependencies.research)
        self.ai_service=Ai(self, self.dependencies.ai)
        self.self_healing=SelfHealingSupervisor(self._healing_health, self._healing_recover, self._healing_audit,
            stale_seconds=float(os.getenv('SELF_HEAL_FEED_STALE_SECONDS','8')),
            cooldown_seconds=float(os.getenv('SELF_HEAL_COOLDOWN_SECONDS','15')),
            max_recoveries=int(os.getenv('SELF_HEAL_MAX_RECOVERIES','5')),
            window_seconds=float(os.getenv('SELF_HEAL_WINDOW_SECONDS','300')))
        self._workers_started = False
        self._auto_repair_queue=[]
        self._auto_repair_lock=threading.RLock()
        self._auto_repair_last=0.0
        # Create the stop event BEFORE starting the worker. The old ordering let
        # the worker observe a fresh fallback Event forever, defeating shutdown.
        self._auto_repair_stop=threading.Event()
        self._auto_repair_thread=threading.Thread(target=self._auto_repair_worker, daemon=True, name='paper-auto-repair')
        with _BACKENDS_LOCK:
            _BACKENDS.add(self)
        if os.getenv('TERMINAL_AUTOSTART_WORKERS','true').strip().lower() in {'1','true','yes','on'}:
            self.start_workers()

    def start_workers(self) -> None:
        if self._workers_started:
            return
        self._workers_started = True
        self.self_healing.start()
        if not self._auto_repair_thread.is_alive():
            self._auto_repair_thread.start()

    def shutdown(self, wait: bool = True) -> None:
        """Stop all runtime workers owned by this backend.

        Normal callers wait briefly for cooperative worker shutdown. During
        interpreter finalization we only signal workers and return immediately;
        joining a large number of daemon workers from an ``atexit`` handler can
        otherwise make pytest/application exit appear to hang.
        """
        try:
            self._auto_repair_stop.set()
        except Exception:
            pass
        try:
            if wait and getattr(self, '_auto_repair_thread', None) and self._auto_repair_thread.is_alive():
                self._auto_repair_thread.join(timeout=2.0)
        except Exception:
            pass
        try:
            if getattr(self, 'self_healing', None):
                if wait:
                    self.self_healing.stop()
                else:
                    # Signal the supervisor without waiting during interpreter
                    # teardown; its worker is daemonized and will be terminated
                    # by the interpreter once shutdown progresses.
                    self.self_healing._stop.set()
                    self.self_healing._wake.set()
        except Exception:
            pass
        try:
            if getattr(self, 'feed', None):
                if wait:
                    self.feed.stop()
                else:
                    try:
                        self.feed.stop(wait=False)
                    except TypeError:
                        # Older feed implementations have no wait parameter;
                        # they are daemon-backed, so signal if possible.
                        getattr(self.feed, 'stop_event', None) and self.feed.stop_event.set()
        except Exception:
            pass

    def _log(self,action,result='OK',detail=None):
        item={'id':str(uuid.uuid4()),'time':datetime.now(timezone.utc).isoformat(),'action':action,'result':result,'detail':detail or {}}; self.action_log=(self.action_log+[item])[-100:]; self.audit.record(action,item);
        try: contracts=importlib.import_module('application_contracts'); self.event_bus.publish(contracts.DomainEvent(contracts.EventTopic.AUDIT_ACTION, item))
        except Exception: pass
        return item
    def _record_pcr_snapshot(self, stats):
        # Keep a bounded, timestamped history for dashboard monitoring. Values are
        # derived only from the currently loaded option chain; no synthetic values.
        if not isinstance(stats, dict): return
        row={
            'timestamp': stats.get('updated_at') or datetime.now(timezone.utc).isoformat(),
            'pcr_oi': stats.get('pcr_oi'),
            'pcr_doi': stats.get('pcr_doi'),
            'call_oi': stats.get('call_oi'),
            'put_oi': stats.get('put_oi'),
            'call_doi': stats.get('call_doi'),
            'put_doi': stats.get('put_doi'),
        }
        self.pcr_history=(self.pcr_history+[row])[-240:]

    def _healing_audit(self, event, detail):
        try:
            self._log(event, detail=detail)
        except Exception:
            pass

    def _healing_health(self):
        with self.lock:
            f = self.feed.state.snapshot() if self.feed else {'connected': False, 'age': None, 'market_status': 'NOT_STARTED'}
            thread_alive = bool(self.feed_supervisor and self.feed_supervisor.thread and self.feed_supervisor.thread.is_alive())
            return {
                'authenticated': self.authenticated, 'feed_enabled': self.feed_auto_enabled,
                'feed_thread_alive': thread_alive, 'connected': bool(f.get('connected')),
                'age': f.get('age'), 'market_status': f.get('market_status'),
                'mode': self.mode, 'paused': self.paused,
            }

    def _healing_recover(self):
        if self.mode in {'EMERGENCY', 'PAUSED'}:
            return {'ok': False, 'error': 'SAFETY_STATE'}
        if not self.feed_auto_enabled or not self.feed_tokens:
            return {'ok': False, 'error': 'FEED_NOT_ARMED'}
        try:
            self.stop_feed()
            time.sleep(0.2)
            return self.start_feed({})
        except Exception as e:
            return {'ok': False, 'error': str(e)}

    def _evaluate_alerts(self, nifty=None, feed=None):
        f=feed or {}
        try:
            self.alerts.evaluate_market(nifty, self.previous_nifty, f.get('age'), bool(f.get('connected')), trace='terminal')
        finally:
            if nifty is not None:
                self.previous_nifty=float(nifty)
            self.last_alert_eval=time.time()


    def _require(self):
        if not self.adapter or not self.authenticated: raise RuntimeError('NOT_AUTHENTICATED')
    def _queue_runtime_repair(self, action, error_text):
        if os.getenv('PAPER_AUTO_SELF_REPAIR','false').lower() != 'true':
            return
        if os.getenv('TRADING_MODE','paper').lower() != 'paper' or os.getenv('LIVE_TRADING','false').lower() == 'true' or os.getenv('LIVE_ORDERS_ENABLED','false').lower() == 'true':
            return
        tb=traceback.format_exc()
        text=f"action={action}\nerror={error_text}\n{tb}"
        target=None
        for m in re.finditer(r'File [\"\']([^\"\']+)[\"\'], line \d+', tb):
            candidate=Path(m.group(1)).resolve()
            if candidate.is_file() and candidate.is_relative_to(self.ROOT) and candidate.suffix=='.py':
                target=candidate
        if target is None: return
        with self._auto_repair_lock:
            if len(self._auto_repair_queue) >= 3: return
            self._auto_repair_queue.append((time.time(), action, text, target))
        try: self.audit.record('AUTO_REPAIR_QUEUED', {'action':action,'target':str(target)})
        except Exception: pass

    def _auto_repair_worker(self):
        while not self._auto_repair_stop.is_set():
            item=None
            with getattr(self, '_auto_repair_lock', threading.RLock()):
                if getattr(self, '_auto_repair_queue', []): item=self._auto_repair_queue.pop(0)
            if item:
                ts, action, text, target=item
                if time.time()-getattr(self,'_auto_repair_last',0)<float(os.getenv('SELF_REPAIR_COOLDOWN_SECONDS','15')):
                    time.sleep(1); continue
                self._auto_repair_last=time.time()
                try:
                    d=self.self_repair.diagnose(text,target)
                    r=self.self_repair.propose_and_verify(d,target,promote=False)
                    self.audit.record('AUTO_REPAIR_COMPLETED', {'action':action,'target':str(target),'status':r.status,'promoted':r.promoted})
                except Exception as ex:
                    try: self.audit.record('AUTO_REPAIR_FAILED', {'action':action,'target':str(target),'error':str(ex)})
                    except Exception: pass
            else:
                time.sleep(0.25)

    def _fail(self,action,e):
        self.last_error=str(e)
        try: self._queue_runtime_repair(action, str(e))
        except Exception: pass
        return {'ok':False,'error':str(e),'state':self.state(),'action':self._log(action,'FAILED',{'error':str(e)})}












    def _paper_market_evidence(self, symbol):
        """Return trusted current paper quote evidence; fail closed without a fresh feed."""
        f=self.feed.state.snapshot() if self.feed else {'connected':False,'age':None,'local_sequence':0}
        age=f.get('age')
        try: age=float(age)
        except (TypeError, ValueError): age=float('nan')
        if f.get('connected') is not True or not math.isfinite(age) or age < 0 or age > 5.0:
            raise RuntimeError('PAPER_MARKET_DATA_NOT_FRESH')
        try: sequence=int(f.get('local_sequence',0) or 0)
        except (TypeError, ValueError): sequence=0
        if sequence <= 0:
            raise RuntimeError('PAPER_MARKET_DATA_NOT_RECEIVED')
        requested=str(symbol or '').strip().upper()
        if not requested:
            raise RuntimeError('SYMBOL_REQUIRED')
        matches=[]
        for tick in self.ticks.values():
            ts=getattr(tick,'timestamp',None); ltp=getattr(tick,'ltp',None)
            if ts is None or ltp is None: continue
            try:
                tick_age=time.time()-float(ts); px=float(ltp)
            except (TypeError, ValueError): continue
            if not math.isfinite(tick_age) or tick_age < -2.0 or tick_age > 5.0 or not math.isfinite(px) or px <= 0: continue
            tsym=str(getattr(tick,'trading_symbol',None) or '').strip().upper()
            token=str(getattr(tick,'instrument_token',None) or '').strip().lower()
            canonical = {'NIFTY', 'NIFTY 50', 'NIFTY50'}
            if requested in canonical:
                # Exact canonical NIFTY index identity only. Never accept BANKNIFTY
                # or any derivative merely because its symbol contains 'NIFTY'.
                if tsym in canonical or token == 'nifty 50':
                    matches.append((tick_age,px,tick))
            elif tsym == requested:
                matches.append((tick_age,px,tick))
        if not matches:
            raise RuntimeError('INSTRUMENT_MARKET_DATA_REQUIRED')
        matches.sort(key=lambda x:x[0])
        return matches[0][1], matches[0][2]

    def paper_risk_evidence(self):
        """Build risk evidence exclusively from server-owned paper state."""
        positions=self.paper_ledger.positions(); gross=0.0; rows=[]
        for pos in positions:
            q=float(pos.get('net_quantity',0) or 0)
            px=pos.get('avg_buy_price') if q > 0 else pos.get('avg_sell_price')
            if q and px is None: raise RuntimeError('PAPER_POSITION_PRICE_MISSING')
            if q:
                px=float(px)
                if not math.isfinite(px) or px <= 0: raise RuntimeError('PAPER_POSITION_PRICE_INVALID')
                gross += abs(q*px)
            if q:
                rows.append({'quantity':q,'averagePrice':px})
        available=max(self.paper_initial_margin-gross,0.0)
        return {'positions':rows,'limits':{'data':{'availableMargin':available,'marginUsed':gross}},'daily_pnl':float(self.paper_daily_pnl)}

    def paper_order(self,b=None):
        # Serialize the complete check -> risk -> quote -> ledger transaction. A
        # risk gate is only meaningful if concurrent requests cannot all approve
        # against the same pre-trade position snapshot.
        with self.lock:
            try:
                if self.mode=='EMERGENCY': raise RuntimeError('EMERGENCY_STOP_ACTIVE')
                if self.mode!='NORMAL' or self.paused: raise RuntimeError('EXECUTION_PAUSED')
                b=b or {}
                # Every paper execution must pass the deterministic RiskBrain. Account
                # evidence is rebuilt from the server-owned paper ledger immediately before submit.
                if self.risk_snapshot is None:
                    raise RuntimeError('PAPER_RISK_EVALUATION_REQUIRED')
                snap=self.risk_snapshot
                if not all(math.isfinite(float(getattr(snap,k))) for k in ('daily_pnl','gross_exposure','margin_used','available_margin','margin_utilization','net_qty')):
                    raise RuntimeError('PAPER_RISK_SNAPSHOT_INVALID')
                evidence=self.paper_risk_evidence()
                fresh_snap=self.risk_brain.snapshot(evidence['positions'],evidence['limits'],evidence['daily_pnl'])
                # First reject obviously unsafe requests without requiring market data; this
                # keeps deterministic quantity/side violations fail-closed. Then obtain a
                # trusted quote and perform the authoritative final risk evaluation using it.
                preliminary_price=b.get('fill_price',b.get('limit_price',0))
                preliminary=self.risk_brain.evaluate(fresh_snap,{'side':b.get('side'),'quantity':b.get('quantity'),'price':preliminary_price})
                if preliminary.get('decision')!='ALLOW_PAPER':
                    self.risk_snapshot=fresh_snap
                    self.mode='PAUSED' if self.mode!='EMERGENCY' else self.mode
                    raise RuntimeError('RISK_GATE_BLOCKED:'+','.join(preliminary.get('reasons',[])))
                trusted_price,_tick=self._paper_market_evidence(b.get('symbol'))
                final_snap=self.risk_brain.snapshot(evidence['positions'],evidence['limits'],evidence['daily_pnl'])
                order={'side':b.get('side'),'quantity':b.get('quantity'),'price':trusted_price}
                decision=self.risk_brain.evaluate(final_snap,order)
                self.risk_snapshot=final_snap
                if decision.get('decision')!='ALLOW_PAPER':
                    self.mode='PAUSED' if self.mode!='EMERGENCY' else self.mode
                    raise RuntimeError('RISK_GATE_BLOCKED:'+','.join(decision.get('reasons',[])))
                # Authoritative final safety gate immediately before the ledger
                # commit.  Because panic uses the same lock, the state transition
                # and this commit are linearized and cannot cross each other.
                if self.mode=='EMERGENCY' or self.paused:
                    raise RuntimeError('EXECUTION_ABORTED_BY_SAFETY_STATE')
                requested_fill=b.get('fill_price')
                if requested_fill is not None:
                    try:
                        fp=float(requested_fill)
                        if not math.isfinite(fp) or abs(fp-trusted_price) > max(0.01,trusted_price*0.01):
                            raise RuntimeError('FILL_PRICE_MISMATCH_MARKET')
                    except (TypeError, ValueError):
                        raise RuntimeError('FILL_PRICE_INVALID')
                o=self.paper_ledger.submit(b.get('symbol'),b.get('side'),b.get('quantity'),b.get('order_type','MARKET'),b.get('limit_price'),trusted_price)
                self.local_positions=self.paper_ledger.positions()
                return {'ok':True,'data':o,'positions':self.local_positions,'paper_only':True,'live_orders_enabled':False,'risk_gate':decision,'action':self._log('PAPER_ORDER_FILLED',detail={'order_id':o['order_id'],'risk_gate':decision})}
            except Exception as e: return self._fail('PAPER_ORDER',e)

    def paper_cancel(self,b=None):
        try:
            o=self.paper_ledger.cancel((b or {}).get('order_id')); return {'ok':True,'data':o,'action':self._log('PAPER_ORDER_CANCELLED',detail={'order_id':o['order_id']})}
        except Exception as e: return self._fail('PAPER_CANCEL',e)

    def paper_mark(self,b=None):
        # Account P&L is derived from trusted, fresh market ticks only. Caller-supplied
        # prices are deliberately ignored/rejected so mark-to-market cannot become a
        # risk-authority injection channel.
        try:
            supplied=(b or {}).get('prices')
            if supplied not in (None, {}):
                raise RuntimeError('CLIENT_MARK_PRICES_FORBIDDEN')
            prices={}
            for pos in self.paper_ledger.positions():
                symbol=str(pos.get('symbol') or '').strip().upper()
                if not symbol: raise RuntimeError('PAPER_POSITION_SYMBOL_MISSING')
                px,_tick=self._paper_market_evidence(symbol)
                prices[symbol]=px
            marked=self.paper_ledger.mark_to_market(prices)
            total=float(marked.get('total_pnl',0))
            if not math.isfinite(total): raise RuntimeError('PAPER_PNL_INVALID')
            with self.lock:
                self.paper_daily_pnl=total
            return {'ok':True,'data':marked,'paper_only':True,'trusted_prices':prices,'action':self._log('PAPER_MARK_TO_MARKET')}
        except Exception as e: return self._fail('PAPER_MARK',e)

    def paper_flatten(self,b=None):
        # Flattening is also market-data dependent: never let the browser choose
        # the exit price used by the paper ledger. Rebuild every exit price from
        # the same trusted-tick path used by paper order/MTM.  Serialize the
        # complete snapshot -> quote -> flatten transaction so concurrent
        # flatten requests cannot both act on the same pre-flatten position.
        try:
            with self.lock:
                supplied=(b or {}).get('prices')
                if supplied not in (None, {}): raise RuntimeError('CLIENT_FLATTEN_PRICES_FORBIDDEN')
                prices={}
                for pos in self.paper_ledger.positions():
                    symbol=str(pos.get('symbol') or '').strip().upper()
                    if not symbol: raise RuntimeError('PAPER_POSITION_SYMBOL_MISSING')
                    px,_tick=self._paper_market_evidence(symbol)
                    prices[symbol]=px
                out=self.paper_ledger.flatten(prices); self.local_positions=self.paper_ledger.positions()
                return {'ok':True,'data':out,'positions':self.local_positions,'paper_only':True,'trusted_prices':prices,'action':self._log('PAPER_FLATTEN',detail={'count':len(out)})}
        except Exception as e: return self._fail('PAPER_FLATTEN',e)

    def refresh(self): self.last_refresh=time.time(); return self.state()
    def state(self):
        with self.lock:
            f=self.feed.state.snapshot() if self.feed else {'connected':False,'age':None,'reconnects':0,'market_status':'NOT_STARTED','local_sequence':0,'last_error':''}
            fresh=(f.get('connected') is True and f.get('age') is not None and math.isfinite(float(f['age'])) and 0 <= float(f['age']) <= 5 and int(f.get('local_sequence',0) or 0) > 0); nifty=None
            # Prefer actual Nifty-50 index tick by trading symbol; otherwise do not invent a spot.
            for t in self.ticks.values():
                ts=str(t.trading_symbol or '').strip().upper()
                if ts in {'NIFTY','NIFTY 50','NIFTY50'} or str(t.instrument_token or '').strip().lower()=='nifty 50':
                    nifty=t.ltp; break
            self._evaluate_alerts(nifty, f)
            m={'nifty':nifty,'change':None,'change_pct':None,'vix':None,'source':'kotak_neo_sfeed' if nifty is not None else None,'pcr_oi':self.chain_stats.get('pcr_oi'),'pcr_doi':self.chain_stats.get('pcr_doi'),'iv_rank':None,'iv_percentile':None,'regime':self.last_regime.get('regime','UNKNOWN'),'regime_confidence':self.last_regime.get('confidence',0),'options_intelligence':self.last_intelligence}
            return {'version':'v27.5','api_schema_version':'v12.0','release':'V27.5','timestamp':datetime.now(timezone.utc).isoformat(),'mode':self.mode,'engine_running':self.engine_running,'paused':self.paused,'paper_only':True,'live_orders_enabled':False,'broker':{'name':'Kotak Neo','authenticated':self.authenticated},'self_healing':self.self_healing.snapshot(),'self_repair':self.self_repair.status(),'event_bus':self.event_bus.stats(),'feed':{'connected':f.get('connected',False),'fresh':fresh,'market_status':f.get('market_status'),'age':f.get('age'),'local_sequence':f.get('local_sequence',0),'reconnects':f.get('reconnects',0),'last_error':f.get('last_error',''),'subscribed_tokens':len(self.feed_tokens)},'market':m,'risk':{'risk_state':('EMERGENCY' if self.mode=='EMERGENCY' else ('PAUSED' if self.mode=='PAUSED' else ('READY' if self.risk_snapshot and self.risk_brain.health(self.risk_snapshot)['healthy'] else 'NO_VALID_RISK_SNAPSHOT'))),'live_execution':'DISABLED','snapshot':self.risk_snapshot.__dict__ if self.risk_snapshot else None,'limits':self.risk_brain.health(self.risk_snapshot)['limits']},'decision':{'action':(self.last_plan or {}).get('status','NO TRADE'),'confidence':((self.last_plan or {}).get('candidates') or [{}])[0].get('score',0) if self.last_plan else 0,'reason':'Strategy Brain is deterministic and requires independent Risk Brain approval; execution remains disabled.'},'strategy_plan':self.last_plan,'advanced_risk':self.last_advanced_risk,'quant':{'greeks':self.last_greeks},'vol_surface':self.last_surface,'events':self.last_events,'fii_dii':self.last_flows,'backtest':self.last_backtest,'research_data':self.last_data_ingest,'option_backtest':self.last_option_backtest,'walk_forward':self.last_walk_forward,'stress':self.last_stress,'strategy_backtest':self.last_strategy_backtest,'optimization':self.last_optimization,'robustness':self.last_robustness,'mc_validation':self.last_mc_validation,'option_chain_ingest':self.last_option_ingest,'option_chain_replay':self.last_replay,'research_margin':self.last_research_margin,'v10':self.last_v10,'v11':self.last_v11,'v12':self.last_v12,'v13':self.last_v13,'super_ai':self.last_super_agent,'ai_platform':{'v24_llm_gateway':{'version':'v24.0','configured':bool(getattr(self,'llm_gateway',None) and self.llm_gateway.url),'remote_enabled':bool(getattr(self,'llm_gateway',None) and self.llm_gateway.allow_remote)},'v25_long_term_memory':{'version':'v25.0','episodes':len(self.long_term_memory.recent(200)) if hasattr(self,'long_term_memory') else 0},'v26_autonomous_research':{'version':'v26.0','enabled':hasattr(self,'autonomous_research')},'v27_verified_repair':self.verified_repair.status() if hasattr(self,'verified_repair') else {}},'pass17_agent':self.last_pass17,'option_chain':self.chain,'chain_metrics':self.chain_stats,'pcr_history':self.pcr_history,'agents':[{'id':'27','name':'Core & Tools','status':'ACTIVE','role':'Backend control plane'},{'id':'28','name':'Market Intel','status':'ACTIVE','role':'Live feed health'},{'id':'29','name':'OI Intelligence','status':'ACTIVE' if self.chain else 'WAITING','role':'OI / ΔOI / PCR'},{'id':'31','name':'Risk Brain','status':'ACTIVE','role':'Execution gate'},{'id':'32','name':'Execution','status':'LOCKED','role':'Live orders disabled'},{'id':'33','name':'Extreme Super Agent','status':'ACTIVE' if self.last_super_agent else 'READY','role':'4-agent coordination / diagnosis / planning / safety-gated reasoning'}],'positions':self.broker_positions,'paper_positions':self.paper_ledger.positions(),'orders':self.paper_ledger.orders(),'reconciliation':self.reconciliation,'soak':self.last_soak,'health':[{'name':'Backend API','status':'HEALTHY'},{'name':'Kotak Authentication','status':'AUTHENTICATED' if self.authenticated else 'NOT AUTHENTICATED'},{'name':'SFeed','status':'HEALTHY' if fresh else ('CONNECTED_NO_FRESH_TICK' if f.get('connected') else 'NOT CONNECTED')},{'name':'Option Chain','status':'LIVE' if self.chain else 'NO LIVE DATA'},{'name':'Risk Brain','status':'HEALTHY' if self.risk_snapshot and self.risk_brain.health(self.risk_snapshot)['healthy'] else 'BLOCKED/WAITING'},{'name':'Execution','status':'DISABLED'},{'name':'Audit','status':'ACTIVE'}],'recent_actions':self.action_log[-15:][::-1],'alerts':self.alerts.recent(20)}



    # Thin compatibility facade: HTTP/tests call the backend, while domain logic lives in services.
    def _adapter_from_env(self,b=None): return self.market_service._adapter_from_env(b)
    def authenticate(self,b=None): return self.market_service.authenticate(b)
    def v15_discover(self,b=None): return self.market_service.v15_discover(b)
    def v15_chain_auto(self,b=None): return self.market_service.v15_chain_auto(b)
    def v15_feed_soak_status(self,b=None): return self.market_service.v15_feed_soak_status(b)
    def v15_prepare_feed(self,b=None): return self.market_service.v15_prepare_feed(b)
    def v14_config_status(self,b=None): return self.market_service.v14_config_status(b)
    def v14_status(self,b=None): return self.market_service.v14_status(b)
    def v14_read(self,b=None): return self.market_service.v14_read(b)
    def load_expiries(self,b=None): return self.market_service.load_expiries(b)
    def load_option_chain(self,b=None): return self.market_service.load_option_chain(b)
    def start_feed(self,b=None): return self.market_service.start_feed(b)
    def stop_feed(self,b=None): return self.market_service.stop_feed(b)
    def reconnect_feed(self,b=None): return self.market_service.reconnect_feed(b)
    def read_positions(self,b=None): return self.market_service.read_positions(b)
    def read_holdings(self,b=None): return self.market_service.read_holdings(b)
    def quote(self,b=None): return self.market_service.quote(b)
    def run_soak(self,b=None): return self.market_service.run_soak(b)
    def risk_evaluate(self,b=None): return self.intelligence_service.risk_evaluate(b)
    def options_intelligence(self,b=None): return self.intelligence_service.options_intelligence(b)
    def regime_analyze(self,b=None): return self.intelligence_service.regime_analyze(b)
    def advanced_risk_evaluate(self,b=None): return self.intelligence_service.advanced_risk_evaluate(b)
    def strategy_analyze(self,b=None): return self.intelligence_service.strategy_analyze(b)
    def quant_greeks(self,b=None): return self.intelligence_service.quant_greeks(b)
    def quant_iv(self,b=None): return self.intelligence_service.quant_iv(b)
    def surface_load(self,b=None): return self.intelligence_service.surface_load(b)
    def surface_query(self,b=None): return self.intelligence_service.surface_query(b)
    def event_analyze(self,b=None): return self.intelligence_service.event_analyze(b)
    def flow_analyze(self,b=None): return self.intelligence_service.flow_analyze(b)
    def strategy_health(self,b=None): return self.intelligence_service.strategy_health(b)
    def risk_health(self,b=None): return self.intelligence_service.risk_health(b)
    def read_limits(self,b=None): return self.intelligence_service.read_limits(b)
    def backtest_run(self,b=None): return self.research_service.backtest_run(b)
    def research_ingest(self,b=None): return self.research_service.research_ingest(b)
    def option_backtest_run(self,b=None): return self.research_service.option_backtest_run(b)
    def walk_forward_run(self,b=None): return self.research_service.walk_forward_run(b)
    def stress_run(self,b=None): return self.research_service.stress_run(b)
    def strategy_backtest_run(self,b=None): return self.research_service.strategy_backtest_run(b)
    def optimize_run(self,b=None): return self.research_service.optimize_run(b)
    def robustness_run(self,b=None): return self.research_service.robustness_run(b)
    def mc_validation_run(self,b=None): return self.research_service.mc_validation_run(b)
    def option_chain_ingest(self,b=None): return self.research_service.option_chain_ingest(b)
    def option_chain_replay(self,b=None): return self.research_service.option_chain_replay(b)
    def research_margin(self,b=None): return self.research_service.research_margin(b)
    def v10_import_csv(self,b=None): return self.research_service.v10_import_csv(b)
    def v10_ingest(self,b=None): return self.research_service.v10_ingest(b)
    def v10_read(self,b=None): return self.research_service.v10_read(b)
    def v10_parquet(self,b=None): return self.research_service.v10_parquet(b)
    def v10_calendar_check(self,b=None): return self.research_service.v10_calendar_check(b)
    def v11_register(self,b=None): return self.research_service.v11_register(b)
    def v11_versions(self,b=None): return self.research_service.v11_versions(b)
    def v11_series_map(self,b=None): return self.research_service.v11_series_map(b)
    def v11_query_snapshots(self,b=None): return self.research_service.v11_query_snapshots(b)
    def v11_query_contracts(self,b=None): return self.research_service.v11_query_contracts(b)
    def v11_quality_score(self,b=None): return self.research_service.v11_quality_score(b)
    def v11_replay(self,b=None): return self.research_service.v11_replay(b)
    def v11_soak(self,b=None): return self.research_service.v11_soak(b)
    def v13_normalize(self,b=None): return self.research_service.v13_normalize(b)
    def v13_integrity_run(self,b=None): return self.research_service.v13_integrity_run(b)
    def v13_calendar_check(self,b=None): return self.research_service.v13_calendar_check(b)
    def v13_chain_group(self,b=None): return self.research_service.v13_chain_group(b)
    def v13_chain_nearest(self,b=None): return self.research_service.v13_chain_nearest(b)
    def v13_certify(self,b=None): return self.research_service.v13_certify(b)
    def v13_replay(self,b=None): return self.research_service.v13_replay(b)
    def v12_normalize(self,b=None): return self.research_service.v12_normalize(b)
    def v12_import(self,b=None): return self.research_service.v12_import(b)
    def v12_lineage(self,b=None): return self.research_service.v12_lineage(b)
    def v12_coverage_run(self,b=None): return self.research_service.v12_coverage_run(b)
    def v12_completeness_run(self,b=None): return self.research_service.v12_completeness_run(b)
    def v12_partition_manifest(self,b=None): return self.research_service.v12_partition_manifest(b)
    def v10_contract(self,b=None): return self.research_service.v10_contract(b)
    def super_ai_analyze(self,b=None): return self.ai_service.super_ai_analyze(b)
    def pass17_run(self,b=None): return self.ai_service.pass17_run(b)
    def pass17_memory(self,b=None): return self.ai_service.pass17_memory(b)
    def pass17_tools(self,b=None): return self.ai_service.pass17_tools(b)
    def self_repair_status(self,b=None): return self.ai_service.self_repair_status(b)
    def self_repair_diagnose(self,b=None): return self.ai_service.self_repair_diagnose(b)
    def self_repair_run(self,b=None): return self.ai_service.self_repair_run(b)
    def v24_reason(self,b=None): return self.ai_service.v24_reason(b)
    def v25_memory(self,b=None): return self.ai_service.v25_memory(b)
    def v26_research(self,b=None): return self.ai_service.v26_research(b)
    def v27_repair(self,b=None): return self.ai_service.v27_repair(b)
    def v27_repair_status(self,b=None): return self.ai_service.v27_repair_status(b)
    def alerts_recent(self,b=None): return self.ai_service.alerts_recent(b)
    def alerts_config(self,b=None): return self.ai_service.alerts_config(b)
    def alerts_test(self,b=None): return self.ai_service.alerts_test(b)
    def alerts_emit(self,b=None): return self.ai_service.alerts_emit(b)

    def command(self,a,b=None):
        contracts=importlib.import_module('application_contracts')
        if isinstance(a, contracts.ApplicationCommand):
            cmd=a; a=cmd.name.value; b=dict(cmd.payload)
        else:
            # Legacy/internal callers may use a command not yet represented in the
            # typed enum; keep compatibility while typed HTTP routes use CommandName.
            a=str(a)
        b=b or {}; 
        if a=='refresh': return {'ok':True,'state':self.refresh(),'action':self._log('REFRESH_BUTTON')}
        if a=='auth': return self.authenticate(b)
        if a=='expiries': return self.load_expiries(b)
        if a=='chain': return self.load_option_chain(b)
        if a=='quote': return self.quote(b)
        if a=='positions': return self.read_positions()
        if a=='holdings': return self.read_holdings()
        if a=='limits': return self.read_limits()
        if a=='risk': return self.risk_evaluate(b)
        if a=='options_intel': return self.options_intelligence()
        if a=='regime': return self.regime_analyze(b)
        if a=='advanced_risk': return self.advanced_risk_evaluate(b)
        if a=='risk_health': return self.risk_health()
        if a=='strategy': return self.strategy_analyze()
        if a=='strategy_health': return self.strategy_health()
        if a=='greeks': return self.quant_greeks(b)
        if a=='iv': return self.quant_iv(b)
        if a=='surface_load': return self.surface_load(b)
        if a=='surface_query': return self.surface_query(b)
        if a=='events': return self.event_analyze(b)
        if a=='flows': return self.flow_analyze(b)
        if a=='backtest': return self.backtest_run(b)
        if a=='research_ingest': return self.research_ingest(b)
        if a=='option_backtest': return self.option_backtest_run(b)
        if a=='walk_forward': return self.walk_forward_run(b)
        if a=='stress': return self.stress_run(b)
        if a=='strategy_backtest': return self.strategy_backtest_run(b)
        if a=='optimize': return self.optimize_run(b)
        if a=='robustness': return self.robustness_run(b)
        if a=='mc_validation': return self.mc_validation_run(b)
        if a=='option_chain_ingest': return self.option_chain_ingest(b)
        if a=='option_chain_replay': return self.option_chain_replay(b)
        if a=='research_margin': return self.research_margin(b)
        if a=='v10_import_csv': return self.v10_import_csv(b)
        if a=='v10_ingest': return self.v10_ingest(b)
        if a=='v10_read': return self.v10_read(b)
        if a=='v10_parquet': return self.v10_parquet(b)
        if a=='v10_calendar': return self.v10_calendar_check(b)
        if a=='v10_contract': return self.v10_contract(b)
        if a=='v11_register': return self.v11_register(b)
        if a=='v11_versions': return self.v11_versions(b)
        if a=='v11_series': return self.v11_series_map(b)
        if a=='v11_query_snapshots': return self.v11_query_snapshots(b)
        if a=='v11_query_contracts': return self.v11_query_contracts(b)
        if a=='v11_quality': return self.v11_quality_score(b)
        if a=='v11_replay': return self.v11_replay(b)
        if a=='v11_soak': return self.v11_soak(b)
        if a=='v12_normalize': return self.v12_normalize(b)
        if a=='v12_import': return self.v12_import(b)
        if a=='v12_lineage': return self.v12_lineage(b)
        if a=='v12_coverage': return self.v12_coverage_run(b)
        if a=='v12_completeness': return self.v12_completeness_run(b)
        if a=='v12_manifest': return self.v12_partition_manifest(b)
        if a=='v13_normalize': return self.v13_normalize(b)
        if a=='v13_integrity': return self.v13_integrity_run(b)
        if a=='v13_calendar': return self.v13_calendar_check(b)
        if a=='v13_chain': return self.v13_chain_group(b)
        if a=='v13_nearest': return self.v13_chain_nearest(b)
        if a=='v13_certify': return self.v13_certify(b)
        if a=='v13_replay': return self.v13_replay(b)
        if a=='v14_config': return self.v14_config_status(b)
        if a=='v14_status': return self.v14_status(b)
        if a=='v14_read': return self.v14_read(b)
        if a=='v15_discover': return self.v15_discover(b)
        if a=='v15_chain': return self.v15_chain_auto(b)
        if a=='v15_feed': return self.v15_prepare_feed(b)
        if a=='v15_soak_status': return self.v15_feed_soak_status(b)
        if a=='super_ai': return self.super_ai_analyze(b)
        if a=='pass17_run': return self.pass17_run(b)
        if a=='pass17_memory': return self.pass17_memory(b)
        if a=='pass17_tools': return self.pass17_tools(b)
        if a=='self_repair_status': return self.self_repair_status()
        if a=='self_repair_diagnose': return self.self_repair_diagnose(b)
        if a=='self_repair_run': return self.self_repair_run(b)
        if a=='v24_reason': return self.v24_reason(b)
        if a=='v25_memory': return self.v25_memory(b)
        if a=='v26_research': return self.v26_research(b)
        if a=='v27_repair': return self.v27_repair(b)
        if a=='v27_repair_status': return self.v27_repair_status(b)
        if a=='alerts_recent': return self.alerts_recent(b)
        if a=='alerts_config': return self.alerts_config(b)
        if a=='alerts_test': return self.alerts_test(b)
        if a=='alerts_emit': return self.alerts_emit(b)
        if a=='soak': return self.run_soak(b)
        if a=='feed_start': return self.start_feed(b)
        if a=='feed_stop': return self.stop_feed()
        if a=='feed_reconnect': return self.reconnect_feed()
        if a=='start':
            with self.lock:
                if self.mode=='EMERGENCY': return {'ok':False,'error':'Emergency stop active','state':self.state()}
                self.engine_running=True; return {'ok':True,'state':self.state(),'action':self._log('START_ENGINE')}
        if a=='stop':
            with self.lock:
                self.engine_running=False; return {'ok':True,'state':self.state(),'action':self._log('STOP_ENGINE')}
        if a=='pause':
            with self.lock:
                self.paused=True; self.mode='PAUSED'; return {'ok':True,'state':self.state(),'action':self._log('PAUSE_ENGINE')}
        if a=='resume':
            with self.lock:
                if self.mode=='EMERGENCY': return {'ok':False,'error':'Emergency stop active','state':self.state()}
                self.paused=False; self.mode='NORMAL'; return {'ok':True,'state':self.state(),'action':self._log('RESUME_ENGINE')}
        if a=='paper_order': return self.paper_order(b)
        if a=='paper_cancel': return self.paper_cancel(b)
        if a=='paper_mark': return self.paper_mark(b)
        if a=='paper_flatten': return self.paper_flatten(b)
        if a=='panic':
            # Emergency transition is serialized with the complete execution
            # critical section.  This makes panic and paper submission
            # linearizable: either the order commits before panic, or panic
            # commits first and the order is rejected.  The old implementation
            # changed mode without taking this lock, allowing an in-flight order
            # to commit after EMERGENCY was already visible.
            with self.lock:
                self.engine_running=False
                self.paused=True
                self.mode='EMERGENCY'
                self.alerts.emit('EMERGENCY','EMERGENCY','EMERGENCY STOP','Emergency stop activated; paper engine halted.','emergency-stop',force=True)
                return {'ok':True,'state':self.state(),'action':self._log('EMERGENCY_STOP',detail={'execution':'disabled'})}
        if a=='ai': return {'ok':True,'analysis':{'decision':'NO TRADE','confidence':0,'evidence':self.chain_stats,'feed':self.state()['feed']},'state':self.state(),'action':self._log('RUN_AI_ANALYSIS')}
        if a=='plan':
            return self.strategy_analyze()
        if a=='report': return {'ok':True,'report':{'version':'v27.5','authenticated':self.authenticated,'feed':self.state()['feed'],'chain_metrics':self.chain_stats,'actions':self.action_log[-30:]},'state':self.state(),'action':self._log('VIEW_FULL_REPORT')}
        if a=='nav': return {'ok':True,'target':b.get('target','dashboard'),'state':self.state(),'action':self._log('NAVIGATE',detail={'target':b.get('target','dashboard')})}
        return {'ok':False,'error':'UNKNOWN_ACTION'}



# Explicit worker lifecycle at interpreter shutdown; prevents leaked background
# workers from keeping resources/handles alive after tests or operator shutdown.
