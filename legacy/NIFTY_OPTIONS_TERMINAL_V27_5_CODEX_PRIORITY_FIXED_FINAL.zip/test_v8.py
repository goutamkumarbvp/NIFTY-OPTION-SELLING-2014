from strategy_backtest import MultiLegStrategyBacktester, StrategyOptimizer, robustness

def bars():
 return [
 {'quotes':{'NIFTY|CE|25000':{'bid':100,'ask':102},'NIFTY|PE|25000':{'bid':90,'ask':92}}},
 {'quotes':{'NIFTY|CE|25000':{'bid':101,'ask':103},'NIFTY|PE|25000':{'bid':89,'ask':91}}},
 {'spot':25000,'quotes':{'NIFTY|CE|25000':{'bid':.1,'ask':.2},'NIFTY|PE|25000':{'bid':.1,'ask':.2}}}]
def legs(): return [{'symbol':'NIFTY','option_type':'CE','strike':25000,'side':-1,'qty':1,'lot_size':75},{'symbol':'NIFTY','option_type':'PE','strike':25000,'side':-1,'qty':1,'lot_size':75}]
def test_multileg_ready(): assert MultiLegStrategyBacktester().run(bars(),legs())['status']=='READY'
def test_expiry_required():
 x=bars(); del x[-1]['spot']; assert MultiLegStrategyBacktester().run(x,legs())['reason']=='EXPIRY_SPOT_REQUIRED'
def test_quote_fail_closed():
 x=bars(); del x[1]['quotes']['NIFTY|CE|25000']; assert MultiLegStrategyBacktester().run(x,legs())['reason']=='MISSING_OR_INVALID_BID_ASK'
def test_margin_gate():
 from strategy_backtest import StrategyBacktestConfig
 x=MultiLegStrategyBacktester(StrategyBacktestConfig(initial_capital=1000)).run(bars(),legs()); assert x['reason']=='MARGIN_UTILIZATION_LIMIT'
def test_optimizer():
 x=StrategyOptimizer().grid(bars(),legs(),{'qty':[1,2]}); assert x['status']=='READY' and x['evaluated']==2
def test_robustness(): assert robustness([1,-1,2])['status']=='READY'
def test_robustness_bad(): assert robustness([1,float('nan')])['status']=='BLOCKED'

def test_mc_validation():
 from strategy_backtest import monte_carlo_validate
 assert monte_carlo_validate([1,-1,2,3,-2])['status']=='READY'
def test_mc_validation_rejects_short_sample():
 from strategy_backtest import monte_carlo_validate
 assert monte_carlo_validate([1,-1])['status']=='BLOCKED'
