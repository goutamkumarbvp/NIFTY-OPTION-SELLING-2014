# V27.3.1 Hardening Fix Report

## Repairs applied
1. Replaced the self-repair Linux chroot dependency on `/opt/pyvenv/bin/python` with a namespace-based Linux sandbox that uses a private `/tmp`, a dedicated writable `/workspace`, and no network namespace access.
2. Added Docker/Podman sandbox fallback for non-Linux hosts; no unsandboxed fallback exists.
3. Updated Dockerfile to create `/opt/pyvenv` deterministically and pin runtime PATH to it.
4. Added explicit TerminalBackend worker lifecycle: stop event is created before worker start; `start_workers()` is idempotent; server shutdown stops workers.
5. Added HTTP server daemon request threads, HTTP/1.0 connection closure, and explicit `Connection: close` headers to prevent leaked request threads.
6. Removed duplicate hardening test definitions.
7. Added test-only worker isolation in `conftest.py` so the application test suite cannot accumulate background runtime workers across cases.

## Verification
- Python compilation: PASS
- Independent security verifier: PASS
- Targeted self-repair/hardening/runtime tests: PASS
- Full collected suite: **374 passed**
- Server startup/health/shutdown: PASS

## Remaining external verification
Real credentialed Kotak Neo connectivity, real market-feed runtime, browser E2E on the user's Windows workstation, and long-duration production soak remain environment-dependent and are not represented as tested here.
