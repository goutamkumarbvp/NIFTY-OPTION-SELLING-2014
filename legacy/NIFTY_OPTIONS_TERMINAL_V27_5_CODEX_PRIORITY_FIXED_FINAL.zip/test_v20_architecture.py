import ast
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SERVICE_FILES=('market_service.py','intelligence_service.py','research_service.py','ai_service.py')
SERVICE_NAMES={'market_service','intelligence_service','research_service','ai_service'}
DOMAIN_MODULES={p.stem for p in ROOT.glob('*.py') if not p.name.startswith('test_')} - {'server','terminal_backend'}

def imports(path):
    t=ast.parse(path.read_text(encoding='utf-8')); out=set()
    for n in ast.walk(t):
        if isinstance(n,ast.Import): out |= {a.name.split('.')[0] for a in n.names}
        elif isinstance(n,ast.ImportFrom) and n.module: out.add(n.module.split('.')[0])
    return out

def production_fanout(path):
    return imports(path) & DOMAIN_MODULES

def test_backend_only_composes_services():
    im=imports(ROOT/'terminal_backend.py')
    assert not (im & (DOMAIN_MODULES - SERVICE_NAMES - {'self_healing'}))
    assert SERVICE_NAMES <= im

def test_service_boundaries_never_import_backend_or_server():
    for name in SERVICE_FILES:
        im=imports(ROOT/name)
        assert 'server' not in im and 'terminal_backend' not in im

def test_services_do_not_import_each_other():
    for name in SERVICE_FILES:
        assert not (imports(ROOT/name) & SERVICE_NAMES)

def test_server_is_transport_only():
    assert imports(ROOT/'server.py') == {'terminal_backend','json','os','http','pathlib','urllib','__future__','threading','signal','runtime_config'}

def test_research_service_fanout_is_bounded():
    assert len(production_fanout(ROOT/'research_service.py')) <= 13

def test_intelligence_service_fanout_is_bounded():
    assert len(production_fanout(ROOT/'intelligence_service.py')) <= 9

def test_market_service_fanout_is_bounded():
    assert len(production_fanout(ROOT/'market_service.py')) <= 7

def test_ai_service_fanout_is_bounded():
    assert len(production_fanout(ROOT/'ai_service.py')) <= 4

def test_no_domain_module_imports_server():
    offenders=[]
    for p in ROOT.glob('*.py'):
        if p.name.startswith('test_') or p.name in {'server.py','terminal_backend.py'}: continue
        if 'server' in imports(p): offenders.append(p.name)
    assert offenders == []

def test_backend_facade_has_no_domain_class_instantiation():
    t=ast.parse((ROOT/'terminal_backend.py').read_text())
    names={'RiskBrain','StrategyBrain','OptionsIntelligence','QuantEngine','ExtremeSuperAgent','ResearchBacktester','KotakNeoMarketAdapter','CodeSelfRepairEngine','AlertManager'}
    calls=[]
    for n in ast.walk(t):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in names: calls.append(n.func.id)
    assert calls == []
