import os, time
from types import SimpleNamespace


def _backend(tmp_path, monkeypatch):
    monkeypatch.setenv('RUNTIME_DIR', str(tmp_path))
    from terminal_backend import TerminalBackend
    tb=TerminalBackend()
    tb.self_healing.stop()
    return tb


def _fresh_tick(tb, symbol, price, token='paper'):
    tb.feed=SimpleNamespace(state=SimpleNamespace(snapshot=lambda: {'connected':True,'age':0.1,'local_sequence':1}))
    tb.ticks[('nse_fo',token)]=SimpleNamespace(trading_symbol=symbol,instrument_token=token,ltp=price,timestamp=time.time())


def test_nifty_never_accepts_banknifty_tick(tmp_path, monkeypatch):
    tb=_backend(tmp_path, monkeypatch)
    _fresh_tick(tb,'BANKNIFTY',123)
    try:
        tb._paper_market_evidence('NIFTY')
        assert False, 'BANKNIFTY must not satisfy NIFTY evidence'
    except RuntimeError as e:
        assert str(e)=='INSTRUMENT_MARKET_DATA_REQUIRED'


def test_paper_mark_rejects_client_prices(tmp_path, monkeypatch):
    tb=_backend(tmp_path, monkeypatch)
    out=tb.paper_mark({'prices':{'NIFTY':999999}})
    assert out['ok'] is False and out['error']=='CLIENT_MARK_PRICES_FORBIDDEN'
    assert tb.paper_daily_pnl == 0.0


def test_paper_mark_uses_trusted_tick(tmp_path, monkeypatch):
    tb=_backend(tmp_path, monkeypatch)
    from paper_execution import PaperExecutionLedger
    tb.paper_ledger=PaperExecutionLedger(tmp_path/'isolated.sqlite3')
    tb.paper_ledger.submit('NIFTY','BUY',75,'MARKET',fill_price=100)
    _fresh_tick(tb,'NIFTY 50',110,'nifty 50')
    out=tb.paper_mark({})
    assert out['ok']
    assert out['trusted_prices']['NIFTY']==110.0
    assert tb.paper_daily_pnl==750.0


def test_self_repair_env_cannot_grant_auto_promotion(tmp_path, monkeypatch):
    monkeypatch.setenv('PAPER_AUTO_SELF_REPAIR','true')
    monkeypatch.setenv('SELF_REPAIR_AUTO_PROMOTE','true')
    from self_repair import CodeSelfRepairEngine
    e=CodeSelfRepairEngine(tmp_path)
    assert e.policy.allow_auto_promote is False
