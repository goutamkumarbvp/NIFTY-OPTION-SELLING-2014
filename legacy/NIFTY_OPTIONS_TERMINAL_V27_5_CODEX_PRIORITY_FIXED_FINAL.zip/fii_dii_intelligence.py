from __future__ import annotations
from math import isfinite
from typing import Any
class FiiDiiIntelligence:
    """Normalizes supplied institutional flow data; never creates flow values."""
    def __init__(self):self.last={'status':'NO_DATA'}
    def analyze(self,rows:list[dict]|None)->dict[str,Any]:
        if rows is None:return self._set({'status':'BLOCKED','reason':'FLOW_DATA_REQUIRED'})
        out=[]
        for r in rows:
            if not isinstance(r,dict):continue
            try:
                fii=float(r.get('fii_net')); dii=float(r.get('dii_net')); dt=str(r.get('date') or '')
                if not all(isfinite(x) for x in (fii,dii)):continue
                out.append({'date':dt,'fii_net':fii,'dii_net':dii,'combined_net':fii+dii})
            except (TypeError,ValueError):continue
        if not out:return self._set({'status':'BLOCKED','reason':'NO_VALID_FLOW_DATA','rows':0})
        fi=sum(x['fii_net'] for x in out); di=sum(x['dii_net'] for x in out)
        bias='BULLISH' if fi+di>0 else 'BEARISH' if fi+di<0 else 'NEUTRAL'
        return self._set({'status':'READY','rows':len(out),'fii_total':fi,'dii_total':di,'combined_total':fi+di,'bias':bias,'latest':out[-1],'series':out,'source':'supplied_fii_dii_data'})
    def _set(self,x):self.last=x;return x
    def health(self):return {'healthy':self.last.get('status')=='READY','last':self.last}
