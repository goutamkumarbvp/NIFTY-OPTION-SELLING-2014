# V3.0 — Risk Brain Release

- Deterministic fail-closed RiskBrain.
- Projected quantity/exposure checks before any paper action.
- Daily-loss, margin-utilization, available-margin and order-side checks.
- Risk snapshot derived from broker positions/limits when authenticated; otherwise only explicitly supplied evidence is accepted.
- Dashboard risk controls call backend APIs.
- Live order placement remains disabled.
- No fabricated market or broker state.

## Gate
RiskBrain can return ALLOW_PAPER or BLOCK. It never places a broker order. A future live Execution Governor must require this gate plus reconciliation, feed freshness, instrument validation, margin evidence and explicit live policy.
