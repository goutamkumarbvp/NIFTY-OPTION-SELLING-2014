# V21.0 Release Notes — Dependency Inversion & Event Isolation

- Added `service_contracts.py` with explicit dependency bundles.
- Added `composition.py` as the concrete implementation composition root.
- Added `event_bus.py` for isolated in-process events.
- Refactored Market, Intelligence, Research and AI services to receive injected dependencies.
- Removed concrete domain/infrastructure imports from application services.
- Kept server as HTTP transport boundary.
- Added architecture contract tests and event failure-isolation test.
- Fixed V18 self-repair `Path`/root resolution defect exposed during deep integration audit.
- Preserved paper-only/read-only execution safety.
- Full test suite: **294/294 PASS**.
