from __future__ import annotations
from datetime import datetime, timezone
from typing import Any


def _num(v):
    try: return None if v in (None, "") else float(v)
    except (TypeError, ValueError): return None

def _int(v):
    n=_num(v); return None if n is None else int(n)

def _get(d,*keys,default=None):
    for k in keys:
        if k in d and d[k] is not None: return d[k]
    return default

def _flatten(payload:Any)->list[dict]:
    if payload is None: return []
    if isinstance(payload,list):
        out=[]
        for x in payload: out.extend(_flatten(x))
        return out
    if not isinstance(payload,dict): return []
    if any(k in payload for k in ('strike_price','strikePrice','strike','dStrikePrice','option_type','optionType')):
        return [payload]
    out=[]
    for key in ('data','result','records','option_chain','optionChain','options','chain'):
        if key in payload: out.extend(_flatten(payload[key]))
    return out

def normalize_option_chain(payload:Any)->list[dict]:
    final=[]
    for d in _flatten(payload):
        strike=_num(_get(d,'strike_price','strikePrice','strike','dStrikePrice'))
        if strike is None: continue
        typ=str(_get(d,'option_type','optionType','optionTypeCode','cp','type',default='')).upper()
        candidates=[] if typ not in {'CE','PE'} else [(typ,d)]
        if not candidates:
            for side in ('CE','PE'):
                if isinstance(d.get(side),dict): candidates.append((side,{**d[side], 'strike':strike}))
        for side,x in candidates:
            oi=_int(_get(x,'open_interest','openInterest','oi'))
            volume=_int(_get(x,'volume','vol'))
            # OI and volume are counts and cannot be negative. Reject the affected
            # contract at the normalization boundary so downstream PCR/liquidity
            # calculations can never consume impossible market evidence.
            if oi is not None and oi < 0: continue
            if volume is not None and volume < 0: continue
            final.append({'strike':strike,'expiry':_get(x,'expiry','expiry_date','expiryDate'),
              'option_type':side,'instrument_token':str(_get(x,'instrument_token','instrumentToken','token',default='')),
              'trading_symbol':_get(x,'trading_symbol','tradingSymbol','symbol'),
              'ltp':_num(_get(x,'last_traded_price','lastTradedPrice','ltp','LTP')),
              'bid':_num(_get(x,'best_bid_price','bestBidPrice','bid_price','bidPrice','bid')),
              'ask':_num(_get(x,'best_ask_price','bestAskPrice','ask_price','askPrice','ask')),
              'oi':oi,
              'doi':_int(_get(x,'change_in_oi','changeInOi','changeInOI','doi','oi_change')),
              'volume':volume,
              'iv':_num(_get(x,'implied_volatility','impliedVolatility','iv'))})
    return final

def build_chain(payload:Any)->list[dict]:
    # Contract identity must include expiry; strike alone collides across weekly/monthly series.
    by={}
    for c in normalize_option_chain(payload):
        expiry=c.get('expiry')
        key=(str(expiry or ''), c['strike'])
        row=by.setdefault(key,{'strike':c['strike'],'expiry':expiry,'ce':None,'pe':None})
        side='ce' if c['option_type']=='CE' else 'pe'
        # Keep the first complete contract for a side; duplicate feeds must not silently overwrite.
        if row[side] is None:
            row[side]=c
    return [by[k] for k in sorted(by, key=lambda x:(x[0],x[1]))]

def chain_metrics(chain:list[dict])->dict:
    ce_oi=sum((r.get('ce') or {}).get('oi') or 0 for r in chain); pe_oi=sum((r.get('pe') or {}).get('oi') or 0 for r in chain)
    ce_doi=sum((r.get('ce') or {}).get('doi') or 0 for r in chain); pe_doi=sum((r.get('pe') or {}).get('doi') or 0 for r in chain)
    return {'call_oi':ce_oi,'put_oi':pe_oi,'pcr_oi':pe_oi/ce_oi if ce_oi else None,
            'call_doi':ce_doi,'put_doi':pe_doi,
            # User-defined ΔOI PCR: total PE change in OI divided by total CE change in OI.
            # A negative denominator is mathematically valid; only zero is undefined.
            'pcr_doi':pe_doi/ce_doi if ce_doi != 0 else None,
            'pcr_change_oi':pe_doi/ce_doi if ce_doi != 0 else None,
            'contracts':len(chain),'feedable_tokens':sum(1 for r in chain for s in ('ce','pe') if (r.get(s) or {}).get('instrument_token')),
            'updated_at':datetime.now(timezone.utc).isoformat(),'source':'kotak_neo'}

def chain_feed_tokens(chain:list[dict],segment='nse_fo')->list[dict]:
    out=[]; seen=set()
    for row in chain:
        for side in ('ce','pe'):
            leg=row.get(side) or {}; token=str(leg.get('instrument_token') or '')
            if token and (segment,token) not in seen:
                seen.add((segment,token)); out.append({'exchange_segment':segment,'instrument_token':token})
    return out
