import os, tempfile, json, threading
from pass11_engine import *
from market_data_v10 import OptionChainSQLiteStore

def snaps(n=100):
 return [{'timestamp':f'2026-09-15T09:{15+i//60:02d}:{i%60:02d}+05:30','spot':25000+i,'expiry':'2026-09-24','contracts':[{'symbol':f'NIFTY{i}CE','instrument_token':str(i),'exchange_segment':'nse_fo','underlying':'NIFTY','expiry':'2026-09-24','strike':25000,'option_type':'CE','bid':100+i*.01,'ask':101+i*.01,'oi':1000,'volume':100,'lot_size':75,'tick_size':0.05}]} for i in range(n)]

def test_registry_content_addressed():
 with tempfile.TemporaryDirectory() as d:
  r=DatasetVersionRegistry(os.path.join(d,'r.db')); p=[{'x':1}]
  a=r.register('n',p); b=r.register('n',p); assert a['version']==b['version'] and b['existing']

def test_registry_changes_version():
 with tempfile.TemporaryDirectory() as d:
  r=DatasetVersionRegistry(os.path.join(d,'r.db')); a=r.register('n',[1]); b=r.register('n',[2]); assert a['version']!=b['version']

def test_registry_list():
 with tempfile.TemporaryDirectory() as d:
  r=DatasetVersionRegistry(os.path.join(d,'r.db')); r.register('n',[1]); assert len(r.list_versions('n')['versions'])==1

def test_series_groups_expiry():
 c=[{'expiry':'2026-09-24','strike':25000,'option_type':'CE'},{'expiry':'2026-10-01','strike':25000,'option_type':'PE'}]
 r=ContractSeriesManager().series(c); assert r['expiries']==['2026-09-24','2026-10-01']

def test_series_select_unknown_blocks(): assert ContractSeriesManager().select([{'expiry':'2026-09-24','strike':1,'option_type':'CE'}],'2026-10-01')['status']=='BLOCKED'

def test_query_layer():
 with tempfile.TemporaryDirectory() as d:
  db=os.path.join(d,'x.db'); st=OptionChainSQLiteStore(db); ss=snaps(3); assert st.ingest('d',ss)['status']=='READY'; q=HistoricalQueryLayer(db); assert len(q.datasets()['datasets'])==1; assert len(q.snapshots('d')['snapshots'])==3; assert len(q.contracts('d',expiry='2026-09-24')['contracts'])==3

def test_quality_ready(): assert DataQualityScorer().score(snaps(3))['status']=='READY'

def test_quality_degraded():
 s=snaps(3); s[1]['contracts'][0]['ask']=99; r=DataQualityScorer().score(s); assert r['status']=='DEGRADED' and r['issue_count']>0

def test_replay_no_lookahead():
 r=HighSpeedReplayEngine().replay(snaps(4),signal_indices=[0,2]); assert r['status']=='READY' and r['events']==2 and r['first_event']['fill_index']==1 and r['last_event']['fill_index']==3

def test_replay_out_of_range(): assert HighSpeedReplayEngine().replay(snaps(3),[2])['status']=='BLOCKED'

def test_replay_nonmonotonic_blocks():
 s=snaps(3); s[2]['timestamp']=s[1]['timestamp']; assert HighSpeedReplayEngine().replay(s)['reason']=='NON_MONOTONIC_TIMESTAMP'

def test_replay_soak():
 r=HighSpeedReplayEngine().soak(snaps(50),passes=3); assert r['status']=='READY' and r['events']==147

def test_event_limit(): assert HighSpeedReplayEngine().replay(snaps(3),max_events=1)['reason']=='EVENT_LIMIT_EXCEEDED'

def test_server_health_and_routes():
 import server
 assert server.TerminalBackend().state()['api_schema_version']=='v12.0'
