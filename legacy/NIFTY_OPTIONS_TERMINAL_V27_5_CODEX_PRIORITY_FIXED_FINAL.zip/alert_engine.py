from __future__ import annotations
import json, os, threading, time, urllib.parse, urllib.request, uuid
from collections import deque
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable

@dataclass(frozen=True)
class Alert:
    alert_id: str
    kind: str
    severity: str
    title: str
    message: str
    created_at: float
    dedupe_key: str
    delivered: dict[str, bool]

class AlertManager:
    """Fail-safe multi-channel alerting. Alerts never place/cancel/modify orders."""
    SEVERITY = {"INFO":1,"WARNING":2,"CRITICAL":3,"EMERGENCY":4}
    def __init__(self, path: str|Path, env: dict[str,str]|None=None, sender: Callable[[str,Alert],bool]|None=None):
        self.env = env or os.environ
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock(); self.items:list[Alert]=[]; self.sender=sender
        self.cooldown=float(self.env.get("ALERT_COOLDOWN_SECONDS","300") or 300)
        self.big_move=float(self.env.get("ALERT_BIG_MOVE_PCT","1.0") or 1.0)
        self.black_swan=float(self.env.get("ALERT_BLACK_SWAN_MOVE_PCT","2.0") or 2.0)
        self.stale_seconds=float(self.env.get("ALERT_FEED_STALE_SECONDS","5") or 5)
        self.min_severity=str(self.env.get("ALERT_MIN_SEVERITY","INFO")).upper()
        self.move_window=float(self.env.get("ALERT_MOVE_WINDOW_SECONDS","300") or 300)
        self._prices=deque(maxlen=10000)
        self.telegram_enabled=bool(self.env.get("TELEGRAM_BOT_TOKEN") and self.env.get("TELEGRAM_CHAT_ID"))
        self.twilio_enabled=bool(self.env.get("TWILIO_ACCOUNT_SID") and self.env.get("TWILIO_AUTH_TOKEN"))
        self.sms_enabled=bool(self.twilio_enabled and self.env.get("TWILIO_SMS_FROM") and self.env.get("ALERT_SMS_TO"))
        self.whatsapp_enabled=bool(self.twilio_enabled and self.env.get("TWILIO_WHATSAPP_FROM") and self.env.get("ALERT_WHATSAPP_TO"))
        self.email_enabled=False
        self._load()
    def _load(self):
        if not self.path.exists(): return
        try:
            rows=json.loads(self.path.read_text(encoding='utf-8'))
            if isinstance(rows,list):
                for x in rows[-500:]:
                    self.items.append(Alert(**x))
        except Exception:
            self.items=[]
    def _persist(self):
        tmp=self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps([asdict(x) for x in self.items[-500:]],sort_keys=True),encoding='utf-8')
        with tmp.open('rb') as f: os.fsync(f.fileno())
        os.replace(tmp,self.path)
    def _allowed(self,severity):
        return self.SEVERITY.get(severity,2)>=self.SEVERITY.get(self.min_severity,1)
    def _recent_duplicate(self,key,now):
        return any(x.dedupe_key==key and now-x.created_at<self.cooldown for x in reversed(self.items[-200:]))
    def emit(self, kind:str, severity:str, title:str, message:str, dedupe_key:str|None=None, force:bool=False)->dict[str,Any]:
        severity=str(severity).upper(); now=time.time(); key=dedupe_key or f"{kind}:{title}"
        with self.lock:
            if not self._allowed(severity): return {"emitted":False,"suppressed":"severity_filter"}
            if not force and self._recent_duplicate(key,now): return {"emitted":False,"suppressed":"dedupe"}
            a=Alert(str(uuid.uuid4()),str(kind).upper(),severity,str(title),str(message),now,key,{})
            delivered={}
            if self.sender:
                try: delivered['custom']=bool(self.sender('custom',a))
                except Exception: delivered['custom']=False
            if self.telegram_enabled:
                delivered['telegram']=self._telegram(a)
            if self.sms_enabled:
                delivered['sms']=self._twilio_message(a, self.env.get('TWILIO_SMS_FROM',''), self.env.get('ALERT_SMS_TO',''))
            if self.whatsapp_enabled:
                delivered['whatsapp']=self._twilio_message(a, self.env.get('TWILIO_WHATSAPP_FROM',''), self.env.get('ALERT_WHATSAPP_TO',''))
            a=Alert(a.alert_id,a.kind,a.severity,a.title,a.message,a.created_at,a.dedupe_key,delivered)
            self.items.append(a); self.items=self.items[-500:]; self._persist()
            return {"emitted":True,"alert":asdict(a)}
    def _twilio_message(self,a:Alert, sender:str, recipient:str)->bool:
        """Send SMS/WhatsApp through Twilio Programmable Messaging."""
        sid=str(self.env.get('TWILIO_ACCOUNT_SID','')).strip()
        token=str(self.env.get('TWILIO_AUTH_TOKEN','')).strip()
        sender=str(sender).strip(); recipient=str(recipient).strip()
        if not sid or not token or not sender or not recipient:
            return False
        text=f"[{a.severity}] {a.title}\n{a.message}\nTime: {time.strftime('%Y-%m-%d %H:%M:%S %Z',time.localtime(a.created_at))}"
        url=f"https://api.twilio.com/2010-04-01/Accounts/{urllib.parse.quote(sid, safe='')}/Messages.json"
        data=urllib.parse.urlencode({'To':recipient,'From':sender,'Body':text}).encode()
        auth=urllib.parse.quote(sid, safe='')+':'+urllib.parse.quote(token, safe='')
        import base64
        headers={'Content-Type':'application/x-www-form-urlencoded','Authorization':'Basic '+base64.b64encode(auth.encode()).decode()}
        # External alert delivery must never block the trading/risk path.
        # DNS resolution can outlive urllib's socket timeout, so execute the
        # whole network operation on a daemon worker and bound the caller wait.
        result = {'ok': False}
        done = threading.Event()
        def _send():
            try:
                req=urllib.request.Request(url,data=data,headers=headers,method='POST')
                with urllib.request.urlopen(req,timeout=7) as r:
                    result['ok'] = 200 <= r.status < 300
            except Exception:
                result['ok'] = False
            finally:
                done.set()
        threading.Thread(target=_send, name='alert-twilio-delivery', daemon=True).start()
        done.wait(timeout=float(self.env.get('ALERT_DELIVERY_WAIT_SECONDS','0.25') or 0.25))
        return bool(result['ok'])

    def _telegram(self,a:Alert)->bool:
        token=str(self.env.get('TELEGRAM_BOT_TOKEN','')).strip(); chat=str(self.env.get('TELEGRAM_CHAT_ID','')).strip()
        if not token or not chat:return False
        text=f"[{a.severity}] {a.title}\n{a.message}\nTime: {time.strftime('%Y-%m-%d %H:%M:%S %Z',time.localtime(a.created_at))}"
        url=f"https://api.telegram.org/bot{token}/sendMessage"
        data=urllib.parse.urlencode({'chat_id':chat,'text':text,'disable_web_page_preview':'true'}).encode()
        result = {'ok': False}
        done = threading.Event()
        def _send():
            try:
                req=urllib.request.Request(url,data=data,headers={'Content-Type':'application/x-www-form-urlencoded'},method='POST')
                with urllib.request.urlopen(req,timeout=5) as r:
                    result['ok'] = 200 <= r.status < 300
            except Exception:
                result['ok'] = False
            finally:
                done.set()
        threading.Thread(target=_send, name='alert-telegram-delivery', daemon=True).start()
        done.wait(timeout=float(self.env.get('ALERT_DELIVERY_WAIT_SECONDS','0.25') or 0.25))
        return bool(result['ok'])
    def recent(self,limit:int=50)->list[dict[str,Any]]:
        with self.lock:return [asdict(x) for x in self.items[-max(1,min(int(limit),200)):]][::-1]
    def evaluate_market(self, spot:float|None, previous_spot:float|None, feed_age:float|None, connected:bool, trace='market')->list[dict[str,Any]]:
        out=[]; now=time.time()
        if connected and feed_age is not None and feed_age>self.stale_seconds:
            out.append(self.emit('FEED_STALE','CRITICAL','Live feed stale',f'Kotak SFeed has been stale for {feed_age:.1f}s.',f'feed-stale:{trace}'))
        if not connected and previous_spot is not None:
            out.append(self.emit('BROKER_DISCONNECTED','CRITICAL','Kotak/SFeed disconnected','Live market connection is not healthy.',f'feed-disconnect:{trace}'))
        if spot is not None:
            self._prices.append((now,float(spot)))
            cutoff=now-self.move_window
            while self._prices and self._prices[0][0]<cutoff:self._prices.popleft()
            base=self._prices[0][1] if self._prices else previous_spot
            if base not in (None,0):
                move=(float(spot)-float(base))/float(base)*100.0
                if abs(move)>=self.black_swan:
                    out.append(self.emit('BLACK_SWAN','EMERGENCY','BLACK SWAN / EXTREME MOVE',f'NIFTY moved {move:+.2f}% within about {int(self.move_window)}s.',f'black-swan:{trace}:{int(now//self.move_window)}'))
                elif abs(move)>=self.big_move:
                    out.append(self.emit('BIG_MOVE','CRITICAL','Large NIFTY movement',f'NIFTY moved {move:+.2f}% within about {int(self.move_window)}s.',f'big-move:{trace}:{int(now//self.move_window)}'))
        return out

    def evaluate_risk(self, decision:dict[str,Any]|None, daily_pnl:float|None=None, stop_loss:float|None=None, trade_pnl:float|None=None, trade_stop_loss:float|None=None)->list[dict[str,Any]]:
        out=[]
        if daily_pnl is not None and stop_loss is not None and float(daily_pnl)<=-abs(float(stop_loss)):
            out.append(self.emit('STOP_LOSS','CRITICAL','STOP LOSS HIT',f'Daily P&L {float(daily_pnl):.2f} reached configured stop-loss {abs(float(stop_loss)):.2f}.','stop-loss:daily'))
        if trade_pnl is not None and trade_stop_loss is not None and float(trade_pnl)<=-abs(float(trade_stop_loss)):
            out.append(self.emit('STOP_LOSS','CRITICAL','TRADE STOP LOSS HIT',f'Trade P&L {float(trade_pnl):.2f} reached configured trade stop-loss {abs(float(trade_stop_loss)):.2f}.','stop-loss:trade'))
        if decision and str(decision.get('decision','')).upper()=='BLOCK':
            out.append(self.emit('RISK_BLOCK','WARNING','Risk gate blocked trade','Risk Brain rejected the proposed trade.','risk-block'))
        return out
    def new_trade(self, plan:dict[str,Any]|None, trace='strategy')->list[dict[str,Any]]:
        if not plan:return []
        c=plan.get('candidates') or []
        if c:
            top=c[0] if isinstance(c[0],dict) else {'type':str(c[0])}
            label=top.get('type','TRADE')
            score=top.get('score')
            msg=f"New paper-trade candidate available: {label}" + (f" | score={score}" if score is not None else '')
            return [self.emit('NEW_TRADE','INFO','NEW TRADE CANDIDATE',msg,f'new-trade:{trace}')]
        return []
    def undesirable(self,kind,title,message,dedupe_key=None,severity='CRITICAL'):
        return self.emit(kind,severity,title,message,dedupe_key)
