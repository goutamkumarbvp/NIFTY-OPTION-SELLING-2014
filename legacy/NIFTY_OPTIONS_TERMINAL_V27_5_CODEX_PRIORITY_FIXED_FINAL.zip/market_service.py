from __future__ import annotations

import os
import time
from datetime import datetime, timezone
from service_contracts import MarketDependencies

class Market:
    """Application service boundary. Trading components are reached only through the injected context."""
    def __init__(self, ctx, deps: MarketDependencies):
        self.ctx = ctx; self.deps = deps
        # Broker/market-owned state and adapters live behind this service boundary.
        c = ctx; root = c.ROOT
        c.adapter=None; c.feed=None; c.feed_supervisor=None; c.authenticated=False
        c.ticks={}; c.chain=[]; c.chain_stats={}; c.pcr_history=[]; c.last_chain=0.; c.last_refresh=0.
        c.feed_tokens=[]; c.last_expiries=None; c.last_expiry=None; c.broker_positions=[]; c.local_positions=[]
        c.reconciliation={'matched':True,'broker_positions':0,'local_positions':0,'mismatches':[]}; c.last_soak=None
        c.v14_manager=None; c.v14_last=None; c.v15_resolver=None; c.v15_planner=deps.subscription_planner(); c.v15_monitor=None
        c.v15_underlying=None; c.v15_chain=None; c.v15_last=None; c.feed_auto_enabled=False

    def _adapter_from_env(self,b=None):
        # Pass 14 canonical configuration uses NEO_* names and hard-blocks live trading.
        cfg=self.deps.config_cls.from_env(os.environ); cfg.validate()
        self.ctx.v14_manager=self.deps.manager_cls(cfg)
        self.ctx.v14_manager.load()
        # Legacy market adapter remains available for compatibility, but no order method is exposed by it.
        return self.deps.adapter_cls(self.deps.adapter_config_cls(cfg.consumer_key,cfg.environment,cfg.mobile_number,cfg.ucc))

    def authenticate(self,b=None):
        # Never accept MPIN from an HTTP request. Credentials stay in local environment.
        try:
            if not self.ctx.v14_manager:
                cfg=self.deps.config_cls.from_env(os.environ); cfg.validate(); self.ctx.v14_manager=self.deps.manager_cls(cfg)
            r=self.ctx.v14_manager.authenticate(str(b.get('totp','')).strip() or None)
            cfg=self.ctx.v14_manager.config
            self.ctx.adapter=self.deps.adapter_cls(self.deps.adapter_config_cls(cfg.consumer_key,cfg.environment,cfg.mobile_number,cfg.ucc))
            self.ctx.adapter.client=self.ctx.v14_manager.client
            self.ctx.adapter.authenticated=True
            self.ctx.authenticated=True; self.ctx.v14_last={'status':'AUTHENTICATED','result':r}
            return {'ok':True,'broker':'Kotak Neo','authenticated':True,'result':r,'paper_only':True,'live_orders_enabled':False,'state':self.ctx.state(),'action':self.ctx._log('BROKER_AUTHENTICATE')}
        except Exception as e:
            self.ctx.authenticated=False; self.ctx.last_error=str(e); return {'ok':False,'error':str(e),'paper_only':True,'live_orders_enabled':False,'state':self.ctx.state(),'action':self.ctx._log('BROKER_AUTHENTICATE','FAILED',{'error':str(e)})}

    def v15_discover(self,b=None):
        try:
            self.ctx._require()
            self.ctx.v15_resolver=self.deps.token_resolver(self.ctx.adapter)
            ref=self.ctx.v15_resolver.resolve()
            self.ctx.v15_underlying={'exchange_segment':ref.exchange_segment,'instrument_token':ref.instrument_token,'trading_symbol':ref.trading_symbol,'underlying':'NIFTY'}
            return {'ok':True,'data':self.ctx.v15_underlying,'source':'kotak_neo','live_orders_enabled':False,'action':self.ctx._log('V15_DISCOVER_NIFTY','OK',self.ctx.v15_underlying),'state':self.ctx.state()}
        except Exception as e:return self.ctx._fail('V15_DISCOVER_NIFTY',e)

    def v15_chain_auto(self,b=None):
        try:
            self.ctx._require()
            if not self.ctx.v15_underlying:
                self.ctx.v15_discover()
            token=self.ctx.v15_underlying['instrument_token']
            exps=self.ctx.adapter.expiries(exchange_segment='nse_fo',instrument_token=token)
            refs=[]
            for d in self.deps.response_extractor.walk(exps):
                for k in ('expiry','expiry_date','expiryDate'):
                    if d.get(k): refs.append(str(d[k])[:10])
            refs=sorted(set(x for x in refs if len(x)==10 and x[4]=='-' and x[7]=='-'))
            requested=str((b or {}).get('expiry','')).strip()
            expiry=requested or (refs[0] if refs else '')
            if not expiry: raise self.deps.pass15_error('NO_NIFTY_EXPIRY_RETURNED_BY_KOTAK')
            raw=self.ctx.adapter.option_chain(exchange_segment='nse_fo',instrument_token=token,expiry=expiry)
            contracts=self.deps.response_extractor.option_contracts(raw)
            if not contracts: raise self.deps.pass15_error('NO_NIFTY_OPTION_CONTRACTS_RETURNED_BY_KOTAK')
            self.ctx.v15_chain={'expiry':expiry,'contracts':contracts,'contract_count':len(contracts),'available_expiries':refs[:50]}
            # Promote broker-returned market fields into the canonical chain pipeline so
            # CE/PE ΔOI and both PCR series are monitored when Kotak provides them.
            derived_chain=self.deps.build_chain(contracts)
            if derived_chain:
                stats=self.deps.chain_metrics(derived_chain)
                self.ctx.chain=derived_chain; self.ctx.chain_stats=stats; self.ctx._record_pcr_snapshot(stats); self.ctx.last_chain=time.time(); self.ctx.last_expiry=expiry
            self.ctx.feed_tokens=self.ctx.v15_planner.plan(contracts)
            return {'ok':True,'data':self.ctx.v15_chain,'feed_tokens':len(self.ctx.feed_tokens),'state':self.ctx.state(),'action':self.ctx._log('V15_AUTO_OPTION_CHAIN','OK',{'expiry':expiry,'contracts':len(contracts),'feed_tokens':len(self.ctx.feed_tokens)})}
        except Exception as e:return self.ctx._fail('V15_AUTO_OPTION_CHAIN',e)

    def v15_feed_soak_status(self,b=None):
        try:
            data=self.ctx.v15_monitor.snapshot() if self.ctx.v15_monitor else {'status':'NOT_STARTED','messages':0,'unique_tokens':0}
            return {'ok':True,'data':data,'paper_only':True,'live_orders_enabled':False,'state':self.ctx.state()}
        except Exception as e:return self.ctx._fail('V15_FEED_SOAK_STATUS',e)

    def v15_prepare_feed(self,b=None):
        try:
            self.ctx._require()
            if not self.ctx.feed_tokens:
                self.ctx.v15_chain_auto(b or {})
            if not self.ctx.feed_tokens: raise self.deps.pass15_error('NO_FEED_TOKENS')
            self.ctx.v15_monitor=self.deps.tick_soak_monitor()
            # Replace callback with quality monitor while retaining canonical latest-tick state.
            if self.ctx.feed_supervisor and self.ctx.feed_supervisor.thread and self.ctx.feed_supervisor.thread.is_alive():
                self.ctx.stop_feed()
            def on_tick(t):
                self.ctx.v15_monitor.observe(t)
                with self.ctx.lock:self.ctx.ticks[(t.exchange_segment,t.instrument_token)]=t
            def on_status(status):
                with self.ctx.lock:
                    if self.ctx.feed:self.ctx.feed.state.market_status=status
            self.ctx.feed=self.deps.sfeed_cls(self.ctx.v14_manager.client,on_tick,on_status)
            self.ctx.feed_supervisor=self.deps.feed_supervisor_cls(self.ctx.feed)
            self.ctx.feed_supervisor.start(self.ctx.feed_tokens)
            return {'ok':True,'data':{'status':'STARTED','tokens':len(self.ctx.feed_tokens),'max_tokens':3000},'state':self.ctx.state(),'action':self.ctx._log('V15_PREPARE_SFEED','OK',{'tokens':len(self.ctx.feed_tokens)})}
        except Exception as e:return self.ctx._fail('V15_PREPARE_SFEED',e)

    def v14_config_status(self,b=None):
        try:
            cfg=self.deps.config_cls.from_env(os.environ)
            self.ctx.v14_last={'status':'CONFIG_VALID','environment':cfg.environment,'live_trading':False,'credentials_present':bool(cfg.consumer_key and cfg.mobile_number and cfg.ucc and cfg.mpin),'redacted':self.deps.redacted_env(os.environ)}
            return {'ok':True,'data':self.ctx.v14_last,'state':self.ctx.state(),'action':self.ctx._log('V14_CONFIG_STATUS','OK',{'live_trading':False})}
        except Exception as e: return self.ctx._fail('V14_CONFIG_STATUS',e)

    def v14_status(self,b=None):
        try:
            st=self.ctx.v14_manager.state.snapshot() if self.ctx.v14_manager else {'authenticated':False,'feed_connected':False,'feed_fresh':False,'live_orders_enabled':False}
            r={'status':'READY' if st.get('authenticated') else 'NOT_AUTHENTICATED','connection':st,'paper_only':True,'live_orders_enabled':False}
            self.ctx.v14_last=r
            return {'ok':True,'data':r,'state':self.ctx.state(),'action':self.ctx._log('V14_STATUS','OK',r)}
        except Exception as e:return self.ctx._fail('V14_STATUS',e)

    def v14_read(self,b=None):
        try:
            if not self.ctx.v14_manager: raise RuntimeError('V14_NOT_INITIALIZED')
            what=str((b or {}).get('what','')).lower()
            if what=='positions': r=self.ctx.v14_manager.read_positions()
            elif what=='holdings': r=self.ctx.v14_manager.read_holdings()
            elif what=='limits': r=self.ctx.v14_manager.read_limits()
            elif what=='expiries': r=self.ctx.v14_manager.read_expiries(exchange_segment=(b or {}).get('exchange_segment','nse_fo'),instrument_token=(b or {}).get('instrument_token'))
            elif what=='option_chain': r=self.ctx.v14_manager.read_option_chain(exchange_segment=(b or {}).get('exchange_segment','nse_fo'),instrument_token=(b or {}).get('instrument_token'),expiry=(b or {}).get('expiry'))
            elif what=='quotes': r=self.ctx.v14_manager.read_quotes(instrument_tokens=(b or {}).get('instrument_tokens',[]))
            else: raise ValueError('READ_ONLY_TARGET_REQUIRED')
            self.ctx.v14_last={'status':'READY','what':what,'data':r,'live_orders_enabled':False}
            return {'ok':True,'data':self.ctx.v14_last,'state':self.ctx.state(),'action':self.ctx._log('V14_READ_'+what.upper(),'OK')}
        except Exception as e:return self.ctx._fail('V14_READ',e)

    def load_expiries(self,b=None):
        try:
            self.ctx._require(); r=self.ctx.adapter.expiries(b.get('exchange_segment','nse_fo'),b.get('instrument_token')); self.ctx.last_expiries=r; return {'ok':True,'data':r,'state':self.ctx.state(),'action':self.ctx._log('FETCH_EXPIRIES')}
        except Exception as e:return self.ctx._fail('FETCH_EXPIRIES',e)

    def load_option_chain(self,b=None):
        try:
            self.ctx._require(); token=b.get('instrument_token'); expiry=b.get('expiry')
            if not token: raise ValueError('UNDERLYING_INSTRUMENT_TOKEN_REQUIRED')
            if not expiry: raise ValueError('EXPIRY_REQUIRED')
            raw=self.ctx.adapter.option_chain(b.get('exchange_segment','nse_fo'),token,expiry); chain=self.deps.build_chain(raw)
            if not chain: raise ValueError('EMPTY_OPTION_CHAIN')
            stats=self.deps.chain_metrics(chain); self.ctx.chain=chain; self.ctx.chain_stats=stats; self.ctx._record_pcr_snapshot(stats); self.ctx.last_chain=time.time(); self.ctx.last_expiry=expiry
            # Automatically prepare all CE/PE contracts for SFeed; actual subscription remains explicit.
            self.ctx.feed_tokens= [(x['exchange_segment'],x['instrument_token']) for x in self.deps.chain_feed_tokens(chain,b.get('exchange_segment','nse_fo'))]
            return {'ok':True,'chain':chain,'metrics':stats,'feed_tokens':len(self.ctx.feed_tokens),'source':'kotak_neo','state':self.ctx.state(),'action':self.ctx._log('FETCH_LIVE_OPTION_CHAIN',detail={'contracts':len(chain),'feed_tokens':len(self.ctx.feed_tokens)})}
        except Exception as e:return self.ctx._fail('FETCH_LIVE_OPTION_CHAIN',e)

    def start_feed(self,b=None):
        try:
            self.ctx._require(); raw=b.get('tokens') or [{'exchange_segment':a,'instrument_token':c} for a,c in self.ctx.feed_tokens]
            tokens=[]; seen=set()
            for x in raw:
                if isinstance(x,dict) and x.get('exchange_segment') and x.get('instrument_token'):
                    p=(str(x['exchange_segment']),str(x['instrument_token']))
                    if p not in seen: seen.add(p); tokens.append(p)
            if not tokens: raise ValueError('FEED_TOKENS_REQUIRED')
            if len(tokens)>3000: raise ValueError('SFEED_SUBSCRIPTION_LIMIT_EXCEEDED:3000')
            if self.ctx.feed_supervisor and self.ctx.feed_supervisor.thread and self.ctx.feed_supervisor.thread.is_alive(): raise RuntimeError('FEED_ALREADY_RUNNING')
            def on_tick(t:NormalizedTick):
                with self.ctx.lock:self.ctx.ticks[(t.exchange_segment,t.instrument_token)]=t
            def on_status(s):
                with self.ctx.lock:
                    if self.ctx.feed:self.ctx.feed.state.market_status=s
            self.ctx.feed_tokens=tokens; self.ctx.feed_auto_enabled=True; self.ctx.feed=self.deps.sfeed_cls(self.ctx.adapter.client,on_tick,on_status); self.ctx.feed_supervisor=self.deps.feed_supervisor_cls(self.ctx.feed); self.ctx.feed_supervisor.start(tokens)
            return {'ok':True,'state':self.ctx.state(),'action':self.ctx._log('START_LIVE_SFEED',detail={'tokens':len(tokens)})}
        except Exception as e:return self.ctx._fail('START_LIVE_SFEED',e)

    def stop_feed(self,b=None):
        try:
            self.ctx.feed_auto_enabled=False
            if self.ctx.feed_supervisor:self.ctx.feed_supervisor.stop()
            return {'ok':True,'state':self.ctx.state(),'action':self.ctx._log('STOP_LIVE_SFEED')}
        except Exception as e:return self.ctx._fail('STOP_LIVE_SFEED',e)

    def reconnect_feed(self,b=None):
        if not self.ctx.feed_tokens:return {'ok':False,'error':'NO_PREVIOUS_FEED_SUBSCRIPTION','state':self.ctx.state()}
        self.ctx.stop_feed(); return self.ctx.start_feed({})

    def read_positions(self,b=None):
        try:
            self.ctx._require(); raw=self.ctx.adapter.positions(); self.ctx.broker_positions=raw; self.ctx.reconciliation=self.deps.reconcile(raw, self.ctx.local_positions);
            if not self.ctx.reconciliation['matched']:
                self.ctx.mode='EMERGENCY'; self.ctx.alerts.emit('RECONCILIATION_MISMATCH','EMERGENCY','BROKER/LOCAL POSITION MISMATCH','Broker positions differ from the local ledger; system entered emergency mode.','reconciliation-mismatch')
            return {'ok':True,'data':raw,'reconciliation':self.ctx.reconciliation,'state':self.ctx.state(),'action':self.ctx._log('READ_BROKER_POSITIONS',detail={'matched':self.ctx.reconciliation['matched']})}
        except Exception as e:return self.ctx._fail('READ_BROKER_POSITIONS',e)

    def read_holdings(self,b=None):
        try:
            self.ctx._require(); raw=self.ctx.adapter.holdings(); return {'ok':True,'data':raw,'state':self.ctx.state(),'action':self.ctx._log('READ_BROKER_HOLDINGS')}
        except Exception as e:return self.ctx._fail('READ_BROKER_HOLDINGS',e)

    def quote(self,b=None):
        try:
            self.ctx._require(); tokens=b.get('instrument_tokens');
            if not isinstance(tokens,list) or not tokens: raise ValueError('INSTRUMENT_TOKENS_REQUIRED')
            return {'ok':True,'data':self.ctx.adapter.quotes(tokens),'source':'kotak_neo','state':self.ctx.state(),'action':self.ctx._log('FETCH_LIVE_QUOTES',detail={'count':len(tokens)})}
        except Exception as e:return self.ctx._fail('FETCH_LIVE_QUOTES',e)

    def run_soak(self,b=None):
        from soak import run_soak
        seconds=min(max(int(b.get('duration_seconds',10)),1),3600); interval=min(max(float(b.get('interval_seconds',1)),0.2),60)
        self.ctx.last_soak=run_soak(self.ctx.state,seconds,interval); return {'ok':bool(self.ctx.last_soak['pass']),'soak':self.ctx.last_soak,'state':self.ctx.state(),'action':self.ctx._log('RUN_FEED_SOAK', 'OK' if self.ctx.last_soak['pass'] else 'FAILED', {'samples':self.ctx.last_soak['samples']})}
