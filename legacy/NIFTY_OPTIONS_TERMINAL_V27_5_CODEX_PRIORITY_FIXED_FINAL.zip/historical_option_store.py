from __future__ import annotations
import hashlib,json,os,re,threading
from pathlib import Path
from research_data import HistoricalOptionChainValidator

class HistoricalOptionChainStore:
    """Immutable JSONL store for normalized option-chain snapshots."""
    def __init__(self, root='runtime/option_chain_data'):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True); self.lock=threading.RLock()
    @staticmethod
    def _name(dataset):
        n=re.sub(r'[^A-Za-z0-9_-]','',str(dataset)); return n or 'dataset'
    def ingest(self,dataset,snapshots,metadata=None):
        chk=HistoricalOptionChainValidator.validate(snapshots)
        if chk['status']!='READY': return chk
        name=self._name(dataset); path=self.root/(name+'.jsonl')
        with self.lock:
            if path.exists(): return {'status':'BLOCKED','reason':'DATASET_EXISTS','path':str(path)}
            tmp=path.with_suffix('.tmp')
            with tmp.open('w',encoding='utf-8') as f:
                for s in snapshots:f.write(json.dumps(s,separators=(',',':'),sort_keys=True)+'\n')
                f.flush(); os.fsync(f.fileno())
            tmp.replace(path)
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        return {'status':'READY','dataset':name,'path':str(path),'snapshots':len(snapshots),'contracts':chk['contracts'],'sha256':digest,'metadata':metadata or {}}
    def read(self,dataset):
        path=self.root/(self._name(dataset)+'.jsonl')
        if not path.exists():return {'status':'BLOCKED','reason':'DATASET_NOT_FOUND'}
        try: rows=[json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
        except (OSError,json.JSONDecodeError):return {'status':'BLOCKED','reason':'DATASET_CORRUPTED'}
        return HistoricalOptionChainValidator.validate(rows)|{'rows':rows}
