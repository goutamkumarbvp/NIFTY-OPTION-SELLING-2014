from __future__ import annotations
import csv, hashlib, json, math, sqlite3
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from collections import defaultdict

IST_OFFSET = '+05:30'

@dataclass(frozen=True)
class DataLineage:
    dataset: str
    source: str
    source_type: str
    imported_at: str
    row_count: int
    sha256: str
    schema_version: str = 'v12.0'

class Pass12ValidationError(ValueError): pass

class ContractIdentity:
    REQUIRED=('symbol','instrument_token','exchange_segment','underlying','expiry','strike','option_type','lot_size','tick_size')
    @classmethod
    def validate(cls, c):
        if not isinstance(c,dict): raise Pass12ValidationError('INVALID_CONTRACT')
        for k in cls.REQUIRED:
            if k not in c or str(c[k]).strip()=='': raise Pass12ValidationError('MISSING_CONTRACT_FIELD')
        if str(c['underlying']).upper()!='NIFTY': raise Pass12ValidationError('NON_NIFTY_UNDERLYING')
        if str(c['exchange_segment']).lower()!='nse_fo': raise Pass12ValidationError('INVALID_EXCHANGE_SEGMENT')
        if str(c['option_type']).upper() not in ('CE','PE'): raise Pass12ValidationError('INVALID_OPTION_TYPE')
        try:
            strike=float(c['strike']); lot=int(c['lot_size']); tick=float(c['tick_size'])
            datetime.fromisoformat(str(c['expiry'])[:10])
        except Exception: raise Pass12ValidationError('INVALID_CONTRACT_NUMERIC_OR_EXPIRY')
        if not math.isfinite(strike) or strike<=0 or lot<=0 or not math.isfinite(tick) or tick<=0: raise Pass12ValidationError('INVALID_CONTRACT_NUMERIC')
        return True

class HistoricalNormalizer:
    ALIASES={'ts':'timestamp','time':'timestamp','underlying_price':'spot','trading_symbol':'symbol','token':'instrument_token','segment':'exchange_segment','open_interest':'oi','best_bid':'bid','best_ask':'ask'}
    @staticmethod
    def timestamp(x):
        s=str(x).strip().replace('Z','+00:00')
        dt=datetime.fromisoformat(s)
        if dt.tzinfo is None: raise Pass12ValidationError('TIMESTAMP_TIMEZONE_REQUIRED')
        return dt.isoformat()
    @classmethod
    def row(cls,row):
        if not isinstance(row,dict): raise Pass12ValidationError('INVALID_ROW')
        r={cls.ALIASES.get(str(k).strip().lower(),str(k).strip().lower()):v for k,v in row.items()}
        r['timestamp']=cls.timestamp(r['timestamp'])
        r['spot']=float(r['spot'])
        if not math.isfinite(r['spot']) or r['spot']<=0: raise Pass12ValidationError('INVALID_SPOT')
        ContractIdentity.validate(r)
        r['expiry']=str(r['expiry'])[:10]; r['option_type']=str(r['option_type']).upper()
        r['strike']=float(r['strike']); r['lot_size']=int(r['lot_size']); r['tick_size']=float(r['tick_size'])
        for k in ('bid','ask'):
            r[k]=float(r[k])
            if not math.isfinite(r[k]) or r[k]<=0: raise Pass12ValidationError('INVALID_QUOTE')
        if r['ask']<r['bid']: raise Pass12ValidationError('CROSSED_MARKET')
        for k in ('oi','volume'):
            r[k]=float(r.get(k,0))
            if not math.isfinite(r[k]) or r[k]<0: raise Pass12ValidationError('INVALID_OI_OR_VOLUME')
        return r

class ProvenanceRegistry:
    def __init__(self,path='runtime/historical_options/v12_provenance.sqlite3'):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(self.path) as c:
            c.execute('CREATE TABLE IF NOT EXISTS lineage(dataset TEXT PRIMARY KEY, source TEXT NOT NULL, source_type TEXT NOT NULL, imported_at TEXT NOT NULL, row_count INTEGER NOT NULL, sha256 TEXT NOT NULL, schema_version TEXT NOT NULL)')
    @staticmethod
    def digest(rows): return hashlib.sha256(''.join(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n' for r in rows).encode()).hexdigest()
    def register(self,dataset,source,source_type,rows):
        if not dataset or not source: return {'status':'BLOCKED','reason':'INVALID_PROVENANCE'}
        h=self.digest(rows); now=datetime.now().astimezone().isoformat()
        with sqlite3.connect(self.path) as c:
            old=c.execute('SELECT sha256 FROM lineage WHERE dataset=?',(str(dataset),)).fetchone()
            if old and old[0]!=h: return {'status':'BLOCKED','reason':'DATASET_IMMUTABLE'}
            if old: return {'status':'READY','existing':True,'dataset':dataset,'sha256':h,'rows':len(rows)}
            c.execute('INSERT INTO lineage VALUES(?,?,?,?,?,?,?)',(str(dataset),str(source),str(source_type),now,len(rows),h,'v12.0'))
        return {'status':'READY','existing':False,'dataset':dataset,'sha256':h,'rows':len(rows)}
    def get(self,dataset):
        with sqlite3.connect(self.path) as c:r=c.execute('SELECT * FROM lineage WHERE dataset=?',(dataset,)).fetchone()
        if not r:return {'status':'BLOCKED','reason':'DATASET_NOT_FOUND'}
        return {'status':'READY','lineage':asdict(DataLineage(*r))}

class PartitionedStore:
    """Filesystem partitioner: dataset/date/expiry. Uses atomic temp-file replacement and JSONL universally; Parquet is optional."""
    def __init__(self,root='runtime/historical_options/v12_partitions'):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def write(self,dataset,rows):
        if not isinstance(rows,list) or not rows:return {'status':'BLOCKED','reason':'NO_ROWS'}
        groups=defaultdict(list)
        for r in rows:
            dt=HistoricalNormalizer.timestamp(r['timestamp']); expiry=str(r['expiry'])[:10]
            day=dt[:10]; groups[(day,expiry)].append(r)
        files=[]
        for (day,expiry),grp in sorted(groups.items()):
            d=self.root/safe(dataset)/f'date={day}'/f'expiry={expiry}'; d.mkdir(parents=True,exist_ok=True)
            target=d/'part-00001.jsonl'; tmp=d/'part-00001.jsonl.tmp'
            with open(tmp,'w',encoding='utf-8') as f:
                for r in grp:f.write(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n'); f.flush(); import os; os.fsync(f.fileno())
            tmp.replace(target); files.append(str(target))
        return {'status':'READY','files':files,'partitions':len(files),'rows':len(rows),'format':'jsonl_partitioned'}
    def manifest(self,dataset):
        base=self.root/safe(dataset)
        if not base.exists():return {'status':'BLOCKED','reason':'DATASET_NOT_FOUND'}
        files=sorted(str(p) for p in base.rglob('*.jsonl')); return {'status':'READY','files':files,'partitions':len(files)}

def safe(x):
    import re
    s=re.sub(r'[^A-Za-z0-9_-]','',str(x)); return s or 'dataset'

class CoverageAnalyzer:
    def analyze(self,rows):
        if not isinstance(rows,list) or not rows:return {'status':'BLOCKED','reason':'NO_ROWS'}
        by_day=defaultdict(set); by_exp=defaultdict(int); gaps=[]; prev=None
        for r in rows:
            t=HistoricalNormalizer.timestamp(r['timestamp']); by_day[t[:10]].add(t); by_exp[str(r['expiry'])[:10]]+=1
            if prev and t<=prev:return {'status':'BLOCKED','reason':'NON_MONOTONIC_TIMESTAMP'}
            prev=t
        times=[HistoricalNormalizer.timestamp(r['timestamp']) for r in rows]
        from datetime import datetime as D
        dts=[D.fromisoformat(x) for x in times]
        deltas=[(b-a).total_seconds() for a,b in zip(dts,dts[1:])]
        if deltas:
            med=sorted(deltas)[len(deltas)//2]
            gaps=[{'from':a.isoformat(),'to':b.isoformat(),'seconds':(b-a).total_seconds()} for a,b in zip(dts,dts[1:]) if (b-a).total_seconds()>max(med*1.5,60)]
        return {'status':'READY','rows':len(rows),'days':len(by_day),'date_range':{'start':times[0],'end':times[-1]},'expiries':dict(sorted(by_exp.items())),'median_interval_seconds':(sorted(deltas)[len(deltas)//2] if deltas else None),'gaps':gaps,'gap_count':len(gaps)}

class ReplaySource:
    def from_jsonl(self,path,limit=1000000):
        rows=[]
        with open(path,encoding='utf-8') as f:
            for i,line in enumerate(f):
                if i>=limit: break
                rows.append(json.loads(line))
        return rows

class DatasetCompleteness:
    def score(self,coverage,expected_days=None,expected_expiries=None):
        if coverage.get('status')!='READY':return {'status':'BLOCKED','reason':'INVALID_COVERAGE'}
        components=[]
        if expected_days is not None:
            if expected_days<=0:return {'status':'BLOCKED','reason':'INVALID_EXPECTED_DAYS'}
            components.append(min(1,coverage['days']/expected_days))
        if expected_expiries is not None:
            if expected_expiries<=0:return {'status':'BLOCKED','reason':'INVALID_EXPECTED_EXPIRIES'}
            components.append(min(1,len(coverage['expiries'])/expected_expiries))
        if coverage['gap_count']>0: components.append(max(0,1-min(1,coverage['gap_count']/max(1,coverage['rows']-1))))
        score=sum(components)/len(components) if components else 1.0
        return {'status':'READY','score':round(score,4),'complete':score>=0.999,'components':components}
