from __future__ import annotations
import asyncio, threading, time
from dataclasses import dataclass
from typing import Callable, Optional

@dataclass(frozen=True)
class NormalizedTick:
    exchange_segment:str; instrument_token:str; trading_symbol:Optional[str]; ltp:float
    bid:Optional[float]; ask:Optional[float]; volume:Optional[int]; oi:Optional[int]
    timestamp:float; local_sequence:int; feed_level:str='touchline'; raw_type:str=''

def _num(x):
    try:return None if x is None else float(x)
    except:return None
def _int(x):
    try:return None if x is None else int(float(x))
    except:return None

def normalize_sdk_message(msg,sequence:int)->NormalizedTick:
    d=msg.model_dump() if hasattr(msg,'model_dump') else dict(msg)
    def g(*keys,default=None):
        for k in keys:
            if k in d and d[k] is not None:return d[k]
        return default
    ltp=_num(g('last_traded_price'))
    if ltp is None or not __import__('math').isfinite(ltp) or ltp<=0:
        raise ValueError('INVALID_LTP')
    bid=_num(g('best_bid_price','bid_price')); ask=_num(g('best_ask_price','ask_price'))
    if bid is not None and (not __import__('math').isfinite(bid) or bid<0): raise ValueError('INVALID_BID')
    if ask is not None and (not __import__('math').isfinite(ask) or ask<0): raise ValueError('INVALID_ASK')
    if bid is not None and ask is not None and bid>ask: raise ValueError('CROSSED_QUOTE')
    return NormalizedTick(str(g('exchange_segment',default='')),str(g('instrument_token',default='')),g('trading_symbol'),
      ltp,bid,ask,_int(g('volume')),_int(g('open_interest','oi')),time.time(),sequence,type(msg).__name__,type(msg).__name__)

class FeedState:
    def __init__(self): self.connected=False; self.last_message=0.0; self.last_error=''; self.reconnects=0; self.market_status='UNKNOWN'; self._seq=0; self.lock=threading.RLock()
    def mark_connected(self):
        with self.lock:self.connected=True
    def mark_message(self):
        with self.lock:self.last_message=time.time(); self._seq+=1; return self._seq
    def mark_error(self,e):
        with self.lock:self.last_error=str(e)
    def mark_disconnected(self):
        with self.lock:self.connected=False
    def snapshot(self):
        with self.lock:return {'connected':self.connected,'last_message':self.last_message,'age':time.time()-self.last_message if self.last_message else None,'last_error':self.last_error,'reconnects':self.reconnects,'market_status':self.market_status,'local_sequence':self._seq}

class KotakSFeedBridge:
    def __init__(self,neo_client,on_tick:Callable,on_status:Optional[Callable]=None,max_reconnects:int=10,backoff:float=1.0):
        self.neo=neo_client; self.on_tick=on_tick; self.on_status=on_status or (lambda s:None); self.max_reconnects=max_reconnects; self.backoff=backoff; self.state=FeedState(); self.stop_event=asyncio.Event()
    async def run(self,tokens:list):
        if len(tokens)>3000: raise ValueError('SFEED_SUBSCRIPTION_LIMIT_EXCEEDED:3000')
        try: from neo_api_client.websocket.feed import WsToken,SFeedScrip,SFeedScripLite,SFeedIndex,SFeedMarketStatus,SFeedCasChange
        except ImportError as e: raise RuntimeError('kotakneoapi==3.0.6 with SFeed support required') from e
        attempts=0
        while not self.stop_event.is_set():
            try:
                async with self.neo.create_websocket() as ws:
                    self.state.mark_connected(); self.on_status('CONNECTED'); await ws.subscribe_exchange()
                    await ws.subscribe_scrips([WsToken(seg,str(tok)) for seg,tok in tokens])
                    attempts=0
                    async for msg in ws:
                        if self.stop_event.is_set(): break
                        if isinstance(msg,SFeedMarketStatus): self.state.market_status=msg.status; self.on_status(msg.status); continue
                        if isinstance(msg,(SFeedScrip,SFeedScripLite,SFeedIndex,SFeedCasChange)):
                            seq=self.state.mark_message(); self.on_tick(normalize_sdk_message(msg,seq))
            except asyncio.CancelledError: raise
            except Exception as e:
                self.state.mark_error(e); self.state.mark_disconnected(); self.on_status('ERROR');
                if self.stop_event.is_set(): break
                attempts+=1
                if attempts>self.max_reconnects: raise
                self.state.reconnects+=1; await asyncio.sleep(min(self.backoff*2**(attempts-1),30))
    async def stop(self): self.stop_event.set()

class FeedSupervisor:
    def __init__(self,bridge): self.bridge=bridge; self.thread=None; self.loop=None; self.error=None
    def start(self,tokens):
        if self.thread and self.thread.is_alive(): raise RuntimeError('FEED_ALREADY_RUNNING')
        def worker():
            try:self.loop=asyncio.new_event_loop(); asyncio.set_event_loop(self.loop); self.loop.run_until_complete(self.bridge.run(tokens))
            except Exception as e:self.error=e
            finally:
                if self.loop and not self.loop.is_closed(): self.loop.close()
        self.thread=threading.Thread(target=worker,name='kotak-sfeed',daemon=True); self.thread.start()
    def stop(self):
        if self.loop and not self.loop.is_closed():
            fut=asyncio.run_coroutine_threadsafe(self.bridge.stop(),self.loop)
            try:fut.result(timeout=3)
            except Exception:pass
        if self.thread:self.thread.join(timeout=3)
