from server import Audit
from pathlib import Path
import tempfile

def test_hash_chained_audit_verifies_and_detects_tamper():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'audit.jsonl'; a=Audit(p); a.record('X',{'v':1}); a.record('Y')
        assert Audit(p).verify() is True
        lines=p.read_text().splitlines(); lines[0]=lines[0].replace('"event":"X"','"event":"TAMPER"'); p.write_text('\n'.join(lines)+'\n')
        try: Audit(p); assert False
        except RuntimeError as e: assert str(e)=='AUDIT_CHAIN_CORRUPTED'
