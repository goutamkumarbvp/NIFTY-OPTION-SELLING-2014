from __future__ import annotations
import inspect
from dataclasses import dataclass
from typing import Optional

@dataclass
class NeoConfig:
    consumer_key:str; environment:str='prod'; mobile_number:Optional[str]=None; ucc:Optional[str]=None

class KotakNeoMarketAdapter:
    """Read-only market-data adapter for official Kotak Neo Python SDK 3.0.6."""
    def __init__(self,config:NeoConfig): self.config=config; self.client=None; self.authenticated=False
    def load_sdk(self):
        try: from neo_api_client import NeoAPI
        except ImportError as e: raise RuntimeError('Install kotakneoapi==3.0.6') from e
        self.client=NeoAPI(consumer_key=self.config.consumer_key,environment=self.config.environment); return self.client
    def authenticate(self,totp:str,mpin:str):
        if not self.client:self.load_sdk()
        if not self.config.mobile_number or not self.config.ucc: raise ValueError('MOBILE_NUMBER_AND_UCC_REQUIRED')
        login=self.client.totp_login(mobile_number=self.config.mobile_number,ucc=self.config.ucc,totp=totp)
        validate=self.client.totp_validate(mpin=mpin)
        self.authenticated=True
        return {'login_status':self._status(login),'validate_status':self._status(validate)}
    @staticmethod
    def _status(x):
        if isinstance(x,dict): return x.get('stat') or x.get('status') or ('OK' if not x.get('error') else 'ERROR')
        return 'OK'
    def _require_auth(self):
        if not self.client or not self.authenticated: raise RuntimeError('NOT_AUTHENTICATED')
    def _call(self,name,**kwargs):
        self._require_auth(); fn=getattr(self.client,name,None)
        if not fn: raise RuntimeError(f'SDK_METHOD_NOT_AVAILABLE:{name}')
        sig=inspect.signature(fn); has_varkw=any(p.kind==inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
        accepted={k:v for k,v in kwargs.items() if v is not None} if has_varkw else {k:v for k,v in kwargs.items() if k in sig.parameters and v is not None}
        return fn(**accepted)
    def quotes(self,instrument_tokens): return self._call('quotes',instrument_tokens=instrument_tokens,quote_type='all')
    def expiries(self,exchange_segment='nse_fo',instrument_token=None): return self._call('expiries',exchange_segment=exchange_segment,instrument_token=instrument_token)
    def option_chain(self,exchange_segment='nse_fo',instrument_token=None,expiry=None): return self._call('option_chain',exchange_segment=exchange_segment,instrument_token=instrument_token,expiry=expiry)
    def search_scrip(self,**kwargs): return self._call('search_scrip',**kwargs)
    def positions(self): return self._call('positions')
    def holdings(self): return self._call('holdings')
    def limits(self): return self._call('limits')
    def margin_required(self,**kwargs): return self._call('margin_required',**kwargs)
    def order_report(self,order_id=None): return self._call('order_report',order_id=order_id)
    def trade_report(self): return self._call('trade_report')
    def scrip_master(self,exchange_segment=None):
        from instrument_master import ScripMasterClient
        if not self.client:self.load_sdk()
        return ScripMasterClient(self.client).discover(exchange_segment)
