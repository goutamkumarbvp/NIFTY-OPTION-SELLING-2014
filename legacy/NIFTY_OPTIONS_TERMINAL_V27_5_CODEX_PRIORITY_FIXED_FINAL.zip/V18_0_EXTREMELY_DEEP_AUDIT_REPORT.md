# V18.0 Extremely Deep Audit Report — Verified Code Self-Repair

## Scope
Audited the V17.4 source package and added V18 verified code self-repair capabilities while preserving the hard paper-only execution boundary.

## Findings and repairs
1. **Runtime-only healing boundary** — V17.4 could recover the market feed but could not diagnose/test source failures. V18 adds a separate code-repair control plane.
2. **No immutable repair checkpoint** — V18 snapshots the target source before any promotion.
3. **No isolated candidate verification** — V18 copies the project into a temporary sandbox and applies the candidate there first.
4. **No mandatory verification gate** — V18 requires compile, pytest, and safety-invariant scanning before promotion.
5. **No automatic rollback path** — V18 restores the pre-repair snapshot if post-promotion verification fails.
6. **Unsafe autonomous mutation risk** — V18 forbids secret files, targets outside the project root, enabling live trading, adding `place_order`, or changing `live_orders_enabled` to true.
7. **AI overclaim risk** — the default provider is deterministic/offline and explicitly does not pretend to be a general LLM. An external AI provider can be plugged into the proposal interface, but all policy/test gates remain mandatory.
8. **API observability gap** — V18 exposes self-repair status, diagnosis, and run endpoints through the existing backend control plane.
9. **Regression risk** — all existing tests were rerun after integration.

## V18 control flow
`Detect → Diagnose → Propose → Syntax Gate → Policy Gate → Snapshot → Sandbox → Compile → Tests → Security Invariants → Optional Promotion → Post-Promotion Verify → Automatic Rollback → Audit`

## Safety invariants
- `LIVE_TRADING` cannot be enabled by the repair engine.
- `live_orders_enabled=True` cannot be introduced by a repair.
- A `place_order()` function cannot be introduced by a repair.
- `.env`, secret-like files, and files outside the project root are not repair targets.
- Default `SELF_REPAIR_AUTO_PROMOTE=false`.
- Existing paper-only execution controls remain intact.

## Verification results
- **Pytest: 271/271 PASS**
- **V18 self-repair tests: 6/6 PASS**
- **V17.4 runtime self-healing tests: 2/2 PASS**
- **Python compile: PASS**
- **HTTP startup/health smoke test: PASS on isolated port**
- **Live-trading safety scan: PASS** (only test strings and defensive scanner literals mention the blocked terms)
- **Secret-like hardcoded credential scan: no findings**

## Important limitation
V18 provides the **verified self-repair framework and safe offline deterministic diagnosis**, not a claim that an LLM can autonomously invent a correct fix for every possible programming defect. General AI patch generation is provider-dependent. A proposed patch is never trusted merely because an AI generated it; it must pass the same hard gates.

## Production recommendation
Keep `SELF_REPAIR_AUTO_PROMOTE=false` until a long paper/sandbox soak demonstrates stable behavior. Sensitive trading/risk/execution/authentication changes should remain human-approved even when an AI proposal is available.
