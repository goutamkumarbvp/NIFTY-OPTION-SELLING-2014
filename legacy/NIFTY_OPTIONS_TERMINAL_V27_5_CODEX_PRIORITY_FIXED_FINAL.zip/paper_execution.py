from __future__ import annotations
import json, sqlite3, threading, time, uuid
from pathlib import Path
from dataclasses import dataclass, asdict

@dataclass
class PaperOrder:
    order_id: str
    symbol: str
    side: str
    quantity: int
    order_type: str
    limit_price: float | None
    status: str = 'OPEN'
    filled_quantity: int = 0
    avg_fill_price: float | None = None
    created_at: float = 0.0
    updated_at: float = 0.0

class PaperExecutionLedger:
    """Deterministic paper-only execution ledger. It has no broker dependency."""
    def __init__(self, db_path: Path):
        self.db_path=Path(db_path); self.db_path.parent.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock(); self._init()
    def _conn(self):
        c=sqlite3.connect(self.db_path, timeout=10, isolation_level='IMMEDIATE'); c.row_factory=sqlite3.Row; return c
    def _init(self):
        with self._conn() as c:
            c.executescript('''CREATE TABLE IF NOT EXISTS orders(order_id TEXT PRIMARY KEY,symbol TEXT NOT NULL,side TEXT NOT NULL,quantity INTEGER NOT NULL,order_type TEXT NOT NULL,limit_price REAL,status TEXT NOT NULL,filled_quantity INTEGER NOT NULL,avg_fill_price REAL,created_at REAL NOT NULL,updated_at REAL NOT NULL); CREATE TABLE IF NOT EXISTS fills(fill_id TEXT PRIMARY KEY,order_id TEXT NOT NULL,quantity INTEGER NOT NULL,price REAL NOT NULL,ts REAL NOT NULL);''')
    def submit(self, symbol, side, quantity, order_type='MARKET', limit_price=None, fill_price=None):
        symbol=str(symbol).strip(); side=str(side).upper(); order_type=str(order_type).upper(); quantity=int(quantity)
        if not symbol: raise ValueError('SYMBOL_REQUIRED')
        if side not in {'BUY','SELL'}: raise ValueError('SIDE_INVALID')
        if quantity<=0 or quantity>1000000: raise ValueError('QUANTITY_INVALID')
        if order_type not in {'MARKET','LIMIT'}: raise ValueError('ORDER_TYPE_INVALID')
        if order_type=='LIMIT' and (limit_price is None or float(limit_price)<=0): raise ValueError('LIMIT_PRICE_REQUIRED')
        now=time.time(); oid=uuid.uuid4().hex
        with self.lock, self._conn() as c:
            c.execute('INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?,?)',(oid,symbol,side,quantity,order_type,limit_price,'OPEN',0,None,now,now))
            if fill_price is not None or order_type=='MARKET':
                if fill_price is None:
                    raise ValueError('FILL_PRICE_REQUIRED')
                px=float(fill_price)
                if px<=0 or px != px or px in (float('inf'), float('-inf')): raise ValueError('FILL_PRICE_INVALID')
                marketable=True
                if order_type=='LIMIT':
                    limit=float(limit_price)
                    marketable=not ((side=='BUY' and px>limit) or (side=='SELL' and px<limit))
                if marketable:
                    c.execute('UPDATE orders SET status=?,filled_quantity=?,avg_fill_price=?,updated_at=? WHERE order_id=?',('FILLED',quantity,px,now,oid))
                    c.execute('INSERT INTO fills VALUES(?,?,?,?,?)',(uuid.uuid4().hex,oid,quantity,px,now))
        return self.get_order(oid)
    def cancel(self, order_id):
        with self.lock, self._conn() as c:
            r=c.execute('SELECT status FROM orders WHERE order_id=?',(str(order_id),)).fetchone()
            if not r: raise ValueError('ORDER_NOT_FOUND')
            if r['status']!='OPEN': raise ValueError('ORDER_NOT_OPEN')
            c.execute('UPDATE orders SET status=?,updated_at=? WHERE order_id=?',('CANCELLED',time.time(),str(order_id)))
        return self.get_order(order_id)
    def get_order(self, order_id):
        with self._conn() as c:
            r=c.execute('SELECT * FROM orders WHERE order_id=?',(str(order_id),)).fetchone()
            return dict(r) if r else None
    def orders(self, limit=500):
        with self._conn() as c: return [dict(r) for r in c.execute('SELECT * FROM orders ORDER BY created_at DESC LIMIT ?', (min(max(int(limit),1),5000),))]
    def _symbol_account(self, symbol):
        """Return FIFO-matched realized P&L and remaining open lots."""
        with self._conn() as c:
            rows=c.execute("SELECT f.quantity, f.price, f.ts, o.side FROM fills f JOIN orders o ON o.order_id=f.order_id WHERE o.symbol=? ORDER BY f.ts ASC, f.fill_id ASC", (symbol,)).fetchall()
        lots=[]
        realized=0.0
        for r in rows:
            signed=int(r['quantity']) if r['side']=='BUY' else -int(r['quantity'])
            price=float(r['price'])
            while signed and lots and ((lots[0][0] > 0) != (signed > 0)):
                lqty,lprice=lots[0]
                matched=min(abs(lqty),abs(signed))
                realized += ((price-lprice) if lqty > 0 else (lprice-price))*matched
                lots[0][0] -= matched if lqty > 0 else -matched
                signed += matched if signed < 0 else -matched
                if lots[0][0] == 0: lots.pop(0)
            if signed: lots.append([signed,price])
        return realized,lots

    def positions(self):
        with self._conn() as c:
            rows=c.execute("SELECT symbol,side,SUM(filled_quantity) qty,SUM(filled_quantity*avg_fill_price)/SUM(filled_quantity) avg_price FROM orders WHERE status='FILLED' GROUP BY symbol,side").fetchall()
        out={}
        for r in rows:
            out.setdefault(r['symbol'],{'symbol':r['symbol'],'net_quantity':0,'buy_quantity':0,'sell_quantity':0,'avg_buy_price':None,'avg_sell_price':None})
            qty=int(r['qty'])
            if r['side']=='BUY': out[r['symbol']].update(buy_quantity=qty,avg_buy_price=float(r['avg_price'])); out[r['symbol']]['net_quantity']+=qty
            else: out[r['symbol']].update(sell_quantity=qty,avg_sell_price=float(r['avg_price'])); out[r['symbol']]['net_quantity']-=qty
        return list(out.values())

    def mark_to_market(self, prices: dict):
        result=[]; total_unrealized=0.0; total_realized=0.0
        for p in self.positions():
            realized,lots=self._symbol_account(p['symbol']); p['realized_pnl']=realized; total_realized+=realized
            px=prices.get(p['symbol'])
            if px is None: p['unrealized_pnl']=None; result.append(p); continue
            px=float(px)
            if px<=0 or px != px or px in (float('inf'),float('-inf')): p['unrealized_pnl']=None; result.append(p); continue
            unrealized=sum((px-entry)*qty for qty,entry in lots)
            p['unrealized_pnl']=unrealized; total_unrealized+=unrealized; result.append(p)
        return {'positions':result,'realized_pnl':total_realized,'unrealized_pnl':total_unrealized,'total_pnl':total_realized+total_unrealized}
    def flatten(self, prices: dict):
        # Serialize the entire snapshot -> submit sequence.  Taking the lock only
        # inside submit() is insufficient because two callers can otherwise read
        # the same non-zero position before either caller writes the flattening fill.
        # Holding this ledger lock across the complete operation makes flatten
        # linearizable and prevents LONG -> SHORT / SHORT -> LONG over-flattening.
        with self.lock:
            out=[]
            for p in self.positions():
                q=int(p['net_quantity']); px=prices.get(p['symbol'])
                if q==0 or px is None: continue
                out.append(self.submit(p['symbol'],'SELL' if q>0 else 'BUY',abs(q),'MARKET',fill_price=float(px)))
            return out
