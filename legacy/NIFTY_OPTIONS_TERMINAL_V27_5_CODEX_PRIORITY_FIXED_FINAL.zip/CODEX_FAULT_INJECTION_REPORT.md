# CODEX Fault-Injection / Automatic-Healing Verification

Mode: paper/read-only. No live orders or real credentials used.

## Campaign
13 adversarial runtime scenarios were executed against the SelfHealingSupervisor.

PASS scenarios:
- dead feed worker
- broker/feed disconnect
- stale feed
- NaN feed age
- Infinity feed age
- negative feed age
- emergency safety hold
- unauthenticated hold
- feed-disabled hold
- market-closed hold
- false-success recovery (never marked healthy)
- recovery exception (never marked healthy)
- repeated failed recovery / circuit breaker

Result: **13/13 PASS**.

## Repair made during attack
Non-finite and negative feed age values were previously capable of bypassing the stale-age comparison. The health classifier now explicitly rejects non-finite/negative age as `INVALID_FEED_AGE`, causing the recovery path to execute and requiring post-recovery health verification.

## Regression evidence
- Targeted hardening/self-healing tests: 20 passed
- Existing release suite (excluding the new long-duration fault test): 341 passed
- Total collected tests after addition: 345

## Safety
All tests used synthetic state/recovery functions. No broker credentials, real order endpoints, or live trading were enabled.
