# V17.3 — MULTI-CHANNEL LIVE ALERTING

Adds Telegram + SMS + WhatsApp delivery to the existing fail-safe alert engine. SMS and WhatsApp use Twilio Programmable Messaging; all secrets are local environment variables and never exposed in the dashboard. Dashboard remains always enabled. Alerting never places, modifies, cancels, or enables orders. LIVE_TRADING remains false.

Channels: dashboard, Telegram, SMS, WhatsApp.
Alert types: stop loss, new trade, black swan, big move, feed stale/disconnect, risk block, reconciliation mismatch, emergency, undesirable.

External delivery is configuration-dependent and was not falsely claimed as delivered during build tests.
