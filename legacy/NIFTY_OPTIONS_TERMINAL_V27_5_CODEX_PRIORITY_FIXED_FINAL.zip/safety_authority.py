from runtime_config import assert_paper_only, SafetyInvariantError
PAPER_ONLY_INVARIANTS={'TRADING_MODE':'paper','LIVE_TRADING':'false','LIVE_ORDERS_ENABLED':'false'}
