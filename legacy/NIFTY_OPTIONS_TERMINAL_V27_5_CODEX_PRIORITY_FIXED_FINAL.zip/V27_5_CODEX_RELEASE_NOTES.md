# V27.5 Codex Release Notes

## Release identity
- Release: V27.5
- Mode: paper/read-only
- Live orders: disabled
- Automatic repair promotion: disabled by default

## Codex repairs carried forward
- Health/version normalization
- Fail-closed OS sandbox capability handling
- Candidate identity and integrity verification
- Independent reflection/security gate
- Compile/test/security/policy gates before promotion
- Automatic rollback and post-promotion verification
- Panic/order and concurrent-flatten serialization
- Strict JSON and non-finite input rejection

## V27.5 release gates
- Full pytest suite must be green.
- Self-repair sandbox must be executable on the certification host.
- No unsandboxed fallback is permitted.
- Paper-only invariant must remain enforced.
- Live orders must remain disabled.

## Hang/clean-exit hardening
- Test runner disables host/global pytest plugin autoload to prevent external plugin teardown resources from keeping the process alive after tests finish.
- Python fault handler is enabled for actionable diagnostics.
- Release test runner has a 180-second hard upper bound with graceful TERM followed by KILL fallback, preventing an indefinite CI/test-runner hang.
- Verified clean exit after the full 379-test suite.
