from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class Position:
    key: str
    symbol: str
    exchange_segment: str
    quantity: float
    average_price: float | None
    raw: dict

def _num(v):
    try: return None if v in (None, '') else float(v)
    except (TypeError, ValueError): return None

def _rows(payload: Any) -> list[dict]:
    if isinstance(payload, list): return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for k in ('data','positions','position','result'):
            if k in payload:
                return _rows(payload[k])
    return []

def normalize_positions(payload: Any) -> dict[str, Position]:
    out={}
    for r in _rows(payload):
        symbol=str(r.get('tradingSymbol') or r.get('displaySymbol') or r.get('symbol') or '')
        seg=str(r.get('exchangeSegment') or r.get('exchange_segment') or '')
        token=str(r.get('instrumentToken') or r.get('instrument_token') or '')
        key=f'{seg}:{token or symbol}'
        qty=_num(r.get('quantity') if r.get('quantity') is not None else r.get('netQuantity'))
        if qty is None: qty=_num(r.get('netQty'))
        if qty is None: qty=0.0
        avg=_num(r.get('averagePrice') if r.get('averagePrice') is not None else r.get('avgPrice'))
        out[key]=Position(key,symbol,seg,qty,avg,r)
    return out

def reconcile(broker_payload: Any, local_payload: Any) -> dict:
    broker=normalize_positions(broker_payload); local=normalize_positions(local_payload)
    keys=sorted(set(broker)|set(local)); mismatches=[]
    for k in keys:
        b=broker.get(k); l=local.get(k)
        bq=b.quantity if b else 0.0; lq=l.quantity if l else 0.0
        if abs(bq-lq)>1e-9:
            mismatches.append({'key':k,'broker_qty':bq,'local_qty':lq,'delta':bq-lq})
    return {'matched':not mismatches,'broker_positions':len(broker),'local_positions':len(local),'mismatches':mismatches}
