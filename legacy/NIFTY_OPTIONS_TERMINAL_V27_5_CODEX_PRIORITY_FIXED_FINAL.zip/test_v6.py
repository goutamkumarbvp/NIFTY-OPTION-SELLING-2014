from quant_engine import QuantEngine
from vol_surface import VolatilitySurface
from event_intelligence import EventIntelligence
from fii_dii_intelligence import FiiDiiIntelligence
from research_backtest import ResearchBacktester
from server import TerminalBackend,Handler
from http.server import ThreadingHTTPServer
from urllib.request import urlopen,Request
from urllib.error import HTTPError
import json,threading,math

def test_call_put_parity():
 q=QuantEngine(); c=q.price(100,100,30/365,.05,.2,.0,True); p=q.price(100,100,30/365,.05,.2,.0,False)
 assert abs((c-p)-(100-100*math.exp(-.05*30/365)))<1e-7

def test_greeks_finite():
 g=QuantEngine().greeks(25000,25000,30/365,.06,.15); assert all(math.isfinite(x) for x in g.__dict__.values())

def test_iv_roundtrip():
 q=QuantEngine(); px=q.price(100,105,60/365,.05,.25); iv=q.implied_vol(px,100,105,60/365,.05); assert iv and abs(iv-.25)<1e-5

def test_iv_arbitrage_invalid():
 assert QuantEngine().implied_vol(1,100,100,30/365,.05) is not None
 assert QuantEngine().implied_vol(150,100,100,30/365,.05) is None

def test_surface_no_extrapolation():
 v=VolatilitySurface(); v.load([{'expiry':.1,'strike':100,'iv':.2},{'expiry':.1,'strike':110,'iv':.22}]); assert v.interpolate(.1,105)['status']=='READY'; assert v.interpolate(.2,105)['status']=='BLOCKED'

def test_surface_empty_blocks(): assert VolatilitySurface().interpolate(.1,100)['status']=='BLOCKED'

def test_event_missing_blocks(): assert EventIntelligence().analyze(None)['status']=='BLOCKED'

def test_event_high_near_blocks():
 e=EventIntelligence(60).analyze([{'name':'RBI','timestamp':'2026-09-15T09:00:00+05:30','severity':'HIGH'}],now=__import__('datetime').datetime.fromisoformat('2026-09-15T08:50:00+05:30')); assert e['status']=='BLOCKED'

def test_event_future_not_immediate_block():
 e=EventIntelligence(30).analyze([{'name':'Event','timestamp':'2026-09-16T09:00:00+05:30','severity':'HIGH'}],now=__import__('datetime').datetime.fromisoformat('2026-09-15T08:50:00+05:30')); assert e['status']=='READY'

def test_flows_bias():
 x=FiiDiiIntelligence().analyze([{'date':'x','fii_net':-100,'dii_net':50}]); assert x['bias']=='BEARISH' and x['combined_total']==-50

def test_flows_missing_blocks(): assert FiiDiiIntelligence().analyze(None)['status']=='BLOCKED'

def test_backtest_lookahead_protection():
 x=ResearchBacktester().run([{'open':100,'close':102},{'open':102,'close':110},{'open':110,'close':105}], [1,-1,0]); assert x['status']=='READY' and x['lookahead_protection']=='signal_t_fills_bar_t_plus_1'

def test_backtest_signal_length(): assert ResearchBacktester().run([{'open':1,'close':2}]*3,[1])['status']=='BLOCKED'

def test_backtest_invalid_signal(): assert ResearchBacktester().run([{'open':1,'close':2}]*3,[2,0,0])['status']=='BLOCKED'

def test_backend_pass6_modules():
 a=TerminalBackend(); assert a.quant and a.vol_surface and a.event_intel and a.fii_dii and a.backtester
 assert a.state()['api_schema_version']=='v12.0'

def test_http_pass6_routes():
 srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); threading.Thread(target=srv.serve_forever,daemon=True).start(); base=f'http://127.0.0.1:{srv.server_address[1]}'
 try:
  h=json.loads(urlopen(base+'/api/health').read()); assert h['api_schema_version']=='v12.0' and h['live_orders_enabled'] is False
  for path,payload in [('/api/quant/greeks',{'spot':100,'strike':100,'time_to_expiry':.1,'rate':.05,'iv':.2}),('/api/quant/implied-vol',{'market_price':3,'spot':100,'strike':100,'time_to_expiry':.1,'rate':.05}),('/api/volatility/surface/load',{'points':[{'expiry':.1,'strike':100,'iv':.2}]}),('/api/intelligence/events',{'events':[]}),('/api/intelligence/fii-dii',{'rows':[{'date':'x','fii_net':1,'dii_net':2}]}),('/api/research/backtest',{'bars':[{'open':1,'close':2}]*3,'signals':[0,0,0]})]:
   r=Request(base+path,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'}); out=json.loads(urlopen(r).read()); assert 'state' in out
 finally:srv.shutdown();srv.server_close()

def test_dashboard_routes_present():
 s=open('dashboard/index.html').read();
 for x in ['/api/quant/greeks','/api/quant/implied-vol','/api/volatility/surface/load','/api/intelligence/events','/api/intelligence/fii-dii','/api/research/backtest']: assert x in s
