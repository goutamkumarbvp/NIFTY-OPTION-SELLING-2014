from __future__ import annotations
import threading, time, math
from collections import deque
from dataclasses import dataclass, asdict
from typing import Callable, Optional, Any

@dataclass
class HealingState:
    enabled: bool = True
    armed: bool = False
    status: str = "IDLE"
    last_check: float = 0.0
    last_recovery: float = 0.0
    recoveries: int = 0
    failures: int = 0
    consecutive_failures: int = 0
    circuit_open: bool = False
    last_reason: str = ""
    last_error: str = ""

class SelfHealingSupervisor:
    """Bounded, deterministic runtime self-healing.

    It does NOT modify source code, place orders, change risk policy, or bypass
    emergency/pause states. It only restarts an explicitly armed market-feed
    connection after health evidence indicates that the feed has failed.
    """
    SAFE_MARKET_STATES = {"OPEN", "TRADING", "RUNNING", "MARKET_OPEN", "ACTIVE"}

    def __init__(self, health: Callable[[], dict[str, Any]], recover: Callable[[], dict[str, Any]],
                 audit: Optional[Callable[[str, dict[str, Any]], Any]] = None,
                 interval: float = 2.0, stale_seconds: float = 8.0,
                 cooldown_seconds: float = 15.0, max_recoveries: int = 5,
                 window_seconds: float = 300.0):
        self.health = health
        self.recover = recover
        self.audit = audit or (lambda *_: None)
        self.interval = max(0.5, float(interval))
        self.stale_seconds = max(2.0, float(stale_seconds))
        self.cooldown_seconds = max(2.0, float(cooldown_seconds))
        self.max_recoveries = max(1, int(max_recoveries))
        self.window_seconds = max(30.0, float(window_seconds))
        self.state = HealingState()
        self._history = deque()
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.RLock()

    def start(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = threading.Thread(target=self._run, name="self-healing-supervisor", daemon=True)
            self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        t = self._thread
        if t and t.is_alive():
            t.join(timeout=3)

    def arm(self) -> None:
        with self._lock:
            self.state.armed = True
            self.state.status = "MONITORING"
            self.state.circuit_open = False
            self.state.consecutive_failures = 0
            self.state.last_error = ""
        self._wake.set()

    def disarm(self) -> None:
        with self._lock:
            self.state.armed = False
            self.state.status = "IDLE"

    def reset_circuit(self) -> None:
        with self._lock:
            self._history.clear()
            self.state.circuit_open = False
            self.state.consecutive_failures = 0
            self.state.status = "MONITORING" if self.state.armed else "IDLE"
            self.state.last_error = ""
        self._wake.set()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            out = asdict(self.state)
            out.update({
                "interval_seconds": self.interval,
                "stale_seconds": self.stale_seconds,
                "cooldown_seconds": self.cooldown_seconds,
                "max_recoveries": self.max_recoveries,
                "window_seconds": self.window_seconds,
                "recent_recoveries": len(self._recent()),
            })
            return out

    def _recent(self):
        now = time.time()
        while self._history and self._history[0] < now - self.window_seconds:
            self._history.popleft()
        return self._history

    def _eligible(self, h: dict[str, Any]) -> tuple[bool, str]:
        if not self.state.enabled or not self.state.armed:
            return False, "NOT_ARMED"
        if h.get("mode") in {"EMERGENCY", "PAUSED"} or h.get("paused"):
            return False, "SAFETY_STATE"
        if not h.get("authenticated"):
            return False, "NOT_AUTHENTICATED"
        if not h.get("feed_enabled"):
            return False, "FEED_NOT_ARMED"
        if self.state.circuit_open:
            return False, "CIRCUIT_OPEN"
        market_status = str(h.get("market_status") or "").upper()
        if market_status and market_status not in self.SAFE_MARKET_STATES:
            return False, "MARKET_NOT_OPEN"
        return True, ""

    def _failure_detected(self, h: dict[str, Any]) -> Optional[str]:
        if not h.get("feed_thread_alive", False):
            return "FEED_THREAD_DEAD"
        if not h.get("connected", False):
            return "FEED_DISCONNECTED"
        age = h.get("age")
        try:
            if age is not None:
                age_f = float(age)
                if not math.isfinite(age_f) or age_f < 0:
                    return "INVALID_FEED_AGE"
                if age_f > self.stale_seconds:
                    return "FEED_STALE"
        except Exception:
            return "INVALID_FEED_AGE"
        return None

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                h = self.health() or {}
                now = time.time()
                with self._lock:
                    self.state.last_check = now
                eligible, why = self._eligible(h)
                if not eligible:
                    with self._lock:
                        if why == "CIRCUIT_OPEN": self.state.status = "CIRCUIT_OPEN"
                        elif self.state.armed and why == "SAFETY_STATE": self.state.status = "SAFE_HOLD"
                        elif self.state.armed and why == "MARKET_NOT_OPEN": self.state.status = "MARKET_CLOSED_HOLD"
                        elif self.state.armed: self.state.status = "WAITING"
                else:
                    reason = self._failure_detected(h)
                    if reason:
                        with self._lock:
                            recent = len(self._recent())
                            cooldown = now - self.state.last_recovery < self.cooldown_seconds
                        if recent >= self.max_recoveries:
                            with self._lock:
                                self.state.circuit_open = True
                                self.state.status = "CIRCUIT_OPEN"
                                self.state.last_reason = reason
                            self.audit("SELF_HEAL_CIRCUIT_OPEN", {"reason": reason, "recent_recoveries": recent})
                        elif not cooldown:
                            self._recover(reason)
                        else:
                            with self._lock:
                                self.state.status = "COOLDOWN"
                    else:
                        with self._lock:
                            if self.state.armed:
                                self.state.status = "HEALTHY"
                                self.state.consecutive_failures = 0
            except Exception as e:
                with self._lock:
                    self.state.failures += 1
                    self.state.last_error = str(e)
                    self.state.status = "SUPERVISOR_ERROR"
                self.audit("SELF_HEAL_SUPERVISOR_ERROR", {"error": str(e)})
            self._wake.wait(self.interval)
            self._wake.clear()

    def _recover(self, reason: str) -> None:
        with self._lock:
            self.state.status = "RECOVERING"
            self.state.last_reason = reason
            self.state.last_recovery = time.time()
            self._history.append(self.state.last_recovery)
            attempt = self.state.recoveries + 1
        self.audit("SELF_HEAL_ATTEMPT", {"reason": reason, "attempt": attempt})
        try:
            result = self.recover() or {}
            ok = bool(result.get("ok"))
            time.sleep(min(3.0, max(0.5, self.interval)))
            h = self.health() or {}
            # Re-run the fail-closed health predicates after recovery. A live
            # thread/socket alone is insufficient: stale or invalid feed data
            # must never be promoted to HEALTHY.
            eligible, eligibility_reason = self._eligible(h)
            remaining_fault = self._failure_detected(h)
            verified = eligible and remaining_fault is None
            if ok and verified:
                with self._lock:
                    self.state.recoveries += 1
                    self.state.consecutive_failures = 0
                    self.state.status = "HEALTHY"
                    self.state.last_error = ""
                self.audit("SELF_HEAL_SUCCESS", {"reason": reason})
            else:
                with self._lock:
                    self.state.failures += 1
                    self.state.consecutive_failures += 1
                    self.state.status = "RECOVERY_FAILED"
                    self.state.last_error = str(result.get("error", "recovery verification failed"))
                self.audit("SELF_HEAL_FAILED", {"reason": reason, "result": result, "verified": verified, "eligibility_reason": eligibility_reason, "remaining_fault": remaining_fault})
        except Exception as e:
            with self._lock:
                self.state.failures += 1
                self.state.consecutive_failures += 1
                self.state.status = "RECOVERY_ERROR"
                self.state.last_error = str(e)
            self.audit("SELF_HEAL_ERROR", {"reason": reason, "error": str(e)})
