import json, os, sys, tempfile
import pytest
from pathlib import Path
from urllib.request import Request, urlopen
from http.server import ThreadingHTTPServer
from self_repair import CodeSelfRepairEngine
from market_intelligence import build_chain
from paper_execution import PaperExecutionLedger
from risk_brain import RiskBrain
from server import Handler
from market_feed import normalize_sdk_message


def test_multi_expiry_chain_identity_preserved():
    payload=[
        {'strike':100,'expiry':'2026-09-17','option_type':'CE','ltp':10},
        {'strike':100,'expiry':'2026-09-17','option_type':'PE','ltp':10},
        {'strike':100,'expiry':'2026-09-24','option_type':'CE','ltp':12},
        {'strike':100,'expiry':'2026-09-24','option_type':'PE','ltp':12},
    ]
    out=build_chain(payload)
    assert len(out)==2
    assert {x['expiry'] for x in out}=={'2026-09-17','2026-09-24'}


def test_limit_order_never_fills_beyond_limit():
    with tempfile.TemporaryDirectory() as d:
        l=PaperExecutionLedger(Path(d)/'p.sqlite3')
        o=l.submit('X','BUY',75,'LIMIT',limit_price=100,fill_price=120)
        assert o['status']=='OPEN' and o['filled_quantity']==0
        o=l.submit('Y','SELL',75,'LIMIT',limit_price=100,fill_price=120)
        assert o['status']=='FILLED'


def test_matched_trades_are_realized_not_unrealized():
    with tempfile.TemporaryDirectory() as d:
        l=PaperExecutionLedger(Path(d)/'p.sqlite3')
        l.submit('X','SELL',75,fill_price=100)
        l.submit('X','BUY',75,fill_price=80)
        m=l.mark_to_market({'X':90})
        assert m['realized_pnl']==1500 and m['unrealized_pnl']==0 and m['total_pnl']==1500


def test_zero_margin_is_fail_closed():
    rb=RiskBrain(); s=rb.snapshot([],{'data':{'availableMargin':0,'marginUsed':0}})
    assert rb.evaluate(s,{'side':'SELL','quantity':75,'price':100})['decision']=='BLOCK'


def test_nonfinite_json_is_rejected():
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    import threading
    t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
    try:
        req=Request(f'http://127.0.0.1:{srv.server_address[1]}/api/state',data=b'{"x":NaN}',headers={'Content-Type':'application/json'})
        try: urlopen(req,timeout=3); assert False
        except Exception as e: assert getattr(e,'code',None)==400
    finally: srv.shutdown(); srv.server_close()


def test_invalid_market_tick_is_rejected():
    class M:
        def model_dump(self): return {'last_traded_price':float('nan'),'exchange_segment':'nse_fo','instrument_token':'1'}
    try: normalize_sdk_message(M(),1); assert False
    except ValueError as e: assert str(e)=='INVALID_LTP'


def test_self_repair_rejects_dangerous_candidate_and_sandbox_isolated():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); target=root/'x.py'; target.write_text('VALUE=1\n')
        e=CodeSelfRepairEngine(root)
        dx=e.diagnose('Runtime Exception',target)
        r=e.propose_and_verify(dx,target,"import os\nos.environ['LIVE_TRADING']='true'\nVALUE=2\n")
        assert r.status=='PATCH_BLOCKED'
        if not e._sandbox_backend_available():
            pytest.skip('OS sandbox capability unavailable; isolation test is not runnable on this host')
        marker=f'v27-host-{os.getpid()}-{next(tempfile._get_candidate_names())}'
        host=Path('/tmp')/marker
        try:
            p=e._sandbox_run([sys.executable,'-c',f"open('/tmp/{marker}','w').write('sandbox')"],root,20)
            assert p.returncode==0
            assert not host.exists(), 'sandbox escaped to host filesystem'
        finally: host.unlink(missing_ok=True)

def test_multi_fill_pnl_is_quantity_correct():
    with tempfile.TemporaryDirectory() as d:
        l=PaperExecutionLedger(Path(d)/'p.sqlite3')
        l.submit('X','SELL',50,fill_price=100)
        l.submit('X','SELL',100,fill_price=120)
        l.submit('X','BUY',150,fill_price=90)
        m=l.mark_to_market({'X':90})
        assert m['realized_pnl']==3500 and m['unrealized_pnl']==0 and m['total_pnl']==3500

def test_options_intelligence_blocks_negative_oi_or_volume():
    from options_intelligence import OptionsIntelligence
    bad=[{'strike':25000,'ce':{'oi':-1,'volume':10,'ltp':100},'pe':{'oi':100,'volume':10,'ltp':100}}]
    assert OptionsIntelligence().analyze(bad,25000)['status']=='BLOCKED'
    bad=[{'strike':25000,'ce':{'oi':1,'volume':-10,'ltp':100},'pe':{'oi':100,'volume':10,'ltp':100}}]
    assert OptionsIntelligence().analyze(bad,25000)['status']=='BLOCKED'

def test_multi_fill_fifo_partial_reversal():
    with tempfile.TemporaryDirectory() as d:
        l=PaperExecutionLedger(Path(d)/'p.sqlite3')
        l.submit('X','BUY',100,fill_price=100)
        l.submit('X','SELL',150,fill_price=120)
        m=l.mark_to_market({'X':110})
        assert m['realized_pnl']==2000
        assert m['unrealized_pnl']==500
        assert m['total_pnl']==2500
