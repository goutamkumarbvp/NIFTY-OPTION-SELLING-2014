from __future__ import annotations
"""V23 Super AI Agent: bounded multi-agent decision, diagnosis and planning core.

The agent is deliberately evidence-first and policy-bounded. It can observe, diagnose,
plan and learn from supplied evidence, but it cannot place live orders, mutate code,
or bypass Risk/Safety policy. Any code repair remains delegated to the verified
self-repair subsystem.
"""
from dataclasses import dataclass, asdict
from typing import Any, Mapping, Protocol
import time, uuid

@dataclass(frozen=True)
class SpecialistReport:
    name: str
    status: str
    score: float
    findings: tuple[str, ...]
    risks: tuple[str, ...]
    missing: tuple[str, ...]

@dataclass(frozen=True)
class AgentDecision:
    decision: str
    confidence: float
    data_quality: float
    consensus: float
    evidence: list[str]
    conflicts: list[str]
    risks: list[str]
    invalidation: list[str]
    next_actions: list[str]

@dataclass(frozen=True)
class DiagnosticReport:
    severity: str
    health_score: float
    root_causes: tuple[str, ...]
    affected_components: tuple[str, ...]
    recommended_actions: tuple[str, ...]

class ReasoningProvider(Protocol):
    def summarize(self, evidence: Mapping[str, Any]) -> Mapping[str, Any]: ...

class DeterministicReasoner:
    """Offline provider: no network, no hidden LLM calls, deterministic output."""
    def summarize(self, evidence: Mapping[str, Any]) -> Mapping[str, Any]:
        return {"mode": "deterministic", "summary": f"evidence_items={len(evidence)}"}

class ExtremeSuperAgent:
    VERSION = "v23.0-super-ai-agent"
    HARD_BLOCKS = ("EMERGENCY", "PAUSED")
    MAX_HISTORY = 50
    def __init__(self, reasoner: ReasoningProvider | None = None):
        self.reasoner = reasoner or DeterministicReasoner()
        self.last: dict[str, Any] | None = None
        self.history: list[dict[str, Any]] = []
        self.learning: dict[str, int] = {}

    @staticmethod
    def _num(x, default=None):
        try: return float(x)
        except Exception: return default

    def _market_agent(self, state, regime) -> SpecialistReport:
        feed=state.get("feed") or {}; m=state.get("market") or {}
        findings=[]; risks=[]; missing=[]
        fresh=bool(feed.get("fresh")); connected=bool(feed.get("connected"))
        if connected and fresh: findings.append("Kotak SFeed connected and fresh")
        else:
            risks.append("market feed is disconnected or stale")
            if not connected: missing.append("feed connection")
            if not fresh: missing.append("fresh tick")
        rg=str(regime.get("regime",m.get("regime","UNKNOWN"))).upper()
        if rg != "UNKNOWN": findings.append(f"regime={rg}")
        else: missing.append("market regime")
        score=(1.0 if connected else 0.0)+(1.0 if fresh else 0.0)+(1.0 if rg!="UNKNOWN" else 0.0)
        return SpecialistReport("Market Intelligence Agent", "READY" if score>=3 else "WAITING", round(score/3,3), tuple(findings), tuple(risks), tuple(missing))

    def _options_agent(self, intelligence) -> SpecialistReport:
        intelligence=intelligence or {}; findings=[]; risks=[]; missing=[]
        dq=self._num(intelligence.get("data_quality",intelligence.get("quality_score")),None)
        if dq is None: missing.append("options data quality")
        else:
            dq=dq/100 if dq>1 else dq
            findings.append(f"options data quality={dq:.2f}")
            if dq<.75: risks.append("options data quality below minimum")
        pcr=self._num(intelligence.get("pcr_oi"),None)
        pcrd=self._num(intelligence.get("pcr_doi",intelligence.get("pcr_change_oi")),None)
        if pcr is None: missing.append("PCR(OI)")
        else: findings.append(f"PCR(OI)={pcr:.3f}")
        if pcrd is not None: findings.append(f"PCR(ΔOI)={pcrd:.3f}")
        else: missing.append("PCR(ΔOI)")
        score=(0 if dq is None else dq)+(1 if pcr is not None else 0)+(1 if pcrd is not None else 0)
        denom=(1 if dq is not None else 0)+(1 if pcr is not None else 0)+(1 if pcrd is not None else 0)
        denom=max(1,denom)
        return SpecialistReport("Options Intelligence Agent", "READY" if score/denom>=.75 else "WAITING", round(score/denom,3), tuple(findings), tuple(risks), tuple(missing))

    def _strategy_agent(self, plan) -> SpecialistReport:
        plan=plan or {}; cands=plan.get("candidates") or []; status=str(plan.get("status","UNKNOWN")).upper()
        findings=[]; risks=[]; missing=[]
        if cands: findings.append(f"strategy candidate={cands[0].get('type','UNKNOWN')}")
        else: missing.append("strategy candidate")
        if status in ("NO TRADE","BLOCKED"): risks.append(f"strategy status={status}")
        score=1 if cands and status not in ("NO TRADE","BLOCKED") else 0
        return SpecialistReport("Strategy Agent", "READY" if score else "WAITING", float(score), tuple(findings), tuple(risks), tuple(missing))

    def _risk_agent(self, state, advanced_risk) -> SpecialistReport:
        ar=advanced_risk or {}; findings=[]; risks=[]; missing=[]
        decision=str(ar.get("decision","UNKNOWN")).upper()
        if decision=="ALLOW": findings.append("advanced Risk Brain allows analysis")
        elif decision=="BLOCK": risks.append("Risk Brain blocks strategy")
        else: missing.append("advanced risk decision")
        safe=state.get("paper_only") is True and state.get("live_orders_enabled") is False
        if safe: findings.append("paper-only safety invariant active")
        else: risks.append("paper-only safety invariant not confirmed")
        score=(1 if decision in ("ALLOW","UNKNOWN") else 0)+(1 if safe else 0)
        return SpecialistReport("Safety & Risk Agent", "READY" if score==2 else "BLOCKED" if not safe else "WAITING", score/2, tuple(findings), tuple(risks), tuple(missing))

    def diagnose(self, state: dict[str, Any], intelligence: dict[str, Any] | None=None,
                 regime: dict[str, Any] | None=None, advanced_risk: dict[str, Any] | None=None) -> dict[str, Any]:
        state=state or {}; feed=state.get("feed") or {}; risks=[]; causes=[]; affected=[]; actions=[]
        if not feed.get("connected"): causes.append("market feed disconnected"); affected.append("market_feed"); actions.append("re-authenticate/reconnect feed")
        if not feed.get("fresh"): causes.append("market feed stale"); affected.append("market_feed"); actions.append("refresh subscription and verify fresh tick")
        intel=intelligence or {}; dq=self._num(intel.get("data_quality",intel.get("quality_score")),None)
        if dq is not None and dq>1: dq/=100
        if dq is None: causes.append("options intelligence quality unknown"); affected.append("options_intelligence"); actions.append("rebuild option-chain intelligence")
        elif dq<.75: causes.append("options data quality below threshold"); affected.append("options_intelligence"); actions.append("quarantine low-quality snapshot")
        rg=str((regime or {}).get("regime", "UNKNOWN")).upper()
        if rg=="UNKNOWN": causes.append("market regime unavailable"); affected.append("market_regime"); actions.append("recompute regime after fresh data")
        rd=str((advanced_risk or {}).get("decision","UNKNOWN")).upper()
        if rd=="BLOCK": causes.append("risk policy block"); affected.append("risk_brain"); actions.append("do not trade; resolve risk condition")
        safe=state.get("paper_only") is True and state.get("live_orders_enabled") is False
        if not safe: causes.append("paper-only safety invariant violated"); affected.append("safety_policy"); actions.append("force safe mode and disable live orders")
        severity="CRITICAL" if not safe else "HIGH" if rd=="BLOCK" else "MEDIUM" if causes else "LOW"
        health=max(0.0,1.0-min(.9,.2*len(causes)))
        return asdict(DiagnosticReport(severity,round(health,3),tuple(dict.fromkeys(causes)),tuple(dict.fromkeys(affected)),tuple(dict.fromkeys(actions))))

    def _plan(self, decision, specialists, diagnostic, candidate) -> list[dict[str, Any]]:
        if decision=="PAPER CANDIDATE":
            return [
                {"step":1,"action":"run independent Risk Brain validation","approval":"required","execution":"paper-only"},
                {"step":2,"action":"recheck feed/options freshness","approval":"automatic","execution":"read-only"},
                {"step":3,"action":"simulate candidate and record outcome","approval":"required","execution":"paper-only"},
            ]
        return [{"step":i+1,"action":a,"approval":"automatic" if i<1 else "review","execution":"read-only"} for i,a in enumerate(diagnostic.get("recommended_actions",[])[:5])]

    def run(self, state: dict[str, Any], plan: dict[str, Any] | None,
            intelligence: dict[str, Any] | None, regime: dict[str, Any] | None,
            advanced_risk: dict[str, Any] | None = None,
            events: dict[str, Any] | None = None,
            flows: dict[str, Any] | None = None) -> dict[str, Any]:
        state=state or {}; intelligence=intelligence or {}; regime=regime or {}; plan=plan or None
        specialists=[self._market_agent(state,regime),self._options_agent(intelligence),self._strategy_agent(plan),self._risk_agent(state,advanced_risk)]
        diagnostic=self.diagnose(state,intelligence,regime,advanced_risk)
        evidence=[]; conflicts=[]; risks=[]; invalidation=[]; actions=[]
        for s in specialists: evidence.extend(s.findings); conflicts.extend(s.missing); risks.extend(s.risks)
        dq=self._num(intelligence.get("data_quality",intelligence.get("quality_score")),0.0) or 0.0
        dq=dq/100 if dq>1 else max(0,min(1,dq)); candidate=bool(plan and (plan.get("candidates") or []))
        mode=str(state.get("mode","NORMAL")).upper(); safe=state.get("paper_only") is True and state.get("live_orders_enabled") is False
        risk_block=bool(advanced_risk and str(advanced_risk.get("decision","" )).upper()=="BLOCK")
        consensus=sum(s.score for s in specialists)/len(specialists)
        if not safe or mode in self.HARD_BLOCKS or not state.get("feed",{}).get("connected") or not state.get("feed",{}).get("fresh") or risk_block:
            decision="NO TRADE"
        elif not candidate: decision="NO TRADE"
        elif dq<.75 or consensus<.75 or any(x not in ("PCR(ΔOI)", "advanced risk decision") for x in conflicts): decision="REVIEW"
        else: decision="PAPER CANDIDATE"
        confidence=max(0,min(1,0.35*dq+0.35*consensus+0.30*(1-len(conflicts)/max(1,len(conflicts)+4))))
        if candidate and decision=="PAPER CANDIDATE": invalidation.append("independent Risk Brain approval and paper simulation required")
        actions=self._plan(decision,specialists,diagnostic,candidate)
        trace=str(uuid.uuid4()); result={
            "status":"READY","agent_version":self.VERSION,"autonomy":{"level":3,"name":"Planner with mandatory safety gates","live_execution":False,"code_mutation":False},
            "decision":asdict(AgentDecision(decision,round(confidence,4),round(dq,4),round(consensus,4),evidence,conflicts,risks,invalidation,[x["action"] for x in actions])),
            "specialists":[asdict(x) for x in specialists],"diagnostic":diagnostic,"action_plan":actions,
            "reasoning":dict(self.reasoner.summarize({"decision":decision,"confidence":confidence,"consensus":consensus})),
            "learning":{"prior_decisions":len(self.history),"decision_counts":dict(self.learning)},
            "policy":{"paper_only":True,"live_orders_enabled":False,"order_placement":False,"code_mutation":False,"risk_override":False},
            "trace_id":trace,"timestamp":time.time()
        }
        self.learning[decision]=self.learning.get(decision,0)+1; self.history=(self.history+[result])[-self.MAX_HISTORY:]; self.last=result
        return result
