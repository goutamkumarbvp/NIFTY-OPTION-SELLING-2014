from pathlib import Path
import re, threading, time, json
from urllib.request import urlopen, Request
from server import APP, Handler
from http.server import ThreadingHTTPServer

def test_dashboard_exists_and_is_backend_wired():
    html=Path('dashboard/index.html').read_text()
    required=['/api/refresh','/api/ai/analyze','/api/trade-plan','/api/report','/api/feed/reconnect','/api/engine/start','/api/engine/pause','/api/engine/resume','/api/engine/stop','/api/panic','/api/navigation']
    for r in required: assert r in html, r

def test_state_contract():
    s=APP.state(); assert s['api_schema_version']=='v12.0'; assert s['paper_only'] is True; assert s['live_orders_enabled'] is False

def test_all_backend_commands():
    APP.mode='NORMAL'; APP.paused=False; APP.engine_running=False
    for a in ['refresh','start','pause','resume','stop','ai','plan','report','settings','nav']:
        out=APP.command(a,{'target':'dashboard'}); assert 'ok' in out

def test_panic_fails_closed():
    APP.command('panic'); out=APP.command('start'); assert out['ok'] is False

def test_reconnect_never_fakes_success():
    APP.mode='NORMAL'; APP.feed_tokens=[]; out=APP.command('feed_reconnect'); assert out['ok'] is False

def test_http_routes():
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); port=srv.server_address[1]; t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
    try:
        assert json.loads(urlopen(f'http://127.0.0.1:{port}/api/health').read())['backend_wired'] is True
        req=Request(f'http://127.0.0.1:{port}/api/ai/analyze',data=b'{}',headers={'Content-Type':'application/json'},method='POST')
        assert json.loads(urlopen(req).read())['ok'] is True
    finally: srv.shutdown(); srv.server_close()
