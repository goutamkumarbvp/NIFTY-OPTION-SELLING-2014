# NIFTY Options Terminal V15.0

## PASS 15 — Kotak Neo credentialed read-only NIFTY pipeline

Pass 15 extends V14 from a generic read-only Kotak session into an evidence-driven NIFTY market-data pipeline.

### Added
- Defensive Kotak SDK response extraction for nested `data`/list envelopes.
- Broker-evidence NIFTY underlying token discovery through `search_scrip`.
- No hard-coded NIFTY token fallback.
- Automatic expiry discovery and NIFTY option-chain retrieval.
- CE/PE contract extraction with explicit `nse_fo` validation.
- Deduplicated SFeed subscription planning with the 3000-token ceiling.
- Live tick soak monitor: message rate, invalid ticks, duplicate/out-of-order local sequence, unique tokens, tick freshness.
- Four Pass-15 backend endpoints.
- Dashboard Pass-15 controls.
- Fixed V14 authentication wiring so the authenticated Kotak session is the same client used by the read-only market adapter/SFeed.

### Safety
- `LIVE_TRADING=true` remains rejected by the application.
- No `place_order()` definition was added.
- No `live_orders_enabled=True` path exists.
- MPIN is not accepted from browser requests.
- NIFTY tokens are never guessed.
- Real credentialed login was **not claimed** unless a local machine supplies the credentials and current TOTP.

### Verification
- Full regression: **207/207 PASS**
- Python compileall: PASS
- HTTP health: PASS
- V15 endpoint wiring: PASS
- Dashboard: 108 IDs / 73 handlers / 0 missing
- Safety static scan: PASS

### Official SDK alignment
The implementation targets the current official `kotakneoapi` 3.0.x flow: keyword-based `NeoAPI(...)`, TOTP login followed by MPIN validation, and async SFeed WebSocket subscription. The current official repository documents SFeed batching and the 3000-token subscription ceiling.

### Not claimed
No production credentialed Kotak login/SFeed soak was executed inside the build container. That requires the user's local credentials, current TOTP and network access to Kotak. The release is ready for that local read-only test.
