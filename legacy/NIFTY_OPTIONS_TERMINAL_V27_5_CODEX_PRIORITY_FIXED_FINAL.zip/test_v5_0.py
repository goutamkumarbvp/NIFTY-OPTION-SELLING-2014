from options_intelligence import OptionsIntelligence
from market_regime import MarketRegimeEngine
from advanced_risk import AdvancedRiskBrain
from strategy_brain import StrategyBrain
from risk_brain import RiskBrain
from server import TerminalBackend, Handler
from http.server import ThreadingHTTPServer
from urllib.request import urlopen, Request
from urllib.error import HTTPError
import json, threading

def chain():
    return [
      {'strike':24900,'pe':{'ltp':20,'oi':1000,'doi':200,'bid':19,'ask':21,'volume':500},'ce':{'ltp':150,'oi':300,'doi':-50,'bid':149,'ask':151,'volume':400}},
      {'strike':25000,'pe':{'ltp':30,'oi':1500,'doi':300,'bid':29,'ask':31,'volume':900},'ce':{'ltp':100,'oi':1000,'doi':50,'bid':99,'ask':101,'volume':900}},
      {'strike':25100,'pe':{'ltp':50,'oi':800,'doi':100,'bid':49,'ask':51,'volume':800},'ce':{'ltp':60,'oi':1800,'doi':200,'bid':59,'ask':61,'volume':1000}},
      {'strike':25200,'pe':{'ltp':80,'oi':500,'doi':50,'bid':79,'ask':81,'volume':500},'ce':{'ltp':30,'oi':2200,'doi':300,'bid':29,'ask':31,'volume':1000}},
    ]

def test_options_intelligence_derives_pcr_and_levels():
    x=OptionsIntelligence().analyze(chain(),25000)
    assert x['status']=='DEGRADED' and x['pcr_oi'] is not None and x['support_levels'] and x['resistance_levels']
    assert x['source']=='derived_from_option_chain'

def test_options_missing_spot_fails_closed():
    assert OptionsIntelligence().analyze(chain())['status']=='BLOCKED'

def test_regime_unknown_without_evidence():
    r=MarketRegimeEngine().classify()
    assert r['regime']=='UNKNOWN' and r['confidence']==0

def test_regime_bull_with_evidence():
    r=MarketRegimeEngine().classify(spot=25200,prev_close=25000,pcr=1.2,breadth=.7)
    assert 'BULL' in r['regime']

def test_advanced_risk_requires_liquidity():
    d=AdvancedRiskBrain().evaluate({'status':'READY'},liquidity_score=None)
    assert d['decision']=='BLOCK' and 'LIQUIDITY_EVIDENCE_REQUIRED' in d['reasons']

def test_advanced_risk_allows_paper_with_valid_evidence():
    d=AdvancedRiskBrain().evaluate({'status':'READY'},liquidity_score=.8,spread_pct=.02)
    assert d['decision']=='ALLOW_PAPER'

def test_strategy_uses_intelligence_and_liquidity():
    intel=OptionsIntelligence().analyze(chain(),25000)
    p=StrategyBrain().analyze(chain(),25000,'RANGE',intel)
    assert p['liquidity_score']<.55 and p['status']=='NO_TRADE' and p['execution']=='DISABLED'

def test_risk_malformed_account_fails_closed():
    s=RiskBrain().snapshot([],{'data':{}},0)
    d=RiskBrain().evaluate(s,{'side':'BUY','quantity':1,'price':100})
    assert d['decision']=='BLOCK' and 'INVALID_RISK_SNAPSHOT' in d['reasons']

def test_backend_v5_routes():
    app=TerminalBackend(); app.chain=chain(); app.ticks={('nse_cm','nifty 50'):type('T',(),{'trading_symbol':'Nifty 50','instrument_token':'nifty 50','ltp':25000})()}
    app.options_intelligence(); app.strategy_analyze()
    assert app.last_intelligence['status'] in {'READY','DEGRADED'}
    assert app.last_plan['execution']=='DISABLED'

def test_http_health_and_intel_route():
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); threading.Thread(target=srv.serve_forever,daemon=True).start()
    try:
        h=json.loads(urlopen(f'http://127.0.0.1:{srv.server_address[1]}/api/health').read())
        assert h['api_schema_version']=='v12.0' and h['live_orders_enabled'] is False
        req=Request(f'http://127.0.0.1:{srv.server_address[1]}/api/intelligence/options',data=b'{}',headers={'Content-Type':'application/json'})
        try:
            urlopen(req).read(); assert False
        except HTTPError as e:
            out=json.loads(e.read()); assert 'intelligence' in out and out['ok'] is False
    finally: srv.shutdown(); srv.server_close()
