#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON_BIN:-python3}"
if [[ ! -x .venv/bin/python ]]; then
  "$PYTHON_BIN" -m venv .venv
fi
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
export TRADING_MODE=paper
export LIVE_TRADING=false
export LIVE_ORDERS_ENABLED=false
export BIND_HOST="${BIND_HOST:-127.0.0.1}"
export PORT="${PORT:-8500}"
exec .venv/bin/python server.py
