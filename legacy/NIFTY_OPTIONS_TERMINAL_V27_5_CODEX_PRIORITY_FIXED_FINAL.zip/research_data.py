from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime
from math import isfinite
from pathlib import Path
import csv, json, threading

@dataclass(frozen=True)
class Bar:
    timestamp: str
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0

class HistoricalDataValidator:
    @staticmethod
    def validate(rows):
        if not isinstance(rows,list) or len(rows)<2: return {'status':'BLOCKED','reason':'INSUFFICIENT_ROWS'}
        out=[]; prev=None
        for r in rows:
            try:
                ts=str(r['timestamp']); dt=datetime.fromisoformat(ts.replace('Z','+00:00'))
                vals=[float(r[k]) for k in ('open','high','low','close')]; vol=float(r.get('volume',0))
                if not all(isfinite(x) for x in vals+[vol]) or min(vals)<=0 or vol<0: raise ValueError
                o,h,l,c=vals
                if h<max(o,c) or l>min(o,c) or l<=0: return {'status':'BLOCKED','reason':'INVALID_OHLC'}
                if prev is not None and dt<=prev: return {'status':'BLOCKED','reason':'NON_MONOTONIC_TIMESTAMP'}
                prev=dt; out.append(asdict(Bar(ts,o,h,l,c,vol)))
            except (KeyError,TypeError,ValueError,OverflowError): return {'status':'BLOCKED','reason':'INVALID_BAR'}
        return {'status':'READY','rows':out,'count':len(out)}

class HistoricalDataStore:
    """Atomic JSONL research store; never silently overwrites a dataset."""
    def __init__(self, root='runtime/research_data'):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True); self.lock=threading.Lock()
    def ingest(self, dataset, rows, metadata=None):
        chk=HistoricalDataValidator.validate(rows)
        if chk['status']!='READY': return chk
        name=''.join(c for c in str(dataset) if c.isalnum() or c in ('_','-')) or 'dataset'
        path=self.root/(name+'.jsonl')
        with self.lock:
            if path.exists(): return {'status':'BLOCKED','reason':'DATASET_EXISTS','path':str(path)}
            tmp=path.with_suffix('.tmp')
            with tmp.open('w',encoding='utf-8') as f:
                for r in chk['rows']: f.write(json.dumps(r,separators=(',',':'))+'\n')
                f.flush()
            tmp.replace(path)
        return {'status':'READY','dataset':name,'path':str(path),'rows':chk['count'],'metadata':metadata or {}}
    def read(self,dataset):
        name=''.join(c for c in str(dataset) if c.isalnum() or c in ('_','-')) or 'dataset'; path=self.root/(name+'.jsonl')
        if not path.exists(): return {'status':'BLOCKED','reason':'DATASET_NOT_FOUND'}
        rows=[json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
        return HistoricalDataValidator.validate(rows)


class HistoricalOptionChainValidator:
    """Validate normalized historical option-chain snapshots without inventing missing quotes."""
    REQUIRED=('timestamp','spot','expiry','contracts')
    @staticmethod
    def validate(snapshots):
        if not isinstance(snapshots,list) or len(snapshots)<1: return {'status':'BLOCKED','reason':'NO_OPTION_CHAIN_SNAPSHOTS'}
        prev=None; count=0
        for snap in snapshots:
            try:
                dt=datetime.fromisoformat(str(snap['timestamp']).replace('Z','+00:00')); spot=float(snap['spot']); expiry=str(snap['expiry']); contracts=snap['contracts']
                if not isfinite(spot) or spot<=0 or not expiry or not isinstance(contracts,list) or not contracts: raise ValueError
                if prev is not None and dt<=prev:return {'status':'BLOCKED','reason':'NON_MONOTONIC_TIMESTAMP'}
                prev=dt
                for c in contracts:
                    if not c.get('symbol') or c.get('option_type') not in ('CE','PE') or float(c.get('strike',0))<=0: return {'status':'BLOCKED','reason':'INVALID_CONTRACT'}
                    if c.get('expiry') is not None and str(c.get('expiry')) != expiry: return {'status':'BLOCKED','reason':'EXPIRY_MISMATCH'}
                    try:
                        datetime.fromisoformat(expiry.replace('Z','+00:00')) if 'T' in expiry else datetime.fromisoformat(expiry)
                        oi=float(c.get('oi',0)); volume=float(c.get('volume',0))
                    except (TypeError,ValueError,OverflowError): return {'status':'BLOCKED','reason':'INVALID_CONTRACT_METADATA'}
                    if not all(isfinite(x) and x>=0 for x in (oi,volume)): return {'status':'BLOCKED','reason':'INVALID_CONTRACT_METADATA'}
                    for q in ('bid','ask'):
                        v=float(c[q])
                        if not isfinite(v) or v<=0:return {'status':'BLOCKED','reason':'INVALID_QUOTE'}
                    if float(c['ask'])<float(c['bid']):return {'status':'BLOCKED','reason':'CROSSED_QUOTE'}
                    count+=1
            except (KeyError,TypeError,ValueError,OverflowError): return {'status':'BLOCKED','reason':'INVALID_OPTION_CHAIN_SNAPSHOT'}
        return {'status':'READY','snapshots':len(snapshots),'contracts':count,'schema':'timestamp,spot,expiry,contracts[{symbol,option_type,strike,bid,ask,oi,volume,instrument_token}]'}
