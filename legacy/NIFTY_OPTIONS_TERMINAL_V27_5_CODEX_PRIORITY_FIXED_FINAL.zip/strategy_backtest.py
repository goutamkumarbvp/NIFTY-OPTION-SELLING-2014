from __future__ import annotations
from dataclasses import dataclass
from math import isfinite
from statistics import mean, pstdev
from itertools import product
from random import Random

@dataclass(frozen=True)
class StrategyLeg:
    symbol: str
    option_type: str  # CE/PE
    strike: float
    side: int          # +1 buy, -1 sell
    qty: int
    lot_size: int = 75

@dataclass(frozen=True)
class StrategyBacktestConfig:
    initial_capital: float = 1_000_000.0
    fee_per_lot: float = 20.0
    slippage_pct: float = 0.001
    margin_rate: float = 0.20
    max_margin_utilization: float = 0.80
    risk_free_rate: float = 0.0

class MultiLegStrategyBacktester:
    """Expiry-aware multi-leg option simulator. No fills are invented: every leg needs bid/ask."""
    def __init__(self, config=None): self.config=config or StrategyBacktestConfig()
    @staticmethod
    def _valid_leg(l):
        return isinstance(l, dict) and l.get('option_type') in ('CE','PE') and l.get('side') in (-1,1) and float(l.get('strike',0))>0 and int(l.get('qty',0))>0 and int(l.get('lot_size',0))>0 and bool(l.get('symbol'))
    def _quote(self, quotes, leg):
        key=f"{leg['symbol']}|{leg['option_type']}|{float(leg['strike']):g}"
        q=quotes.get(key, quotes.get(leg['symbol'])) if isinstance(quotes,dict) else None
        if not isinstance(q,dict): return None
        try: bid,ask=float(q['bid']),float(q['ask'])
        except (KeyError,TypeError,ValueError): return None
        if not all(isfinite(x) and x>0 for x in (bid,ask)) or ask<bid: return None
        return bid,ask
    def _fill(self, q, side):
        bid,ask=q
        return (ask*(1+self.config.slippage_pct)) if side==1 else (bid*(1-self.config.slippage_pct))
    def _margin(self, legs, prices):
        gross=sum(abs(l['qty']*l['lot_size']*p) for l,p in zip(legs,prices))
        short=sum(l['qty']*l['lot_size']*p for l,p in zip(legs,prices) if l['side']<0)
        return max(0.0, gross*self.config.margin_rate + short*0.10)
    def _expiry_payoff(self, legs, spot):
        total=0.0
        for l in legs:
            intrinsic=max(spot-l['strike'],0.0) if l['option_type']=='CE' else max(l['strike']-spot,0.0)
            total += l['side']*intrinsic*l['qty']*l['lot_size']
        return total
    def run(self, bars, legs, entry_index=0, expiry_index=None, capital=None):
        c=self.config; cap=c.initial_capital if capital is None else float(capital)
        if not isinstance(bars,list) or len(bars)<2 or not isinstance(legs,list) or not legs: return {'status':'BLOCKED','reason':'INVALID_INPUT'}
        if any(not self._valid_leg(l) for l in legs): return {'status':'BLOCKED','reason':'INVALID_LEG'}
        if not all(isfinite(cap) and cap>0 for _ in [cap]): return {'status':'BLOCKED','reason':'INVALID_CAPITAL'}
        if entry_index<0 or entry_index>=len(bars)-1: return {'status':'BLOCKED','reason':'INVALID_ENTRY_INDEX'}
        expiry_index=len(bars)-1 if expiry_index is None else int(expiry_index)
        if expiry_index<=entry_index or expiry_index>=len(bars): return {'status':'BLOCKED','reason':'INVALID_EXPIRY_INDEX'}
        entry_bar=bars[entry_index+1]; entry_prices=[]
        for l in legs:
            q=self._quote(entry_bar.get('quotes'),l)
            if q is None:return {'status':'BLOCKED','reason':'MISSING_OR_INVALID_BID_ASK','leg':l}
            entry_prices.append(self._fill(q,l['side']))
        margin=self._margin(legs,entry_prices)
        if margin > cap*c.max_margin_utilization:return {'status':'BLOCKED','reason':'MARGIN_UTILIZATION_LIMIT','required_margin':margin}
        entry_cost=sum(l['side']*p*l['qty']*l['lot_size'] for l,p in zip(legs,entry_prices))
        fees=sum(abs(l['qty']) for l in legs)*c.fee_per_lot
        expiry=bars[expiry_index]
        try: spot=float(expiry['spot'])
        except (KeyError,TypeError,ValueError): return {'status':'BLOCKED','reason':'EXPIRY_SPOT_REQUIRED'}
        if not isfinite(spot) or spot<=0:return {'status':'BLOCKED','reason':'INVALID_EXPIRY_SPOT'}
        payoff=self._expiry_payoff(legs,spot)
        pnl=payoff-entry_cost-fees
        return {'status':'READY','strategy_legs':legs,'entry_index':entry_index+1,'expiry_index':expiry_index,'entry_prices':entry_prices,'entry_cashflow':-entry_cost,'expiry_spot':spot,'expiry_payoff':payoff,'fees':fees,'required_margin':margin,'pnl':pnl,'final_capital':cap+pnl,'return_pct':pnl/cap*100,'fill_rule':'signal at t fills at t+1 bid/ask','lookahead_protection':True,'expiry_aware':True}

class StrategyOptimizer:
    """Small deterministic grid optimizer. Optimizes only on supplied training data; no hidden data."""
    def __init__(self, backtester=None): self.bt=backtester or MultiLegStrategyBacktester()
    def grid(self, bars, candidate_legs, parameter_grid):
        if not isinstance(candidate_legs,list) or not parameter_grid:return {'status':'BLOCKED','reason':'INVALID_OPTIMIZATION_INPUT'}
        keys=list(parameter_grid); vals=[parameter_grid[k] for k in keys]
        if any(not isinstance(v,list) or not v for v in vals):return {'status':'BLOCKED','reason':'INVALID_PARAMETER_GRID'}
        results=[]
        for combo in product(*vals):
            params=dict(zip(keys,combo)); legs=[]
            for raw in candidate_legs:
                x=dict(raw)
                for k,v in params.items():
                    if k in x:x[k]=v
                legs.append(x)
            out=self.bt.run(bars,legs)
            if out['status']=='READY': results.append({'params':params,'pnl':out['pnl'],'return_pct':out['return_pct'],'margin':out['required_margin']})
        if not results:return {'status':'BLOCKED','reason':'NO_VALID_CANDIDATE'}
        results.sort(key=lambda x:(x['pnl'],x['return_pct']),reverse=True)
        return {'status':'READY','evaluated':len(results),'best':results[0],'results':results[:100]}

def robustness(pnls):
    if not pnls or any(not isinstance(x,(int,float)) or not isfinite(x) for x in pnls): return {'status':'BLOCKED','reason':'INVALID_PNL_SAMPLE'}
    wins=sum(x>0 for x in pnls); avg=mean(pnls); sd=pstdev(pnls) if len(pnls)>1 else 0.0
    return {'status':'READY','trades':len(pnls),'win_rate':wins/len(pnls),'mean_pnl':avg,'pnl_stddev':sd,'profit_factor':sum(x for x in pnls if x>0)/abs(sum(x for x in pnls if x<0)) if any(x<0 for x in pnls) else float('inf'),'robust':wins/len(pnls)>=0.5 and avg>0}

def monte_carlo_validate(pnls, paths=2000, seed=17):
    if not isinstance(pnls,list) or len(pnls)<5 or any(not isinstance(x,(int,float)) or not isfinite(x) for x in pnls):
        return {'status':'BLOCKED','reason':'INSUFFICIENT_OR_INVALID_PNL_SAMPLE'}
    if not isinstance(paths,int) or paths<100 or paths>100000: return {'status':'BLOCKED','reason':'INVALID_PATHS'}
    r=Random(seed); totals=[sum(r.choice(pnls) for _ in pnls) for _ in range(paths)]; totals.sort(); i=max(0,int(.05*paths)-1)
    return {'status':'READY','paths':paths,'seed':seed,'mean_pnl':mean(totals),'p05_pnl':totals[i],'median_pnl':totals[len(totals)//2],'worst_pnl':totals[0],'profit_probability':sum(x>0 for x in totals)/paths,'loss_probability':sum(x<0 for x in totals)/paths}
