from __future__ import annotations
from dataclasses import dataclass
from random import Random
from statistics import mean
from math import sqrt

@dataclass(frozen=True)
class StressConfig:
    price_shock_pct:float=0.03
    vol_shock_pct:float=0.25
    paths:int=1000
    seed:int=7

class StressEngine:
    def __init__(self,config=None): self.config=config or StressConfig()
    def deterministic(self, pnl, delta=0, gamma=0, vega=0, theta=0, price=0, vol=0, dt=1/365):
        c=self.config
        if any(x!=x for x in (pnl,delta,gamma,vega,theta)): return {'status':'BLOCKED','reason':'INVALID_INPUT'}
        up=price*c.price_shock_pct if price else 0; dv=vol*c.vol_shock_pct if vol else 0
        shocks=[]
        for s in (-1,1):
            dp=s*up; shocks.append({'direction':s,'estimated_pnl':pnl+delta*dp+0.5*gamma*dp*dp+vega*(s*dv)+theta*dt})
        return {'status':'READY','scenarios':shocks,'worst_case':min(x['estimated_pnl'] for x in shocks)}
    def monte_carlo(self, trade_pnls):
        if not trade_pnls or any(not isinstance(x,(int,float)) for x in trade_pnls): return {'status':'BLOCKED','reason':'NO_PNL_SAMPLE'}
        r=Random(self.config.seed); paths=max(100,self.config.paths); totals=[]
        for _ in range(paths): totals.append(sum(r.choice(trade_pnls) for _ in trade_pnls))
        totals.sort(); idx=max(0,int(.05*len(totals))-1)
        return {'status':'READY','paths':paths,'seed':self.config.seed,'mean_pnl':mean(totals),'p05_pnl':totals[idx],'worst_pnl':totals[0],'loss_probability':sum(x<0 for x in totals)/len(totals)}
