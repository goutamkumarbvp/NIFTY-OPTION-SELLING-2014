from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable
import hashlib, json, sqlite3, threading, time, uuid

@dataclass(frozen=True)
class AgentMemory:
    memory_id: str
    kind: str
    key: str
    value: dict[str, Any]
    created_at: float

class AgentMemoryStore:
    """Durable, bounded agent memory. No credentials or raw secrets should be stored."""
    SECRET_WORDS = ("password", "mpin", "totp", "secret", "consumer_key", "api_key", "token")
    def __init__(self, path: str | Path, max_items: int = 2000):
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.max_items=max_items; self.lock=threading.RLock()
        with sqlite3.connect(self.path) as c:
            c.execute("CREATE TABLE IF NOT EXISTS memory(id TEXT PRIMARY KEY, kind TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, created REAL NOT NULL)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_memory_key ON memory(kind,key,created DESC)")
            c.commit()
    @classmethod
    def _safe(cls, obj: Any) -> Any:
        if isinstance(obj, dict):
            out={}
            for k,v in obj.items():
                lk=str(k).lower()
                if any(w in lk for w in cls.SECRET_WORDS): out[str(k)]="[REDACTED]"
                else: out[str(k)]=cls._safe(v)
            return out
        if isinstance(obj, list): return [cls._safe(x) for x in obj]
        return obj
    def put(self, kind: str, key: str, value: dict[str,Any]) -> AgentMemory:
        m=AgentMemory(str(uuid.uuid4()), str(kind), str(key), self._safe(value), time.time())
        with self.lock, sqlite3.connect(self.path) as c:
            c.execute("INSERT INTO memory VALUES(?,?,?,?,?)",(m.memory_id,m.kind,m.key,json.dumps(m.value,sort_keys=True),m.created_at))
            c.execute("DELETE FROM memory WHERE id IN (SELECT id FROM memory ORDER BY created ASC LIMIT MAX(0,(SELECT COUNT(*) FROM memory)-?))",(self.max_items,))
            c.commit()
        return m
    def recent(self, kind: str|None=None, limit: int=20) -> list[dict[str,Any]]:
        limit=max(1,min(int(limit),100))
        q="SELECT id,kind,key,value,created FROM memory"; args=[]
        if kind: q+=" WHERE kind=?"; args.append(kind)
        q+=f" ORDER BY created DESC LIMIT {limit}"
        with self.lock, sqlite3.connect(self.path) as c:
            rows=c.execute(q,args).fetchall()
        return [{"memory_id":r[0],"kind":r[1],"key":r[2],"value":json.loads(r[3]),"created_at":r[4]} for r in rows]

@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    risk: str
    callable: bool = True

class AgentToolRegistry:
    """Allow-listed read/research tools. Never exposes order placement or code mutation."""
    FORBIDDEN = ("order", "execute", "cancel", "modify", "withdraw", "code", "shell", "eval", "exec")
    def __init__(self): self._tools: dict[str, tuple[ToolSpec,Callable[...,Any]]] = {}
    def register(self, name: str, description: str, fn: Callable[...,Any], risk: str="READ_ONLY") -> None:
        n=str(name).strip().lower()
        if not n or any(x in n for x in self.FORBIDDEN): raise ValueError("FORBIDDEN_TOOL_NAME")
        if not callable(fn): raise TypeError("TOOL_NOT_CALLABLE")
        self._tools[n]=(ToolSpec(n,description,risk,True),fn)
    def list(self) -> list[dict[str,Any]]: return [asdict(x[0]) for x in self._tools.values()]
    def call(self, name: str, **kwargs) -> Any:
        n=str(name).lower()
        if n not in self._tools: raise KeyError("TOOL_NOT_ALLOWLISTED")
        spec,fn=self._tools[n]
        if spec.risk.upper() not in ("READ_ONLY","RESEARCH"): raise PermissionError("TOOL_RISK_BLOCKED")
        return fn(**kwargs)

@dataclass(frozen=True)
class Hypothesis:
    hypothesis_id: str
    thesis: str
    evidence: tuple[str,...]
    confidence: float
    falsifiers: tuple[str,...]

class HypothesisEngine:
    def generate(self, intelligence: dict[str,Any], regime: dict[str,Any], plan: dict[str,Any]|None) -> list[Hypothesis]:
        hyps=[]; rg=str(regime.get("regime","UNKNOWN")).upper(); pcr=intelligence.get("pcr_oi")
        evidence=[]
        if rg!="UNKNOWN": evidence.append(f"regime={rg}")
        if pcr is not None: evidence.append(f"PCR(OI)={float(pcr):.3f}")
        if not evidence: return []
        if rg in ("RANGE","NEUTRAL"):
            hyps.append(Hypothesis(str(uuid.uuid4()),"Range-bound premium selling may be suitable",tuple(evidence),0.65,("regime breaks","IV/liquidity deteriorates")))
        elif rg=="BULL":
            hyps.append(Hypothesis(str(uuid.uuid4()),"Bullish regime may favor downside-defined premium structures",tuple(evidence),0.65,("trend reversal","risk block")))
        elif rg=="BEAR":
            hyps.append(Hypothesis(str(uuid.uuid4()),"Bearish regime may favor upside-defined premium structures",tuple(evidence),0.65,("trend reversal","risk block")))
        if plan and plan.get("candidates"):
            hyps[0]=Hypothesis(hyps[0].hypothesis_id,hyps[0].thesis,hyps[0].evidence+tuple(["strategy candidate exists"]),hyps[0].confidence,hyps[0].falsifiers)
        return hyps

class AdversarialCritic:
    def review(self, hypothesis: Hypothesis, data_quality: float, risk: dict[str,Any]|None, feed_fresh: bool) -> dict[str,Any]:
        attacks=[]
        if data_quality<0.75: attacks.append("data quality below minimum")
        if not feed_fresh: attacks.append("feed freshness unconfirmed")
        if risk and str(risk.get("decision","")).upper()=="BLOCK": attacks.append("risk brain blocks projected trade")
        attacks.extend(hypothesis.falsifiers)
        penalty=min(0.9,0.25*sum(x in ("data quality below minimum","feed freshness unconfirmed","risk brain blocks projected trade") for x in attacks))
        return {"verdict":"REJECT" if penalty>=0.5 else ("CAUTION" if penalty else "PASS"),"attacks":attacks,"confidence_after_critique":round(max(0.0,hypothesis.confidence-penalty),4)}

class AgentEvaluator:
    def evaluate(self, decision: str, confidence: float, data_quality: float, critic_verdict: str, missing: list[str]) -> dict[str,Any]:
        score=0.4*confidence+0.4*data_quality+(0.2 if critic_verdict=="PASS" else 0.1 if critic_verdict=="CAUTION" else 0.0)
        return {"quality_score":round(score,4),"decision_consistent":not(decision=="PAPER CANDIDATE" and (critic_verdict=="REJECT" or data_quality<0.75)),"missing_evidence":missing}

class Pass17Agent:
    VERSION="v17.0-agentic-research-core"
    def __init__(self, memory_path: str|Path):
        self.memory=AgentMemoryStore(memory_path); self.tools=AgentToolRegistry(); self.hypotheses=HypothesisEngine(); self.critic=AdversarialCritic(); self.evaluator=AgentEvaluator(); self.last=None; self.lock=threading.RLock()
    def register_default_tools(self, context: dict[str,Any]):
        self.tools.register("read_market_state","Read supplied market state",lambda: context.get("state",{}),"READ_ONLY")
        self.tools.register("read_options_intelligence","Read supplied options intelligence",lambda: context.get("intelligence",{}),"READ_ONLY")
        self.tools.register("read_strategy_plan","Read supplied strategy plan",lambda: context.get("plan") or {},"RESEARCH")
    def run(self, context: dict[str,Any]) -> dict[str,Any]:
        with self.lock:
            state=context.get("state") or {}; intel=context.get("intelligence") or {}; regime=context.get("regime") or {}; plan=context.get("plan") or None; risk=context.get("advanced_risk") or None
            feed=state.get("feed") or {}; dq=float(intel.get("data_quality",intel.get("quality_score",0)) or 0); dq=dq/100 if dq>1 else dq
            missing=[]
            if not feed.get("connected"): missing.append("feed connection")
            if not feed.get("fresh"): missing.append("fresh ticks")
            if not intel: missing.append("options intelligence")
            if not regime or str(regime.get("regime","UNKNOWN")).upper()=="UNKNOWN": missing.append("market regime")
            hyps=self.hypotheses.generate(intel,regime,plan)
            reviews=[self.critic.review(h,dq,risk,bool(feed.get("fresh"))) for h in hyps]
            best=reviews[0] if reviews else {"verdict":"REJECT","attacks":["no hypothesis"],"confidence_after_critique":0}
            candidate=bool(plan and plan.get("candidates"))
            hard_safe=state.get("paper_only") is True and state.get("live_orders_enabled") is False
            if not hard_safe or missing or (risk and str(risk.get("decision","")).upper()=="BLOCK") or not candidate:
                decision="NO TRADE"
            elif best["verdict"]=="REJECT" or dq<0.75: decision="REVIEW"
            else: decision="PAPER CANDIDATE"
            conf=best["confidence_after_critique"]
            evaluation=self.evaluator.evaluate(decision,conf,dq,best["verdict"],missing)
            result={"status":"READY","version":self.VERSION,"decision":decision,"confidence":round(conf,4),"data_quality":round(dq,4),"hypotheses":[asdict(h) for h in hyps],"critic":best,"evaluation":evaluation,"tools":self.tools.list(),"memory_count":len(self.memory.recent(limit=100)),"policy":{"paper_only":True,"live_orders_enabled":False,"order_placement":False,"code_mutation":False},"trace_id":str(uuid.uuid4()),"timestamp":time.time()}
            self.memory.put("decision",result["trace_id"],{"decision":decision,"confidence":conf,"data_quality":dq,"critic":best["verdict"]})
            self.last=result; return result
