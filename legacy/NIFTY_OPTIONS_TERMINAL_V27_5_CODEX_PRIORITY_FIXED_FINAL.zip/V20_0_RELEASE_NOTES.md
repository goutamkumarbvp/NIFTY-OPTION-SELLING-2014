# V20.0 Release Notes — Application Service Decomposition

V20 converts the V19 composition-heavy backend into explicit application service boundaries while retaining the existing public backend facade.

### Services
- MarketService: Kotak/read-only feed, option chain, quotes, positions, feed lifecycle.
- IntelligenceService: Risk, strategy, options intelligence, quant, volatility and market intelligence.
- ResearchService: V10–V13 data/replay/backtest/research engines.
- AiService: Super AI, Pass17 agentic layer, alerts and verified code self-repair.

### Safety
`LIVE_TRADING` remains disabled and no order-placement capability is introduced by V20.

### Verification
285/285 tests pass.
