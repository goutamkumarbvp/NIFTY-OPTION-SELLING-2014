import json, threading
from urllib.request import urlopen, Request
from http.server import ThreadingHTTPServer
from server import APP, Handler
from market_intelligence import build_chain, chain_metrics, chain_feed_tokens

class FakeAdapter:
    def authenticate(self,totp,mpin): return {'login_status':'OK','validate_status':'OK'}
    def expiries(self,exchange_segment='nse_fo',instrument_token=None): return {'stat':'Ok','data':['2026-09-17','2026-09-24']}
    def option_chain(self,*a,**k):
        return {'data':[{'strike_price':25000,'option_type':'CE','instrument_token':'101','last_traded_price':100,'open_interest':1000,'change_in_oi':100,'implied_volatility':12.5},{'strike_price':25000,'option_type':'PE','instrument_token':'102','last_traded_price':90,'open_interest':1200,'change_in_oi':200,'implied_volatility':13.1},{'strike_price':25100,'option_type':'CE','instrument_token':'103','last_traded_price':55,'open_interest':500,'change_in_oi':50},{'strike_price':25100,'option_type':'PE','instrument_token':'104','last_traded_price':130,'open_interest':700,'change_in_oi':70}]}
    def quotes(self,tokens): return {'stat':'Ok','data':tokens}

def test_chain_metrics_and_tokens():
    c=build_chain(FakeAdapter().option_chain()); m=chain_metrics(c); t=chain_feed_tokens(c)
    assert len(c)==2 and abs(m['pcr_oi']-(1900/1500))<1e-9 and len(t)==4

def test_auth_chain_auto_feed_preparation():
    APP.adapter=FakeAdapter(); APP.authenticated=True
    out=APP.command('chain',{'instrument_token':'NIFTY','expiry':'2026-09-17'}); assert out['ok'] and out['feed_tokens']==4 and len(APP.feed_tokens)==4
    APP.adapter=None; APP.authenticated=False; APP.chain=[]; APP.feed_tokens=[]

def test_subscription_limit_guard():
    APP.adapter=FakeAdapter(); APP.authenticated=True
    out=APP.command('feed_start',{'tokens':[{'exchange_segment':'nse_fo','instrument_token':str(i)} for i in range(3001)]})
    assert not out['ok'] and '3000' in out['error']
    APP.adapter=None; APP.authenticated=False

def test_state_has_no_synthetic_market_values():
    s=APP.state(); assert s['api_schema_version']=='v12.0'; assert s['market']['nifty'] is None or isinstance(s['market']['nifty'],float); assert s['market']['vix'] is None; assert s['risk']['live_execution']=='DISABLED'

def test_http_health_and_route_wiring():
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); port=srv.server_address[1]; t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
    try:
        h=json.loads(urlopen(f'http://127.0.0.1:{port}/api/health').read()); assert h['api_schema_version']=='v12.0' and h['real_kotak_path'] and h['option_chain_auto_feed']
        st=json.loads(urlopen(f'http://127.0.0.1:{port}/api/state').read()); assert st['state']['api_schema_version']=='v12.0'
    finally:srv.shutdown();srv.server_close()
