import unittest
from super_ai_agent import ExtremeSuperAgent

class TestV16(unittest.TestCase):
    def setUp(self): self.a=ExtremeSuperAgent()
    def base(self):
        return ({'mode':'NORMAL','paper_only':True,'live_orders_enabled':False,'feed':{'connected':True,'fresh':True}},
                {'status':'TRADE','candidates':[{'type':'IRON_CONDOR','risk_gate_required':True}]},
                {'status':'READY','data_quality':0.95,'pcr_oi':1.1}, {'regime':'RANGE','confidence':0.8})
    def test_paper_candidate(self):
        s,p,i,r=self.base(); x=self.a.run(s,p,i,r); self.assertEqual(x['decision']['decision'],'PAPER CANDIDATE'); self.assertFalse(x['policy']['order_placement'])
    def test_stale_feed_blocks(self):
        s,p,i,r=self.base(); s['feed']['fresh']=False; x=self.a.run(s,p,i,r); self.assertEqual(x['decision']['decision'],'NO TRADE')
    def test_live_flag_blocks(self):
        s,p,i,r=self.base(); s['live_orders_enabled']=True; x=self.a.run(s,p,i,r); self.assertEqual(x['decision']['decision'],'NO TRADE')
    def test_emergency_blocks(self):
        s,p,i,r=self.base(); s['mode']='EMERGENCY'; x=self.a.run(s,p,i,r); self.assertEqual(x['decision']['decision'],'NO TRADE')
    def test_low_quality_review(self):
        s,p,i,r=self.base(); i['data_quality']=0.4; x=self.a.run(s,p,i,r); self.assertIn(x['decision']['decision'],('REVIEW','NO TRADE'))
    def test_risk_block(self):
        s,p,i,r=self.base(); x=self.a.run(s,p,i,r,{'decision':'BLOCK'}); self.assertEqual(x['decision']['decision'],'NO TRADE')
    def test_no_candidate(self):
        s,p,i,r=self.base(); x=self.a.run(s,None,i,r); self.assertEqual(x['decision']['decision'],'NO TRADE')
    def test_no_code_mutation(self):
        s,p,i,r=self.base(); x=self.a.run(s,p,i,r); self.assertFalse(x['policy']['code_mutation'])
    def test_history_bounded(self):
        s,p,i,r=self.base(); [self.a.run(s,p,i,r) for _ in range(60)]; self.assertLessEqual(len(self.a.history),50)
    def test_confidence_not_probability(self):
        s,p,i,r=self.base(); x=self.a.run(s,p,i,r); self.assertIn('confidence',x['decision']); self.assertNotIn('profit_probability',x['decision'])
if __name__=='__main__': unittest.main()
