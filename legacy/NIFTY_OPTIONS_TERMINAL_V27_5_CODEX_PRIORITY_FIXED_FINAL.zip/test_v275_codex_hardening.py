import tempfile
from pathlib import Path
import pytest
from quant_engine import QuantEngine
from self_repair import CodeSelfRepairEngine
from security_verifier import verify_tree


def test_extreme_bs_inputs_fail_closed():
    q=QuantEngine()
    with pytest.raises(ValueError, match='INVALID_BS_INPUT'):
        q.greeks(100,100,1,-1000,0.2)
    assert q.implied_vol(10,100,100,1,-1000) is None

@pytest.mark.parametrize('src', [
    "VALUE=__builtins__['open']('/tmp/x','w')",
    "VALUE=getattr(__builtins__,'open')('/tmp/x','w')",
    "VALUE=__import__('subprocess')",
    "VALUE=globals()",
    "VALUE=locals()",
    "VALUE=object.__subclasses__()",
])
def test_independent_security_verifier_blocks_reflection(src):
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); (root/'x.py').write_text(src)
        r=verify_tree(root, candidate_files=['x.py'])
        assert not r['ok']


def test_patch_size_gate():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); target=root/'x.py'; target.write_text('VALUE=1\n')
        e=CodeSelfRepairEngine(root)
        dx=e.diagnose('Runtime Exception', target)
        result=e.propose_and_verify(dx,target,'VALUE=2\n'+'x'*130000)
        assert result.status=='PATCH_BLOCKED'
        assert 'PATCH_TOO_LARGE' in result.message

def test_normalizer_rejects_negative_counts():
    from market_intelligence import normalize_option_chain
    payload=[{'strike':25000,'option_type':'CE','open_interest':-1,'volume':100,'ltp':10},
             {'strike':25000,'option_type':'PE','open_interest':100,'volume':-1,'ltp':10}]
    assert normalize_option_chain(payload)==[]


def test_risk_snapshot_invalid_position_fails_closed():
    from risk_brain import RiskBrain
    r = RiskBrain()
    snap = r.snapshot([{'quantity':'CORRUPTED','averagePrice':100}], {'availableMargin':100000,'marginUsed':0}, 0)
    decision = r.evaluate(snap, {'quantity':1,'price':100,'side':'BUY'})
    assert decision['decision'] == 'BLOCK'
    assert 'INVALID_RISK_SNAPSHOT' in decision['reasons']


def test_report_version_is_current():
    from terminal_backend import TerminalBackend
    b = TerminalBackend()
    out = b.command('report', {})
    assert out['report']['version'] == 'v27.5'


def test_repair_provider_exception_fails_closed():
    import tempfile
    from pathlib import Path
    from self_repair import CodeSelfRepairEngine
    class FailingProvider:
        def propose(self, *args):
            raise TimeoutError('provider unavailable')
    with tempfile.TemporaryDirectory() as d:
        root = Path(d); target = root/'x.py'; target.write_text('VALUE=1\n')
        e = CodeSelfRepairEngine(root, provider=FailingProvider())
        result = e.propose_and_verify(e.diagnose('Runtime Exception', target), target, None)
        assert result.status == 'PROVIDER_ERROR'
        assert target.read_text() == 'VALUE=1\n'
