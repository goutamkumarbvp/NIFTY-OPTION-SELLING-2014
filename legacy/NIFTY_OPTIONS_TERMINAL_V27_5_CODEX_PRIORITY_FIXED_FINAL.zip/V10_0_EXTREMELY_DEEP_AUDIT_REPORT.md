# PASS 10 — Extremely Deep Audit Report

## Verdict
**PASS — V10.0 research-data foundation verified.**

This pass deliberately stops before live execution. It hardens the historical-data boundary so later strategy/backtest results cannot silently use guessed contract identity or malformed quotes.

## Findings and repairs

### DATA-01 — Contract identity must be explicit
**Risk:** a historical row without a broker/exchange identity can be accidentally mapped to the wrong option contract.
**Repair:** `ContractMapper` requires symbol, instrument token, exchange segment, underlying, expiry, strike, option type, lot size and tick size. Missing or invalid identity returns no mapping.

### DATA-02 — Timestamp ambiguity
**Risk:** naive timestamps can shift the market session.
**Repair:** naive timestamps are explicitly interpreted as IST; aware timestamps are normalized to IST.

### DATA-03 — Session/calendar boundary
**Risk:** research can accidentally accept weekend or outside-session observations.
**Repair:** `NSECalendar` blocks weekends, supports supplied holidays, and checks 09:15–15:30 IST session bounds. Expiry dates must be trading days. This is intentionally conservative; an official holiday calendar must be supplied for exact exchange coverage.

### DATA-04 — Storage atomicity
**Risk:** partial historical datasets after a process failure.
**Repair:** SQLite WAL + `BEGIN IMMEDIATE` transaction + rollback on any write failure.

### DATA-05 — Dataset immutability
**Risk:** silently replacing a dataset invalidates prior research results.
**Repair:** dataset names are immutable after successful ingest; a second ingest returns `DATASET_EXISTS`.

### DATA-06 — Quote contamination
**Risk:** crossed/zero/negative bid-ask or negative OI/volume can corrupt replay and P&L.
**Repair:** strict validation blocks malformed quotes; no values are fabricated.

### DATA-07 — Expiry contamination
**Risk:** mixing contracts from another expiry into a snapshot.
**Repair:** every contract expiry must equal the snapshot expiry.

### DATA-08 — Duplicate contract contamination
**Risk:** duplicate CE/PE rows can double-count OI or fills.
**Repair:** duplicate contract keys inside a snapshot are rejected.

### DATA-09 — Optional Parquet dependency
**Risk:** pretending Parquet is available when no engine is installed.
**Repair:** export returns `PARQUET_ENGINE_UNAVAILABLE` rather than creating a misleading file.

### DATA-10 — HTTP collision regression
**Risk found during smoke testing:** the first implementation used `self.v10_calendar` for an engine and also a method named `v10_calendar`, causing a runtime `TypeError`.
**Repair:** calendar engine renamed to `self.v10_calendar_engine` and endpoint handler renamed `v10_calendar_check`. HTTP smoke was rerun successfully for health, calendar and contract-map paths.

## Verification evidence
- **127/127 tests passed** after final repair.
- Python compilation passed.
- Dashboard wiring: 77 unique DOM IDs, 46 handlers, no handler references to missing IDs.
- Dashboard API references: 46, with zero missing server routes.
- Static scan found zero `place_order` definitions and zero `live_orders_enabled=True` literals.
- HTTP health reported V10.0 and live execution disabled.

## No-go items
- No real historical dataset is claimed merely because the storage engine exists.
- No exact exchange holiday calendar is claimed unless supplied/updated from an authoritative source.
- No exchange/SPAN margin is claimed.
- No live order execution is present.
- No autonomous trading is enabled.

## Next gate
Pass 11 should use this data layer to implement high-throughput historical replay over real licensed data, contract-chain reconstruction across expiries, corporate/calendar metadata where applicable, dataset versioning, query/index performance tests, and leakage-proof strategy replay. Live execution remains behind a separate safety gate.
