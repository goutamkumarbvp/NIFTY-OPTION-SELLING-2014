# V27.2 — OpenAI-capable LLM Reasoning + Paper Auto-Repair Provider

- Added optional OpenAI Responses API provider for V24 reasoning.
- Added optional OpenAI Responses API provider for V27 code repair proposals.
- Default remains offline/fail-closed; no API key is bundled.
- Paper-only repair provider is blocked outside TRADING_MODE=paper and when live-order flags are enabled.
- Existing compile/test/security/sandbox/rollback gates remain mandatory.
- Live order execution and live auto-promotion remain hard disabled.
- Configuration is documented in `.env.example`.

OpenAI models are accessed through the Responses API; the provider expects `OPENAI_API_KEY` locally.
