import tempfile, unittest
from pathlib import Path
from pass17_agent_engine import AgentMemoryStore, AgentToolRegistry, Pass17Agent

class T(unittest.TestCase):
    def setUp(self): self.d=tempfile.TemporaryDirectory(); self.a=Pass17Agent(Path(self.d.name)/'m.sqlite')
    def ctx(self):
        return {'state':{'paper_only':True,'live_orders_enabled':False,'feed':{'connected':True,'fresh':True}},'intelligence':{'data_quality':0.95,'pcr_oi':1.1},'regime':{'regime':'RANGE','confidence':.8},'plan':{'status':'TRADE','candidates':[{'type':'IRON_CONDOR'}]},'advanced_risk':{'decision':'ALLOW'}}
    def test_candidate(self):
        r=self.a.run(self.ctx()); self.assertEqual(r['decision'],'PAPER CANDIDATE'); self.assertTrue(r['evaluation']['decision_consistent'])
    def test_live_flag(self):
        c=self.ctx(); c['state']['live_orders_enabled']=True; self.assertEqual(self.a.run(c)['decision'],'NO TRADE')
    def test_stale(self):
        c=self.ctx(); c['state']['feed']['fresh']=False; self.assertEqual(self.a.run(c)['decision'],'NO TRADE')
    def test_low_quality(self):
        c=self.ctx(); c['intelligence']['data_quality']=.4; self.assertEqual(self.a.run(c)['decision'],'REVIEW')
    def test_risk(self):
        c=self.ctx(); c['advanced_risk']['decision']='BLOCK'; self.assertEqual(self.a.run(c)['decision'],'NO TRADE')
    def test_no_plan(self):
        c=self.ctx(); c['plan']=None; self.assertEqual(self.a.run(c)['decision'],'NO TRADE')
    def test_memory_redaction(self):
        m=self.a.memory.put('x','k',{'mpin':'1234','safe':1}); self.assertEqual(m.value['mpin'],'[REDACTED]')
    def test_memory_persistence(self):
        self.a.memory.put('decision','k',{'decision':'NO TRADE'}); self.assertEqual(len(self.a.memory.recent()),1)
    def test_tool_allowlist(self):
        self.a.tools.register('read_x','x',lambda:1); self.assertEqual(self.a.tools.call('read_x'),1)
    def test_tool_block_order(self):
        with self.assertRaises(ValueError): self.a.tools.register('place_order','x',lambda:1)
    def test_tool_block_risk(self):
        self.a.tools.register('danger','x',lambda:1,'EXECUTION')
        with self.assertRaises(PermissionError): self.a.tools.call('danger')
    def test_hypothesis(self): self.assertTrue(self.a.run(self.ctx())['hypotheses'])
    def test_critic(self): self.assertIn(self.a.run(self.ctx())['critic']['verdict'],('PASS','CAUTION','REJECT'))
    def test_evaluation(self): self.assertIn('quality_score',self.a.run(self.ctx())['evaluation'])
    def test_policy(self): self.assertFalse(self.a.run(self.ctx())['policy']['order_placement'])
    def test_no_profit_probability(self): self.assertNotIn('profit_probability',self.a.run(self.ctx()))
    def test_trace(self): self.assertTrue(self.a.run(self.ctx())['trace_id'])
    def test_memory_bounded(self):
        for i in range(2050): self.a.memory.put('x',str(i),{'i':i})
        self.assertLessEqual(len(self.a.memory.recent(limit=100)),100)

if __name__=='__main__': unittest.main()
