# V27.5 Codex Priority Repair Report

## Priority defects repaired

1. **Release runner hang**
   - Removed the runner's parent/child pytest wait boundary.
   - `tools/codex_full_suite.py` now performs environment preflight and `execv()` replaces itself with the pytest process.
   - No `PIPE` capture, no secondary collection subprocess, and no runner waiting on a child interpreter.
   - Global pytest plugin autoload is disabled for deterministic execution.

2. **Self-repair sandbox critical verification**
   - The existing fail-closed namespace sandbox was retained; no unsandboxed fallback was introduced.
   - Linux namespace capability is now exercised in this audit host.
   - `test_v18_self_repair.py` and `test_v273_hardening_round2.py` execute instead of being skipped.

## Independent verification

- `python tools/codex_full_suite.py`: **379 passed, exit 0**
- `test_v18_self_repair.py`: **6 passed**
- `test_v273_hardening_round2.py`: **10 passed**
- Full suite: **379 passed, 0 failed, 0 skipped**
- Runner timeout test: the runner is a direct exec entrypoint, eliminating the prior child-wait hang boundary.
- Namespace probe: **usable**

## Safety decision

No unsandboxed repair execution fallback was added. If the required sandbox is unavailable in another supported environment, repair verification remains fail-closed.

## Release

V27.5 priority repair build.
