from __future__ import annotations
"""Typed, fault-isolated in-process event bus."""
from collections import defaultdict
from threading import RLock
from typing import Callable, Mapping, Any
from application_contracts import DomainEvent, EventTopic

EventHandler = Callable[[DomainEvent], None]

class EventBus:
    def __init__(self):
        self._handlers: dict[str, list[EventHandler]] = defaultdict(list); self._lock=RLock(); self._sequence=0
    def subscribe(self, topic: EventTopic | str, handler: EventHandler) -> None:
        if not callable(handler): raise TypeError('EVENT_HANDLER_REQUIRED')
        key=str(topic.value if isinstance(topic, EventTopic) else topic)
        with self._lock: self._handlers[key].append(handler)
    def publish(self, event: DomainEvent | str, payload: Mapping[str, Any] | None = None) -> dict:
        if isinstance(event, DomainEvent):
            e=event
        else:
            e=DomainEvent(str(event), dict(payload or {}))
        key=str(e.topic.value if isinstance(e.topic, EventTopic) else e.topic)
        with self._lock:
            self._sequence += 1; seq=self._sequence
            e=DomainEvent(e.topic, dict(e.payload), seq, e.trace_id)
            handlers=list(self._handlers.get(key,()))+list(self._handlers.get('*',()))
        failures=[]
        for h in handlers:
            try: h(e)
            except Exception as exc: failures.append(str(exc))
        return {'topic':key,'sequence':seq,'handlers':len(handlers),'failures':failures}
    def stats(self):
        with self._lock: return {'topics':{k:len(v) for k,v in self._handlers.items()},'sequence':self._sequence}
