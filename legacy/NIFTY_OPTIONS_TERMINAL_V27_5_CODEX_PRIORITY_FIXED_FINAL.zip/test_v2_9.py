import json, threading
from urllib.request import urlopen, Request
from http.server import ThreadingHTTPServer
from server import APP, Handler
from reconciliation import reconcile

class ReadOnlyFake:
    def positions(self): return {'data':[{'exchangeSegment':'nse_fo','instrumentToken':'1','displaySymbol':'NIFTY 25000 CE','quantity':75,'averagePrice':100}]}
    def holdings(self): return {'data':[]}
    def limits(self): return {'data':{'availableMargin':100000}}

def test_read_only_reconciliation_match():
    APP.adapter=ReadOnlyFake(); APP.authenticated=True
    APP.local_positions=[{'exchangeSegment':'nse_fo','instrumentToken':'1','displaySymbol':'NIFTY 25000 CE','quantity':75,'averagePrice':100}]
    out=APP.command('positions'); assert out['ok'] and out['reconciliation']['matched']
    APP.local_positions=[]; APP.adapter=None; APP.authenticated=False

def test_reconciliation_mismatch_fails_closed():
    r=reconcile({'data':[{'exchangeSegment':'nse_fo','instrumentToken':'1','quantity':75}]},{'data':[{'exchangeSegment':'nse_fo','instrumentToken':'1','quantity':0}]})
    assert not r['matched'] and r['mismatches'][0]['delta']==75

def test_read_only_routes_exist():
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); port=srv.server_address[1]; t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
    try:
        h=json.loads(urlopen(f'http://127.0.0.1:{port}/api/health').read()); assert h['api_schema_version']=='v12.0' and h['read_only_reconciliation']
    finally:srv.shutdown();srv.server_close()
