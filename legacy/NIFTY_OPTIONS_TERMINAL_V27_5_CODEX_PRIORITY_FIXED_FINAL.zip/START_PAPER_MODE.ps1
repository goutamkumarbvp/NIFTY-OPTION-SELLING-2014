$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:TRADING_MODE='paper'
$env:LIVE_TRADING='false'
$env:LIVE_ORDERS_ENABLED='false'
$env:PAPER_AUTO_SELF_REPAIR='true'
$env:SELF_REPAIR_AUTO_PROMOTE='false'
$env:BIND_HOST='127.0.0.1'
$env:PORT='8500'
Write-Host 'V27 SAFE PAPER AUTO-REPAIR MODE'
Write-Host 'LIVE_TRADING=false | LIVE_ORDERS_ENABLED=false | PAPER_AUTO_SELF_REPAIR=true'
python server.py
