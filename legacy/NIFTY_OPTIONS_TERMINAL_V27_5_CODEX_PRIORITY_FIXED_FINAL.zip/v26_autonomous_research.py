from __future__ import annotations
"""V26 bounded autonomous research loop: hypotheses -> tests -> robustness -> ranking.
It can research and simulate; it cannot trade or alter production code.
"""
import math, statistics, time, uuid
from typing import Any

class AdvancedAutonomousResearch:
    VERSION="v26.0"
    def __init__(self,max_candidates=20,max_bars=20000): self.max_candidates=max(1,min(int(max_candidates),100)); self.max_bars=max(100,min(int(max_bars),100000))
    @staticmethod
    def _returns(prices): return [(prices[i]/prices[i-1]-1) for i in range(1,len(prices)) if prices[i-1] not in (0,None) and prices[i] is not None]
    def run(self,bars=None,hypotheses=None,context=None):
        bars=list(bars or [])[-self.max_bars:]; hypotheses=list(hypotheses or [])[:self.max_candidates]; context=context or {}
        prices=[]
        for b in bars:
            try: prices.append(float(b.get("close",b) if isinstance(b,dict) else b))
            except Exception: pass
        rs=self._returns(prices); vol=statistics.pstdev(rs) if len(rs)>1 else None
        results=[]
        for h in hypotheses:
            name=str(h.get("name",h.get("id","hypothesis"))); threshold=float(h.get("threshold",0))
            score=0.5; evidence=[f"bars={len(prices)}"]
            if rs:
                mean=statistics.mean(rs); hit=sum(1 for r in rs if r>threshold)/len(rs); score=max(0,min(1,0.5+0.5*(hit-0.5))); evidence += [f"mean_return={mean:.6f}",f"hit_rate={hit:.3f}"]
            if vol is not None: evidence.append(f"realized_vol={vol:.6f}")
            results.append({"hypothesis":name,"score":round(score,4),"evidence":evidence,"robustness":{"sample_size":len(rs),"pass":len(rs)>=30 and score>=.55},"execution":"PAPER_ONLY"})
        results.sort(key=lambda x:x["score"],reverse=True)
        return {"research_id":str(uuid.uuid4()),"version":self.VERSION,"status":"READY" if bars else "INSUFFICIENT_DATA","results":results,"data_quality":{"bars":len(prices),"returns":len(rs),"usable":bool(rs)},"guardrails":{"live_orders_enabled":False,"code_mutation":False,"max_candidates":self.max_candidates},"timestamp":time.time()}
