from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from math import isfinite

@dataclass(frozen=True)
class ReplayConfig:
    fee_per_lot: float=20.0
    slippage_pct: float=0.001
    lot_size: int=75

class OptionChainReplay:
    """Deterministic snapshot replay. Signals at t fill using snapshot t+1 quotes."""
    def __init__(self,config=None): self.config=config or ReplayConfig()
    @staticmethod
    def _time(x): return datetime.fromisoformat(str(x).replace('Z','+00:00'))
    @staticmethod
    def _key(c): return (str(c.get('symbol','')),str(c.get('option_type','')),float(c.get('strike',0)),str(c.get('expiry','')))
    def validate(self,snapshots):
        if not isinstance(snapshots,list) or len(snapshots)<2:return {'status':'BLOCKED','reason':'INSUFFICIENT_SNAPSHOTS'}
        prev=None
        for s in snapshots:
            try:
                t=self._time(s['timestamp']); spot=float(s['spot']); contracts=s['contracts']
                if not isfinite(spot) or spot<=0 or not contracts:return {'status':'BLOCKED','reason':'INVALID_SNAPSHOT'}
                if prev is not None and t<=prev:return {'status':'BLOCKED','reason':'NON_MONOTONIC_TIMESTAMP'}
                prev=t
                seen=set()
                for c in contracts:
                    k=self._key(c)
                    if k in seen:return {'status':'BLOCKED','reason':'DUPLICATE_CONTRACT'}
                    seen.add(k)
                    bid,ask=float(c['bid']),float(c['ask'])
                    if not all(isfinite(x) and x>0 for x in (bid,ask)) or ask<bid:return {'status':'BLOCKED','reason':'INVALID_QUOTE'}
            except (KeyError,TypeError,ValueError,OverflowError):return {'status':'BLOCKED','reason':'INVALID_SNAPSHOT'}
        return {'status':'READY','snapshots':len(snapshots)}
    def _map(self,s): return {self._key(c):c for c in s['contracts']}
    def replay(self,snapshots,legs,entry_index=0,exit_index=None,capital=1_000_000.0):
        chk=self.validate(snapshots)
        if chk['status']!='READY':return chk
        if not isinstance(legs,list) or not legs:return {'status':'BLOCKED','reason':'INVALID_LEGS'}
        exit_index=len(snapshots)-1 if exit_index is None else int(exit_index)
        if entry_index<0 or entry_index+1>=len(snapshots) or exit_index<=entry_index or exit_index>=len(snapshots):return {'status':'BLOCKED','reason':'INVALID_WINDOW'}
        entry=self._map(snapshots[entry_index+1]); exitq=self._map(snapshots[exit_index]); entry_prices=[]; exit_prices=[]
        for l in legs:
            k=(str(l.get('symbol','')),str(l.get('option_type')),float(l.get('strike',0)),str(l.get('expiry',snapshots[entry_index+1].get('expiry'))))
            if k not in entry or k not in exitq:return {'status':'BLOCKED','reason':'MISSING_CONTRACT','contract':k}
            if l.get('side') not in (-1,1) or int(l.get('qty',0))<=0 or int(l.get('lot_size',0))<=0:return {'status':'BLOCKED','reason':'INVALID_LEG'}
            e=entry[k]; x=exitq[k]; ep=float(e['ask']) if l['side']==1 else float(e['bid']); xp=float(x['bid']) if l['side']==1 else float(x['ask'])
            ep=ep*(1+self.config.slippage_pct) if l['side']==1 else ep*(1-self.config.slippage_pct)
            xp=xp*(1-self.config.slippage_pct) if l['side']==1 else xp*(1+self.config.slippage_pct)
            entry_prices.append(ep); exit_prices.append(xp)
        pnl=sum((xp-ep)*int(l['qty'])*int(l['lot_size'])*l['side'] for l,ep,xp in zip(legs,entry_prices,exit_prices))-sum(abs(int(l['qty'])) for l in legs)*self.config.fee_per_lot
        return {'status':'READY','entry_index':entry_index+1,'exit_index':exit_index,'entry_prices':entry_prices,'exit_prices':exit_prices,'pnl':pnl,'final_capital':float(capital)+pnl,'lookahead_protection':True,'replay_only':True}
