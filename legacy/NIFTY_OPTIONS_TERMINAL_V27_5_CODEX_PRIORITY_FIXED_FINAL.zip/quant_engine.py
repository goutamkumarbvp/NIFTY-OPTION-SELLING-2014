from __future__ import annotations
from dataclasses import dataclass, asdict
from math import exp, log, sqrt, erf, isfinite, pi
from typing import Optional

@dataclass(frozen=True)
class Greeks:
    price: float
    delta: float
    gamma: float
    theta: float
    vega: float
    rho: float
    charm: float
    vanna: float
    volga: float
    color: float

class QuantEngine:
    """European Black-Scholes analytics with dividend yield and fail-closed IV solving."""
    @staticmethod
    def _ok(x):
        try: return isfinite(float(x))
        except (TypeError, ValueError): return False
    @staticmethod
    def _norm_pdf(x): return exp(-0.5*x*x)/sqrt(2*pi)
    @staticmethod
    def _norm_cdf(x): return 0.5*(1+erf(x/sqrt(2)))
    def greeks(self,S,K,T,r,sigma,q=0.0,call=True)->Greeks:
        vals=(S,K,T,r,sigma,q)
        if not all(self._ok(x) for x in vals) or S<=0 or K<=0 or T<=0 or sigma<=0: raise ValueError('INVALID_BS_INPUT')
        try:
            d1=(log(S/K)+(r-q+0.5*sigma*sigma)*T)/(sigma*sqrt(T)); d2=d1-sigma*sqrt(T)
            N1=self._norm_cdf(d1); N2=self._norm_cdf(d2); n1=self._norm_pdf(d1); disc_r=exp(-r*T); disc_q=exp(-q*T)
        except (OverflowError, ValueError, ZeroDivisionError) as e:
            raise ValueError('INVALID_BS_INPUT') from e
        if call: price=S*disc_q*N1-K*disc_r*N2; delta=disc_q*N1; theta=(-S*disc_q*n1*sigma/(2*sqrt(T))-r*K*disc_r*N2+q*S*disc_q*N1)/365; rho=K*T*disc_r*N2/100
        else: price=K*disc_r*self._norm_cdf(-d2)-S*disc_q*self._norm_cdf(-d1); delta=disc_q*(N1-1); theta=(-S*disc_q*n1*sigma/(2*sqrt(T))+r*K*disc_r*self._norm_cdf(-d2)-q*S*disc_q*self._norm_cdf(-d1))/365; rho=-K*T*disc_r*self._norm_cdf(-d2)/100
        gamma=disc_q*n1/(S*sigma*sqrt(T)); vega=S*disc_q*n1*sqrt(T)/100
        # Common practitioner definitions; theta/vega/rho are per-day/per-1% conventions.
        charm=-q*disc_q*(N1 if call else N1-1)-disc_q*n1*(2*(r-q)*T-d2*sigma*sqrt(T))/(2*T*sigma*sqrt(T))
        vanna=-disc_q*n1*d2/sigma
        volga=vega*100*d1*d2/sigma/100
        color=-disc_q*n1/(2*S*T*sigma*sqrt(T))*(2*q*T+1+(2*(r-q)*T-d1*sigma*sqrt(T))/(sigma*sqrt(T))) / 365
        return Greeks(price,delta,gamma,theta,vega,rho,charm,vanna,volga,color)
    def price(self,S,K,T,r,sigma,q=0.0,call=True): return self.greeks(S,K,T,r,sigma,q,call).price
    def implied_vol(self,market_price,S,K,T,r,q=0.0,call=True,lo=1e-6,hi=5.0,tol=1e-8,max_iter=120)->Optional[float]:
        if not all(self._ok(x) for x in (market_price,S,K,T,r,q)) or market_price<=0 or S<=0 or K<=0 or T<=0: return None
        try:
            disc_r=exp(-r*T); disc_q=exp(-q*T)
            intrinsic=max(S*disc_q-K*disc_r,0) if call else max(K*disc_r-S*disc_q,0)
            upper=S*disc_q if call else K*disc_r
        except (OverflowError, ValueError, ZeroDivisionError):
            return None
        if not self._ok(intrinsic) or not self._ok(upper): return None
        if market_price < intrinsic-1e-9 or market_price > upper+1e-9: return None
        def f(v):
            try:
                value=self.price(S,K,T,r,v,q,call)
                return value-market_price if self._ok(value) else float('nan')
            except (OverflowError, ValueError, ZeroDivisionError):
                return float('nan')
        if not self._ok(lo) or not self._ok(hi) or lo<=0 or hi<=lo: return None
        flo=f(lo); fhi=f(hi)
        if not self._ok(flo) or not self._ok(fhi): return None
        if abs(flo)<tol:return lo
        if abs(fhi)<tol:return hi
        if flo*fhi>0:return None
        for _ in range(max_iter):
            mid=(lo+hi)/2; fm=f(mid)
            if not self._ok(fm): return None
            if abs(fm)<tol:return mid
            if flo*fm<=0:hi=mid; fhi=fm
            else:lo=mid; flo=fm
        return (lo+hi)/2 if abs(f((lo+hi)/2))<1e-5 else None
