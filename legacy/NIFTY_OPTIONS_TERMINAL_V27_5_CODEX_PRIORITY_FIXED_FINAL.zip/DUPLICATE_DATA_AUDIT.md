# V22 Duplicate Data Audit

Performed before release packaging:
- Exact SHA-256 duplicate-file scan: no duplicates remain.
- Removed generated runtime logs, alerts, SQLite memory, research test artifacts, `.pytest_cache`, and Python `__pycache__` files from the distributable.
- One exact duplicate generated research JSONL pair was found in the uploaded package and removed with the generated runtime state.
- Dashboard DOM IDs were scanned; duplicate `regime` ID was repaired (`regimeValue` for the metric; `regime` remains the button).
- Historical V2–V22 source modules and release reports were retained because they are distinct implementation/audit artifacts, not byte-identical duplicate data.
