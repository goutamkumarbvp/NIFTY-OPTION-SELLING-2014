from __future__ import annotations
"""V24 LLM Reasoning Gateway: provider-neutral, schema-first, fail-closed reasoning.
No provider is contacted unless explicitly configured with LLM_GATEWAY_URL.
"""
import json, os, re, time, urllib.request, urllib.error
from dataclasses import dataclass, asdict
from typing import Any, Mapping

@dataclass(frozen=True)
class ReasoningResult:
    ok: bool
    mode: str
    provider: str
    summary: str
    conclusions: tuple[str, ...]
    uncertainties: tuple[str, ...]
    confidence: float
    latency_ms: float
    blocked: bool = False

class LLMReasoningGateway:
    VERSION = "v24.0"
    def __init__(self, env: Mapping[str, str] | None = None):
        e=dict(env or os.environ)
        self.url=e.get("LLM_GATEWAY_URL", "").strip()
        self.model=e.get("LLM_MODEL", "").strip()
        self.provider=e.get("LLM_PROVIDER", "generic").strip() or "generic"
        self.timeout=max(1.0,min(float(e.get("LLM_TIMEOUT_SECONDS","8")),30.0))
        self.max_evidence=max(1,min(int(e.get("LLM_MAX_EVIDENCE","40")),100))
        self.max_prompt_chars=max(1000,min(int(e.get("LLM_MAX_PROMPT_CHARS","12000")),50000))
        self.allow_remote=e.get("LLM_GATEWAY_ENABLED","false").lower()=="true"
        self.api_key=e.get("LLM_API_KEY", e.get("OPENAI_API_KEY", "")).strip()
        if self.provider.lower() == "openai" and not self.url:
            self.url="https://api.openai.com/v1/responses"

    @staticmethod
    def _clean(x: Any) -> str:
        s=str(x).replace("\x00", " ")
        s=re.sub(r"(?i)(api[_-]?key|token|secret|password)\s*[:=]\s*\S+", r"\1=[REDACTED]", s)
        return s[:1000]

    def _deterministic(self, evidence: Mapping[str, Any], reason: str = "") -> ReasoningResult:
        t=time.perf_counter(); items=[]
        for k,v in list(evidence.items())[:self.max_evidence]:
            val="[REDACTED]" if any(x in str(k).lower() for x in ("secret","password","token","api_key")) else self._clean(v)
            items.append(f"{self._clean(k)}={val}")
        risks=[]; conclusions=[]
        text=" ".join(items).lower()
        if any(x in text for x in ("stale", "disconnected", "blocked", "unsafe")): risks.append("safety or data-quality concern present")
        if not risks: conclusions.append("evidence is internally consistent enough for bounded analysis")
        else: conclusions.append("analysis should remain non-executing until the cited concern is resolved")
        return ReasoningResult(True,"deterministic",self.provider,"; ".join(items[:6]) or "no evidence",tuple(conclusions),tuple(risks),0.65,round((time.perf_counter()-t)*1000,3))

    def reason(self, evidence: Mapping[str, Any], instruction: str = "Analyze evidence conservatively.") -> dict[str, Any]:
        evidence=dict(evidence or {})
        if not self.allow_remote or not self.url:
            return asdict(self._deterministic(evidence,instruction))
        safe_evidence={str(k):self._clean(v) for k,v in list(evidence.items())[:self.max_evidence]}
        if self.provider.lower() == "openai":
            prompt=("Return ONLY valid JSON with keys summary, conclusions, uncertainties, confidence. "
                    "Analyze the supplied evidence conservatively. Do not authorize live orders or risk overrides. "
                    f"Instruction: {self._clean(instruction)}\nEvidence: {json.dumps(safe_evidence,ensure_ascii=False)}")
            payload={"model":self.model,"instructions":"You are a bounded reasoning component for a paper-only trading terminal.","input":prompt,"store":False}
            headers={"Content-Type":"application/json","Authorization":"Bearer "+self.api_key,"X-Reasoning-Gateway":"v24"}
        else:
            payload={"model":self.model,"instruction":self._clean(instruction),"evidence":safe_evidence}
            headers={"Content-Type":"application/json","X-Reasoning-Gateway":"v24"}
        raw=json.dumps(payload,separators=(",",":" )).encode()
        if len(raw)>self.max_prompt_chars: raw=raw[:self.max_prompt_chars]
        req=urllib.request.Request(self.url,data=raw,headers=headers,method="POST")
        t=time.perf_counter()
        try:
            with urllib.request.urlopen(req,timeout=self.timeout) as r:
                obj=json.loads(r.read(200000).decode("utf-8"))
            if self.provider.lower() == "openai":
                text=obj.get("output_text") or ""
                if not text:
                    for item in obj.get("output",[]) or []:
                        for c in item.get("content",[]) or []:
                            if c.get("type")=="output_text": text += c.get("text","")
                parsed=json.loads(text)
            else:
                parsed=obj
            conf=float(parsed.get("confidence",0)); conf=max(0,min(1,conf))
            return asdict(ReasoningResult(True,"remote",self.provider,str(parsed.get("summary",""))[:2000],tuple(map(str,parsed.get("conclusions",[])))[:10],tuple(map(str,parsed.get("uncertainties",[])))[:10],conf,round((time.perf_counter()-t)*1000,3)))
        except Exception as exc:
            fallback=asdict(self._deterministic(evidence,instruction)); fallback.update({"mode":"fallback","blocked":True,"uncertainties":tuple(list(fallback["uncertainties"])+[f"LLM gateway unavailable: {type(exc).__name__}"])})
            return fallback
