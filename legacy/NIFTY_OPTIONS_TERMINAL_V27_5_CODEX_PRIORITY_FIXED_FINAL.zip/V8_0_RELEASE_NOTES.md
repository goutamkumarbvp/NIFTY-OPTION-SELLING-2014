# NIFTY Options Terminal V8.0 — Pass 8

## Scope
Multi-leg NIFTY options strategy research: expiry-aware payoff/P&L, bid/ask execution, slippage, fees, margin-utilization gate, parameter-grid optimization, robustness statistics, Monte-Carlo validation, and normalized historical option-chain schema validation.

## Safety
- Live order execution remains hard-disabled.
- Every leg requires valid bid/ask; no synthetic fills.
- Entry follows next-bar bid/ask look-ahead rule.
- Expiry payoff uses supplied expiry spot and option intrinsic value.
- Margin is explicitly labelled as a research estimate; it is not broker/exchange margin.
- Optimization is bounded to supplied parameter grids and supplied evidence.
- Monte-Carlo uses a deterministic seed and requires a minimum sample.

## Verification
- 95 tests passed.
- Python compilation passed.
- Dashboard/API route audit: 0 missing Pass 8 routes.
- Live execution symbol scan: 0 implementation paths outside tests.
- State version: v8.0.
- live_orders_enabled: false.
- ZIP integrity verified.

## Known limitations
- Broker-authoritative SPAN/Exposure margin is not yet integrated.
- Historical data must be supplied by a real source; this release does not fabricate history.
- Expiry payoff assumes European cash-settled intrinsic treatment and does not model intraday assignment/exercise.
- Optimizer is a bounded grid search, not a machine-learning optimizer.
- Monte-Carlo is bootstrap resampling of supplied trade P&Ls, not a stochastic volatility market simulator.
