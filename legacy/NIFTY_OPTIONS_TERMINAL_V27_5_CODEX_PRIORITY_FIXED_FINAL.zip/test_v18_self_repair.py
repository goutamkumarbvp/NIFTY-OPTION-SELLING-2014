import tempfile
import unittest
import pytest
from pathlib import Path
from self_repair import CodeSelfRepairEngine, RepairPolicy

class V18Tests(unittest.TestCase):
    def test_diagnosis_syntax(self):
        with tempfile.TemporaryDirectory() as d:
            e=CodeSelfRepairEngine(Path(d))
            x=e.diagnose("SyntaxError: invalid syntax", Path(d)/"x.py")
            self.assertEqual(x.category,"SYNTAX_ERROR")
            self.assertFalse(x.repairable)

    def test_policy_blocks_live_enable(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"x.py"; p.write_text("LIVE_TRADING=false\n")
            pol=RepairPolicy(Path(d),paper_only=True,live_orders_enabled=False)
            self.assertEqual(pol.patch_allowed(p.read_text(),"LIVE_TRADING=true\n",p)[0],False)

    def test_verified_candidate_does_not_touch_production(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/"test_x.py").write_text("def test_ok(): assert 1+1==2\n")
            target=root/"x.py"; target.write_text("VALUE=1\n")
            e=CodeSelfRepairEngine(root)
            if not e._sandbox_backend_available():
                pytest.skip("OS sandbox capability unavailable; production verifier fails closed")
            dx=e.diagnose("AssertionError",target)
            r=e.propose_and_verify(dx,target,"VALUE=2\n",promote=False)
            self.assertEqual(r.status,"VERIFIED_CANDIDATE")
            self.assertEqual(target.read_text(),"VALUE=1\n")
            self.assertTrue(r.verification.passed)

    def test_promotion_rollback(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/"test_x.py").write_text("def test_ok(): assert False\n")
            target=root/"x.py"; target.write_text("VALUE=1\n")
            e=CodeSelfRepairEngine(root)
            e.policy.allow_auto_promote=True
            dx=e.diagnose("runtime Exception",target)
            r=e.propose_and_verify(dx,target,"VALUE=2\n",promote=True)
            self.assertEqual(r.status,"VERIFICATION_FAILED")
            self.assertEqual(target.read_text(),"VALUE=1\n")

    def test_automatic_rollback_path(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); target=root/"x.py"; target.write_text("VALUE=1\n")
            e=CodeSelfRepairEngine(root); e.policy.allow_auto_promote=True
            # Force a post-promotion verification failure to exercise rollback.
            calls=[0]
            def fake_verify(_, candidate_rel=None):
                calls[0]+=1
                from self_repair import Verification
                return Verification(calls[0] == 1, True, calls[0] == 1, True, "forced", 0.0)
            e._verify=fake_verify
            dx=e.diagnose("Runtime Exception",target)
            r=e.propose_and_verify(dx,target,"VALUE=2\n",promote=True)
            self.assertEqual(r.status,"ROLLED_BACK")
            self.assertTrue(r.rollback_performed)
            self.assertEqual(target.read_text(),"VALUE=1\n")

    def test_live_invariant_scan(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/"x.py").write_text("LIVE_TRADING=false\n")
            e=CodeSelfRepairEngine(root)
            ok,msg=e._static_security(root)
            self.assertTrue(ok,msg)

if __name__=='__main__': unittest.main()
