from __future__ import annotations
import time

def run_soak(snapshot_fn, duration_seconds=60, interval_seconds=1, max_stale_seconds=5):
    duration_seconds=max(1,int(duration_seconds)); interval_seconds=max(.1,float(interval_seconds))
    started=time.time(); samples=0; fresh=0; stale=0; errors=[]; last=None
    while time.time()-started < duration_seconds:
        try:
            s=snapshot_fn(); samples+=1; last=s
            age=s.get('feed',{}).get('age') if isinstance(s,dict) else None
            if age is not None and age <= max_stale_seconds: fresh+=1
            else: stale+=1
        except Exception as e:
            errors.append(str(e)); stale+=1
        time.sleep(interval_seconds)
    return {'duration_seconds':round(time.time()-started,3),'samples':samples,'fresh_samples':fresh,'stale_samples':stale,'errors':errors[-10:],'pass':samples>0 and not errors and fresh>0,'last_state':last}
