import math
from terminal_backend import TerminalBackend

def test_state_does_not_accept_banknifty_as_nifty():
    b=TerminalBackend()
    b.ticks.clear()
    class T:
        def __init__(self,s,p): self.trading_symbol=s; self.instrument_token=s; self.ltp=p
    b.ticks['x']=T('BANKNIFTY',56000)
    assert b.state()['market']['nifty'] is None

def test_flatten_rejects_client_prices():
    b=TerminalBackend()
    out=b.paper_flatten({'prices':{'X':999999}})
    assert not out['ok'] and 'CLIENT_FLATTEN_PRICES_FORBIDDEN' in out['error']

def test_frontend_has_responsive_and_coalesced_polling():
    s=open('dashboard/index.html',encoding='utf-8').read()
    assert 'stateBusy' in s and 'document.hidden' in s and 'CLIENT_FLATTEN_PRICES_FORBIDDEN' not in s
    assert 'setInterval(loadAlerts,1000)' not in s
