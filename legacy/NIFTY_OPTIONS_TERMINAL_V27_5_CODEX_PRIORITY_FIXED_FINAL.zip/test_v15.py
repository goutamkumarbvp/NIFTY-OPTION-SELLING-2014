from pass15_engine import KotakResponseExtractor, NiftyTokenResolver, SubscriptionPlanner, TickSoakMonitor, Pass15Error

def test_extract_instrument_refs():
    r={'data':[{'exchange_segment':'nse_cm','instrument_token':'999','trading_symbol':'NIFTY 50'},{'exchange_segment':'nse_fo','instrument_token':'1'}]}
    x=KotakResponseExtractor.instrument_refs(r); assert ('nse_cm','999') in {(a.exchange_segment,a.instrument_token) for a in x}

def test_resolver_never_guesses():
    class A:
        def search_scrip(self,**kwargs): return {'data':[]}
    try: NiftyTokenResolver(A()).resolve(); assert False
    except Pass15Error as e: assert 'NOT_RESOLVED' in str(e)

def test_resolver_prefers_exact_nifty():
    class A:
        def search_scrip(self,**kwargs): return {'data':[{'exchange_segment':'nse_cm','instrument_token':'111','trading_symbol':'NIFTY 50'},{'exchange_segment':'nse_fo','instrument_token':'222','trading_symbol':'NIFTY26SEP25000CE'}]}
    x=NiftyTokenResolver(A()).resolve(); assert x.instrument_token=='111' and x.exchange_segment=='nse_cm'

def test_option_contract_extract():
    r={'data':[{'exchange_segment':'nse_fo','instrument_token':'1','strike':'25000','option_type':'CE','expiry':'2026-09-24','trading_symbol':'NIFTY24SEP25000CE'}, {'exchange_segment':'nse_fo','instrument_token':'2','strike':'25000','option_type':'PE','expiry':'2026-09-24'}]}
    x=KotakResponseExtractor.option_contracts(r); assert len(x)==2 and {c['option_type'] for c in x}=={'CE','PE'}

def test_subscription_planner_dedupes():
    p=SubscriptionPlanner().plan([{'exchange_segment':'nse_fo','instrument_token':'1'},{'exchange_segment':'nse_fo','instrument_token':'1'},{'exchange_segment':'nse_cm','instrument_token':'2'}]); assert p==[('nse_fo','1')]

def test_subscription_limit():
    rows=[{'exchange_segment':'nse_fo','instrument_token':str(i)} for i in range(3001)]
    try: SubscriptionPlanner().plan(rows); assert False
    except Pass15Error as e: assert '3000' in str(e)

def test_soak_quality():
    class T: pass
    q=TickSoakMonitor(); t=T(); t.local_sequence=1;t.ltp=100;t.exchange_segment='nse_fo';t.instrument_token='1';q.observe(t); assert q.snapshot()['status']=='GOOD'
