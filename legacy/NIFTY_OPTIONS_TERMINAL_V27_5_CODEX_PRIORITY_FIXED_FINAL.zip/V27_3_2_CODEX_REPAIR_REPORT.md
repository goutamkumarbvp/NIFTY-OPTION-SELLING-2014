# V27.3.2 Codex Repair Report

This artifact is a repaired derivative of the supplied `V27_3_2_CODEX_PASS.zip`.
The original ZIP is preserved outside this working tree and was never modified.

## Repairs
- Corrected internal release identity to V27.3.2.
- Removed the hard-coded V27.3 API health identity by reading VERSION.json.
- Added deterministic self-healing worker shutdown assertion to the fault-injection helper.
- Added release/version and worker-lifecycle regression tests.
- Made the self-repair candidate test exclusion explicit and narrowly limited to the recursive meta-test module; the outer release suite still executes that module normally.
- Release packaging excludes runtime state, caches, bytecode, test artifacts and generated databases.

## Safety preserved
- LIVE_TRADING remains false.
- LIVE_ORDERS_ENABLED remains false.
- Paper-only runtime invariant remains enforced.
- Self-repair auto-promotion remains disabled by default.
