# V26.0 — Advanced Autonomous Research
- Bounded hypothesis → test → robustness → ranking loop.
- Uses supplied historical/research bars only; no synthetic live market data.
- Explicit sample-size and score gates.
- Research output is PAPER_ONLY and cannot place orders or mutate code.
