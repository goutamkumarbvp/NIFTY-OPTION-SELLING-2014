from __future__ import annotations
import hashlib, json, sqlite3, time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from collections import defaultdict
from math import isfinite

@dataclass(frozen=True)
class ReplayEvent:
    signal_index: int
    fill_index: int
    signal_timestamp: str
    fill_timestamp: str

class DatasetVersionRegistry:
    """Content-addressed dataset manifests. A version is immutable once registered."""
    def __init__(self, path='runtime/historical_options/v11_registry.sqlite3'):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(self.path) as c:
            c.execute('CREATE TABLE IF NOT EXISTS versions(name TEXT NOT NULL, version TEXT NOT NULL, sha256 TEXT NOT NULL, row_count INTEGER NOT NULL, created_at TEXT NOT NULL, metadata TEXT NOT NULL, PRIMARY KEY(name,version))')
            c.execute('CREATE INDEX IF NOT EXISTS idx_versions_name ON versions(name,created_at)')
    @staticmethod
    def digest(payload):
        return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    def register(self,name,payload,metadata=None):
        if not name or not isinstance(payload,(list,dict)): return {'status':'BLOCKED','reason':'INVALID_DATASET'}
        h=self.digest(payload); version=h[:16]
        with sqlite3.connect(self.path) as c:
            row=c.execute('SELECT sha256 FROM versions WHERE name=? AND version=?',(str(name),version)).fetchone()
            if row: return {'status':'READY','name':str(name),'version':version,'sha256':h,'existing':True,'rows':len(payload) if isinstance(payload,list) else None}
            c.execute('INSERT INTO versions VALUES(?,?,?,?,?,?)',(str(name),version,h,len(payload) if isinstance(payload,list) else 1,datetime.now(timezone.utc).isoformat(),json.dumps(metadata or {},sort_keys=True)))
        return {'status':'READY','name':str(name),'version':version,'sha256':h,'existing':False,'rows':len(payload) if isinstance(payload,list) else 1}
    def list_versions(self,name):
        with sqlite3.connect(self.path) as c:
            rows=c.execute('SELECT name,version,sha256,row_count,created_at,metadata FROM versions WHERE name=? ORDER BY created_at DESC',(str(name),)).fetchall()
        return {'status':'READY','versions':[{'name':r[0],'version':r[1],'sha256':r[2],'rows':r[3],'created_at':r[4],'metadata':json.loads(r[5])} for r in rows]}

class ContractSeriesManager:
    """Deterministic expiry-series reconstruction from explicit contracts; never guesses expiry."""
    def series(self,contracts):
        if not isinstance(contracts,list) or not contracts: return {'status':'BLOCKED','reason':'NO_CONTRACTS'}
        by=defaultdict(list)
        for c in contracts:
            try:
                expiry=str(c['expiry'])[:10]; strike=float(c['strike']); opt=str(c['option_type']).upper()
                if not expiry or not isfinite(strike) or strike<=0 or opt not in ('CE','PE'): return {'status':'BLOCKED','reason':'INVALID_CONTRACT'}
                by[expiry].append(c)
            except (KeyError,TypeError,ValueError): return {'status':'BLOCKED','reason':'INVALID_CONTRACT'}
        expiries=sorted(by)
        return {'status':'READY','expiries':expiries,'series':{e:{'count':len(by[e]),'contracts':by[e]} for e in expiries}}
    def select(self,contracts,expiry):
        r=self.series(contracts)
        if r['status']!='READY': return r
        e=str(expiry)[:10]
        if e not in r['series']: return {'status':'BLOCKED','reason':'EXPIRY_NOT_FOUND'}
        return {'status':'READY','expiry':e,'contracts':r['series'][e]['contracts']}

class HistoricalQueryLayer:
    """Indexed read-only queries against the V10 SQLite option-chain store."""
    def __init__(self,db_path): self.path=Path(db_path)
    def datasets(self):
        with sqlite3.connect(self.path) as c:
            rows=c.execute('SELECT name,created_at,row_count,contract_count,sha256 FROM datasets ORDER BY created_at DESC').fetchall()
        return {'status':'READY','datasets':[{'name':r[0],'created_at':r[1],'snapshots':r[2],'contracts':r[3],'sha256':r[4]} for r in rows]}
    def snapshots(self,dataset,start_ts=None,end_ts=None,limit=1000):
        limit=max(1,min(int(limit),100000)); q='SELECT snapshot_id,ts,spot,expiry FROM snapshots WHERE dataset=?'; args=[dataset]
        if start_ts: q+=' AND ts>=?'; args.append(start_ts)
        if end_ts: q+=' AND ts<=?'; args.append(end_ts)
        q+=' ORDER BY ts LIMIT ?'; args.append(limit)
        with sqlite3.connect(self.path) as c: rows=c.execute(q,args).fetchall()
        return {'status':'READY','dataset':dataset,'snapshots':[{'snapshot_id':r[0],'timestamp':r[1],'spot':r[2],'expiry':r[3]} for r in rows]}
    def contracts(self,dataset,snapshot_id=None,expiry=None,option_type=None,limit=5000):
        limit=max(1,min(int(limit),100000)); q='SELECT symbol,instrument_token,exchange_segment,underlying,expiry,strike,option_type,bid,ask,oi,volume FROM contracts WHERE dataset=?'; args=[dataset]
        if snapshot_id is not None: q+=' AND snapshot_id=?'; args.append(int(snapshot_id))
        if expiry: q+=' AND expiry=?'; args.append(str(expiry)[:10])
        if option_type: q+=' AND option_type=?'; args.append(str(option_type).upper())
        q+=' ORDER BY expiry,strike,option_type LIMIT ?'; args.append(limit)
        with sqlite3.connect(self.path) as c: rows=c.execute(q,args).fetchall()
        keys=('symbol','instrument_token','exchange_segment','underlying','expiry','strike','option_type','bid','ask','oi','volume')
        return {'status':'READY','dataset':dataset,'contracts':[dict(zip(keys,r)) for r in rows]}

class DataQualityScorer:
    def score(self,snapshots):
        if not isinstance(snapshots,list) or not snapshots: return {'status':'BLOCKED','reason':'NO_SNAPSHOTS'}
        checks=total=0; reasons=[]; prev=None; contract_counts=[]
        for s in snapshots:
            total+=1
            try:
                dt=datetime.fromisoformat(str(s['timestamp']).replace('Z','+00:00')); spot=float(s['spot']); cs=s['contracts']
                ok=isfinite(spot) and spot>0 and isinstance(cs,list) and bool(cs) and (prev is None or dt>prev)
                if not ok: reasons.append('TIMESTAMP_OR_SPOT_OR_CONTRACT_ERROR')
                else: checks+=1
                prev=dt
                seen=set(); valid=0
                for c in cs:
                    try:
                        bid=float(c['bid']); ask=float(c['ask']); oi=float(c.get('oi',0)); vol=float(c.get('volume',0)); key=(c['symbol'],c['expiry'],float(c['strike']),str(c['option_type']).upper())
                        good=isfinite(bid) and isfinite(ask) and bid>0 and ask>=bid and oi>=0 and vol>=0 and key not in seen
                        if good: valid+=1
                        else: reasons.append('INVALID_CONTRACT_QUOTE')
                        seen.add(key)
                    except Exception: reasons.append('INVALID_CONTRACT')
                contract_counts.append((valid,len(cs)))
            except Exception: reasons.append('INVALID_SNAPSHOT')
        contract_ratio=(sum(v for v,n in contract_counts)/sum(n for v,n in contract_counts)) if contract_counts and sum(n for v,n in contract_counts) else 0
        temporal=checks/total
        score=round(0.6*temporal+0.4*contract_ratio,4)
        return {'status':'READY' if score>=0.999 and not reasons else 'DEGRADED','score':score,'temporal_validity':temporal,'contract_validity':contract_ratio,'snapshots':len(snapshots),'issues':reasons[:50],'issue_count':len(reasons)}

class HighSpeedReplayEngine:
    """In-memory sequential replay. Signal at i can only consume state at i and fill at i+1."""
    def validate(self,snapshots):
        if not isinstance(snapshots,list) or len(snapshots)<2:return {'status':'BLOCKED','reason':'INSUFFICIENT_SNAPSHOTS'}
        prev=None
        for s in snapshots:
            try:
                t=datetime.fromisoformat(str(s['timestamp']).replace('Z','+00:00')); spot=float(s['spot'])
                if spot<=0 or not isfinite(spot) or not isinstance(s.get('contracts'),list) or not s['contracts']: return {'status':'BLOCKED','reason':'INVALID_SNAPSHOT'}
                if prev is not None and t<=prev:return {'status':'BLOCKED','reason':'NON_MONOTONIC_TIMESTAMP'}
                prev=t
            except Exception:return {'status':'BLOCKED','reason':'INVALID_SNAPSHOT'}
        return {'status':'READY'}
    def replay(self,snapshots,signal_indices=None,callback=None,max_events=1_000_000):
        chk=self.validate(snapshots)
        if chk['status']!='READY': return chk
        indices=list(range(len(snapshots)-1)) if signal_indices is None else [int(x) for x in signal_indices]
        if len(indices)>max_events:return {'status':'BLOCKED','reason':'EVENT_LIMIT_EXCEEDED'}
        events=[]; start=time.perf_counter()
        for i in indices:
            if i<0 or i+1>=len(snapshots): return {'status':'BLOCKED','reason':'SIGNAL_INDEX_OUT_OF_RANGE','index':i}
            e=ReplayEvent(i,i+1,str(snapshots[i]['timestamp']),str(snapshots[i+1]['timestamp']))
            events.append(e)
            if callback: callback(snapshots[i],snapshots[i+1],i)
        elapsed=max(time.perf_counter()-start,1e-9)
        return {'status':'READY','events':len(events),'elapsed_seconds':elapsed,'events_per_second':round(len(events)/elapsed,2),'first_event':events[0].__dict__ if events else None,'last_event':events[-1].__dict__ if events else None,'lookahead_protection':True,'replay_only':True}
    def soak(self,snapshots,passes=3):
        passes=max(1,min(int(passes),100)); out=[]; total=0; start=time.perf_counter()
        for _ in range(passes):
            r=self.replay(snapshots); 
            if r['status']!='READY': return r
            out.append(r['events_per_second']); total+=r['events']
        elapsed=max(time.perf_counter()-start,1e-9)
        return {'status':'READY','passes':passes,'events':total,'elapsed_seconds':elapsed,'aggregate_events_per_second':round(total/elapsed,2),'min_pass_eps':round(min(out),2),'max_pass_eps':round(max(out),2)}
