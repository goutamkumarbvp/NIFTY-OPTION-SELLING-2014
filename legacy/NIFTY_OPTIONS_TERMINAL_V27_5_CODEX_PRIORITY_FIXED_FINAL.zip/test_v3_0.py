import json, threading
from urllib.request import urlopen, Request
from http.server import ThreadingHTTPServer
from server import APP, Handler
from risk_brain import RiskBrain, RiskLimits

def test_daily_loss_blocks():
    rb=RiskBrain(RiskLimits(max_daily_loss=1000))
    s=rb.snapshot([], {'data':{'availableMargin':100000}}, daily_pnl=-1000)
    assert rb.evaluate(s, {'side':'SELL','quantity':75,'price':100})['decision']=='BLOCK'

def test_projected_qty_blocks():
    rb=RiskBrain(RiskLimits(max_position_qty=100))
    pos={'data':[{'quantity':75,'averagePrice':100}]}; lim={'data':{'availableMargin':100000}}
    s=rb.snapshot(pos,lim)
    assert rb.evaluate(s, {'side':'BUY','quantity':50,'price':100})['decision']=='BLOCK'

def test_exposure_blocks():
    rb=RiskBrain(RiskLimits(max_total_exposure=10000))
    s=rb.snapshot([], {'data':{'availableMargin':100000,'marginUsed':0}})
    assert rb.evaluate(s, {'side':'SELL','quantity':101,'price':100})['decision']=='BLOCK'

def test_invalid_side_blocks():
    rb=RiskBrain(); s=rb.snapshot([], {'data':{'availableMargin':100000,'marginUsed':0}})
    assert rb.evaluate(s, {'side':'HOLD','quantity':75,'price':100})['decision']=='BLOCK'

def test_valid_paper_order_allows():
    rb=RiskBrain(); s=rb.snapshot([], {'data':{'availableMargin':100000,'marginUsed':0}})
    assert rb.evaluate(s, {'side':'SELL','quantity':75,'price':100})['decision']=='ALLOW_PAPER'

def test_routes_and_health():
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler); port=srv.server_address[1]; t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
    try:
        h=json.loads(urlopen(f'http://127.0.0.1:{port}/api/health').read()); assert h['api_schema_version']=='v12.0' and h['backend_wired']
        req=Request(f'http://127.0.0.1:{port}/api/risk/evaluate',data=json.dumps({'order':{'side':'SELL','quantity':75,'price':100},'limits':{'data':{'availableMargin':100000,'marginUsed':0}}}).encode(),headers={'Content-Type':'application/json'})
        out=json.loads(urlopen(req).read()); assert out['ok'] and out['decision']['decision']=='ALLOW_PAPER'
    finally:srv.shutdown();srv.server_close()
