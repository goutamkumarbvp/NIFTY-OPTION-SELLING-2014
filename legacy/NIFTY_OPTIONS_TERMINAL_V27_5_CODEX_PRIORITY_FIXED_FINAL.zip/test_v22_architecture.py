import ast
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SERVICES=('market_service.py','intelligence_service.py','research_service.py','ai_service.py')
CONCRETE={'kotak_neo_adapter','market_feed','pass14_engine','pass15_engine','market_intelligence','risk_brain','advanced_risk','strategy_brain','options_intelligence','market_regime','quant_engine','vol_surface','event_intelligence','fii_dii_intelligence','research_backtest','research_data','options_backtest','walk_forward','stress_monte_carlo','strategy_backtest','historical_option_store','options_replay','research_margin','market_data_v10','pass11_engine','pass12_engine','pass13_engine','super_ai_agent','pass17_agent_engine','alert_engine','self_repair'}
def imports(path):
 t=ast.parse(path.read_text(encoding='utf-8')); out=set()
 for n in ast.walk(t):
  if isinstance(n,ast.Import): out|={a.name.split('.')[0] for a in n.names}
  elif isinstance(n,ast.ImportFrom) and n.module: out.add(n.module.split('.')[0])
 return out
def test_typed_contract_module_is_domain_neutral():
 im=imports(ROOT/'application_contracts.py'); assert not (im & CONCRETE); assert 'server' not in im and 'terminal_backend' not in im
def test_services_import_only_contracts_or_stdlib():
 for name in SERVICES: assert not (imports(ROOT/name)&CONCRETE); assert 'terminal_backend' not in imports(ROOT/name)
def test_event_bus_uses_typed_event_contract():
 text=(ROOT/'event_bus.py').read_text(); assert 'DomainEvent' in text and 'EventTopic' in text; assert 'terminal_backend' not in imports(ROOT/'event_bus.py')
def test_server_remains_transport_only():
 im=imports(ROOT/'server.py'); assert im <= {'terminal_backend','json','os','http','pathlib','urllib','__future__','threading','signal','runtime_config'}
def test_backend_accepts_typed_command():
 text=(ROOT/'terminal_backend.py').read_text(); assert 'ApplicationCommand' in text and 'CommandName' in text
def test_no_duplicate_ai_contract_import():
 assert (ROOT/'ai_service.py').read_text().count('from service_contracts import AIDependencies') == 1
def test_domain_event_legacy_mapping_compatibility():
 from application_contracts import DomainEvent
 e=DomainEvent('x', {'v':22}); assert e['v']==22 and e.get('missing',7)==7
