import concurrent.futures
import threading
import time
from pathlib import Path
from types import SimpleNamespace


def _stop(tb):
    if getattr(tb, '_auto_repair_stop', None):
        tb._auto_repair_stop.set()
    if getattr(tb, 'self_healing', None):
        tb.self_healing.stop()


def _ready(tb, symbol='NIFTY', price=100.0):
    class State:
        def snapshot(self):
            return {'connected': True, 'age': 0.1, 'local_sequence': 1, 'market_status': 'OPEN'}
    tb.feed = SimpleNamespace(state=State())
    tb.ticks[('nse_fo', 'paper')] = SimpleNamespace(
        trading_symbol=symbol, instrument_token='paper', ltp=price, timestamp=time.time()-0.1)


def _authorize(tb):
    r = tb.risk_evaluate({'limits': {'data': {'availableMargin': 100000}}, 'daily_pnl': 0,
                          'order': {'side': 'BUY', 'quantity': 75, 'price': 100}})
    assert r['decision']['decision'] == 'ALLOW_PAPER'


def test_panic_and_paper_order_are_linearized(tmp_path, monkeypatch):
    import terminal_backend
    monkeypatch.setattr(terminal_backend, 'ROOT', tmp_path)
    tb = terminal_backend.TerminalBackend()
    try:
        _ready(tb)
        _authorize(tb)
        entered = threading.Event()
        release = threading.Event()
        original_submit = tb.paper_ledger.submit

        def blocked_submit(*args, **kwargs):
            entered.set()
            assert release.wait(5), 'test synchronization timeout'
            return original_submit(*args, **kwargs)

        tb.paper_ledger.submit = blocked_submit
        order_result = {}
        panic_result = {}

        def do_order():
            order_result['r'] = tb.paper_order({'symbol': 'NIFTY', 'side': 'BUY', 'quantity': 75, 'fill_price': 100})

        def do_panic():
            panic_result['r'] = tb.command('panic')

        ot = threading.Thread(target=do_order)
        ot.start()
        assert entered.wait(5)
        pt = threading.Thread(target=do_panic)
        pt.start()
        time.sleep(0.1)
        # panic must not be able to publish EMERGENCY while the atomic execution
        # critical section is still capable of committing an order.
        assert 'r' not in panic_result
        release.set()
        ot.join(5); pt.join(5)
        assert order_result['r']['ok'] is True
        assert panic_result['r']['ok'] is True
        assert panic_result['r']['state']['mode'] == 'EMERGENCY'
        assert tb.paper_ledger.positions()[0]['net_quantity'] == 75

        # Once panic has linearized, every later execution attempt is rejected.
        blocked = tb.paper_order({'symbol': 'NIFTY', 'side': 'BUY', 'quantity': 75, 'fill_price': 100})
        assert not blocked['ok']
        assert 'EMERGENCY_STOP_ACTIVE' in blocked['error']
        assert tb.paper_ledger.positions()[0]['net_quantity'] == 75
    finally:
        _stop(tb)


def test_concurrent_flatten_is_idempotent(tmp_path):
    from paper_execution import PaperExecutionLedger
    ledger = PaperExecutionLedger(Path(tmp_path) / 'paper.sqlite3')
    ledger.submit('NIFTY', 'BUY', 75, fill_price=100)
    with concurrent.futures.ThreadPoolExecutor(max_workers=32) as ex:
        results = list(ex.map(lambda _: ledger.flatten({'NIFTY': 100}), range(32)))
    fills = [item for result in results for item in result]
    positions = ledger.positions()
    assert len(fills) == 1
    assert positions[0]['net_quantity'] == 0
    assert positions[0]['buy_quantity'] == 75
    assert positions[0]['sell_quantity'] == 75


def test_concurrent_flatten_multiple_symbols_is_atomic(tmp_path):
    from paper_execution import PaperExecutionLedger
    ledger = PaperExecutionLedger(Path(tmp_path) / 'paper.sqlite3')
    ledger.submit('A', 'BUY', 75, fill_price=100)
    ledger.submit('B', 'SELL', 50, fill_price=200)
    with concurrent.futures.ThreadPoolExecutor(max_workers=24) as ex:
        results = list(ex.map(lambda _: ledger.flatten({'A': 100, 'B': 200}), range(24)))
    fills = [item for result in results for item in result]
    by_symbol = {p['symbol']: p['net_quantity'] for p in ledger.positions()}
    assert len(fills) == 2
    assert by_symbol['A'] == 0
    assert by_symbol['B'] == 0
