# V18.0 — Verified Code Self-Repair & Automatic Rollback

## Added
- `self_repair.py`: code self-repair control plane.
- Structured AI-style diagnosis with incident IDs, severity, confidence, evidence and recommended action.
- Pluggable repair-provider interface; deterministic offline provider included.
- Immutable source checkpoint before promotion.
- Isolated sandbox candidate workspace.
- Candidate AST/syntax validation.
- Mandatory compile + pytest + safety-invariant verification.
- Automatic rollback after failed post-promotion verification.
- Hard safety policy preventing live trading enablement, order-function injection, secret-file mutation, and out-of-root mutation.
- Runtime status exposed through `/api/self-repair/status`.
- Diagnosis exposed through `/api/self-repair/diagnose`.
- Verified repair flow exposed through `/api/self-repair/run`.
- `SELF_REPAIR_AUTO_PROMOTE=false` by default.

## Verification
- 271/271 pytest PASS.
- V18 self-repair tests cover diagnosis, safety block, sandbox verification, non-promotion, and rollback.
- Server startup/health smoke test PASS on an isolated port.

## Safety
The engine does not place broker orders, enable live trading, modify risk policy, or bypass emergency/pause controls. General AI patch generation is provider-dependent; all generated candidates remain subject to deterministic policy and test gates.
